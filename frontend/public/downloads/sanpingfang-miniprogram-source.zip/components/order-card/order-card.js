Component({
  properties: {
    order: { type: Object, value: {} }
  },
  methods: {
    onTap() {
      this.triggerEvent('tap', { order: this.data.order });
    },
    onAction(e) {
      const action = e.currentTarget.dataset.action;
      this.triggerEvent('action', { order: this.data.order, action });
    }
  }
});
