Component({
  properties: {
    product: { type: Object, value: {} },
    showAction: { type: Boolean, value: true }
  },
  methods: {
    onTap() {
      this.triggerEvent('tap', { product: this.data.product });
    },
    onAction() {
      this.triggerEvent('action', { product: this.data.product });
    }
  }
});
