Component({
  properties: {
    visible: { type: Boolean, value: true },
    title: { type: String, value: '加载失败' },
    desc: { type: String, value: '请检查网络后重试' },
    retryText: { type: String, value: '重新加载' }
  },
  methods: {
    onRetry() {
      this.triggerEvent('retry');
    }
  }
});
