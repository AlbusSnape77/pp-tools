const runtime = {
  mode: 'demo',
  cloudEnvId: ''
};

runtime.isDemo = function isDemo() {
  return runtime.mode === 'demo';
};

runtime.validate = function validate() {
  if (!['demo', 'cloud'].includes(runtime.mode)) {
    throw new Error('运行模式只能是 demo 或 cloud');
  }
  if (runtime.mode === 'cloud' && !String(runtime.cloudEnvId || '').trim()) {
    throw new Error('云开发模式必须配置 cloudEnvId');
  }
};

module.exports = runtime;
