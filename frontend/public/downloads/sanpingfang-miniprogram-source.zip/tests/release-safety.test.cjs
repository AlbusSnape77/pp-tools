const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    if (entry.name === '.git' || entry.name === 'project.private.config.json') return [];
    const target = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(target) : [target];
  });
}

test('公开项目配置不包含个人 AppID 或固定云环境', () => {
  const project = JSON.parse(fs.readFileSync(path.join(root, 'project.config.json'), 'utf8'));
  assert.equal(project.appid, 'touristappid');

  const unsafe = walk(root)
    .filter(file => /\.(js|json|md)$/i.test(file))
    .filter(file => /wx[0-9a-f]{16}|cloud[0-9]+-[a-z0-9-]+/i.test(fs.readFileSync(file, 'utf8')));
  assert.deepEqual(unsafe, []);
});

test('私有项目配置被忽略且个人页提供演示数据重置入口', () => {
  const ignore = fs.readFileSync(path.join(root, '.gitignore'), 'utf8');
  const mineScript = fs.readFileSync(path.join(root, 'pages/mine/mine.js'), 'utf8');
  const mineTemplate = fs.readFileSync(path.join(root, 'pages/mine/mine.wxml'), 'utf8');

  assert.match(ignore, /project\.private\.config\.json/);
  assert.match(mineScript, /resetDemoData/);
  assert.match(mineTemplate, /重置演示数据/);
});

test('微信运行时使用显式文件路径加载演示分发器', () => {
  const dataRuntime = fs.readFileSync(path.join(root, 'utils/data-runtime.js'), 'utf8');

  assert.match(dataRuntime, /require\(['"]\.\/demo\/index['"]\)/);
  assert.doesNotMatch(dataRuntime, /require\(['"]\.\/demo['"]\)/);
});
