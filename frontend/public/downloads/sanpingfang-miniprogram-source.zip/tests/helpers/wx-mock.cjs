function clone(value) {
  if (value === undefined) return undefined;
  return JSON.parse(JSON.stringify(value));
}

function createWxMock() {
  const storage = new Map();
  let cloudCalls = 0;

  return {
    getStorageSync(key) {
      return clone(storage.get(key));
    },
    setStorageSync(key, value) {
      storage.set(key, clone(value));
    },
    removeStorageSync(key) {
      storage.delete(key);
    },
    clearStorageSync() {
      storage.clear();
    },
    cloud: {
      callFunction() {
        cloudCalls += 1;
        return Promise.reject(new Error('测试中不应调用云函数'));
      }
    },
    __cloudCallCount() {
      return cloudCalls;
    },
    __reset() {
      storage.clear();
      cloudCalls = 0;
    }
  };
}

module.exports = { createWxMock };
