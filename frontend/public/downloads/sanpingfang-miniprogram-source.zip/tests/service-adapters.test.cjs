const test = require('node:test');
const assert = require('node:assert/strict');
const { beforeEach } = require('node:test');
const { createWxMock } = require('./helpers/wx-mock.cjs');

global.wx = createWxMock();
global.getApp = () => ({ globalData: {} });

const cloudAuth = require('../utils/cloud-auth');
const cloudProduct = require('../utils/cloud-product');
const cloudOrder = require('../utils/cloud-order');
const cloudUser = require('../utils/cloud-user');
const cloudShop = require('../utils/cloud-shop');
const cloudFeedback = require('../utils/cloud-feedback');
const cloudFile = require('../utils/cloud-file');
const mediaUploader = require('../utils/media-uploader');

beforeEach(() => {
  wx.__reset();
  wx.setStorageSync('authInfo', { userId: 'demo-user-1', role: 'user' });
});

test('现有页面服务在演示模式返回本地商品和登录结果', async () => {
  const login = await cloudAuth.userLogin('user', '123456');
  const products = await cloudProduct.listProducts();

  assert.equal(login.authInfo.role, 'user');
  assert.ok(products.list.length >= 12);
  assert.equal(wx.__cloudCallCount(), 0);
});

test('用户、订单、门店和反馈服务保持现有返回接口', async () => {
  await cloudUser.saveCartList([{ cartId: 'cart-1' }]);
  const created = await cloudOrder.createOrder({
    items: [{ id: 1, name: '珍珠奶茶', price: 16, quantity: 1 }],
    totalPrice: 16
  });
  const orders = await cloudOrder.listMyOrders();
  const storeState = await cloudShop.syncShopStateToLocal();
  await cloudFeedback.createFeedback({ content: '演示反馈' });

  assert.equal(created.order.id, orders.list[0].id);
  assert.equal(created.order.id, orders.ordersList[0].id);
  assert.equal(storeState.storeConfig.status, 'open');
  assert.equal((wx.getStorageSync('cartList') || [])[0].cartId, 'cart-1');
  assert.equal(wx.__cloudCallCount(), 0);
});

test('演示模式保留本地图片且不读取或上传云文件', async () => {
  const localPath = 'wxfile://temp/avatar.png';
  assert.equal(await cloudFile.resolveImageUrl(localPath), localPath);
  assert.equal(await cloudFile.resolveImageUrl('cloud://private/avatar.png'), '');
  assert.equal(await mediaUploader.uploadImage(localPath, 'avatar'), localPath);
  assert.equal(wx.__cloudCallCount(), 0);
});
