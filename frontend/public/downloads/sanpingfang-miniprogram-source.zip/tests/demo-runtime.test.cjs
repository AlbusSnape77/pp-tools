const test = require('node:test');
const assert = require('node:assert/strict');
const { beforeEach } = require('node:test');
const { createWxMock } = require('./helpers/wx-mock.cjs');

global.wx = createWxMock();

const store = require('../utils/demo/store');
const auth = require('../utils/demo/auth');
const products = require('../utils/demo/products');
const users = require('../utils/demo/users');
const orders = require('../utils/demo/orders');
const shop = require('../utils/demo/shop');
const feedback = require('../utils/demo/feedback');
const account = require('../utils/demo/account');
const dataRuntime = require('../utils/data-runtime');

beforeEach(() => {
  wx.__reset();
});

test('首次读取时初始化数据库并持久化后续修改', () => {
  const first = store.read();
  assert.ok(first.products.length >= 12);
  first.shop.status = 'pause';
  store.write(first);
  assert.equal(store.read().shop.status, 'pause');
});

test('重置后恢复演示账号和门店状态', () => {
  const current = store.read();
  current.users[0].nickname = '已修改';
  store.write(current);

  const reset = store.reset();

  assert.equal(reset.shop.status, 'open');
  assert.equal(reset.users[0].username, 'user');
  assert.equal(reset.users[0].nickname, '演示用户');
  assert.equal(reset.admins[0].username, 'admin');
});

test('演示用户和管理员可以登录且错误密码被拒绝', async () => {
  assert.equal((await auth.userLogin({ username: 'user', password: '123456' })).authInfo.role, 'user');
  assert.equal((await auth.adminEntry({ username: 'admin', password: 'admin123' })).authInfo.role, 'admin');
  await assert.rejects(() => auth.userLogin({ username: 'user', password: 'wrong-password' }), /账号或密码错误/);
});

test('普通用户可以注册且不能重复使用用户名', async () => {
  const result = await auth.userRegister({ username: 'newuser', password: '654321', nickname: '新用户' });
  assert.equal(result.authInfo.username, 'newuser');
  await assert.rejects(() => auth.userRegister({ username: 'newuser', password: '654321', nickname: '重复' }), /已存在/);
});

test('用户数据只保存购物车收藏和最近浏览', async () => {
  const saved = await users.updateUserData({
    userId: 'demo-user-1',
    data: { cartList: [{ cartId: 1 }], favoriteList: [2], recentViewedList: [3], ignored: true }
  });
  assert.deepEqual(saved.cartList, [{ cartId: 1 }]);
  assert.deepEqual((await users.getUserData({ userId: 'demo-user-1' })).favoriteList, [2]);
  assert.equal(Object.hasOwn(saved, 'ignored'), false);
});

test('商品支持读取新增编辑和售卖状态更新', async () => {
  const initial = await products.listProducts();
  const created = await products.upsertProduct({
    product: { name: '测试饮品', desc: '测试描述', price: 15, category: '果茶', stock: 8 }
  });
  const updated = await products.upsertProduct({ product: { ...created.product, price: 17 } });
  await products.updateStatus({ productId: created.product.id, status: 'paused' });
  const status = (await products.listStatus()).list.find(item => item.productId === created.product.id);

  assert.ok(initial.list.length >= 12);
  assert.equal(updated.product.price, 17);
  assert.equal(status.status, 'paused');
});

test('下单扣减库存并支持管理员更新状态和用户查询', async () => {
  const before = (await products.getProduct({ id: 1 })).product.stock;
  const created = await orders.createOrder({
    userId: 'demo-user-1',
    order: {
      totalPrice: 16,
      payablePrice: 16,
      items: [{ id: 1, name: '珍珠奶茶', price: 16, quantity: 1 }]
    }
  });
  await orders.updateStatus({ action: 'adminUpdateById', orderId: created.order.id, status: '制作中' });
  const mine = await orders.listOrders({ scope: 'mine', userId: 'demo-user-1' });

  assert.equal((await products.getProduct({ id: 1 })).product.stock, before - 1);
  assert.equal(mine.list[0].status, '制作中');
});

test('取消订单只恢复一次库存', async () => {
  const before = (await products.getProduct({ id: 1 })).product.stock;
  const created = await orders.createOrder({
    userId: 'demo-user-1',
    order: { items: [{ id: 1, name: '珍珠奶茶', price: 16, quantity: 2 }], totalPrice: 32 }
  });
  await orders.updateStatus({ action: 'cancelMine', orderId: created.order.id, userId: 'demo-user-1' });
  await assert.rejects(
    () => orders.updateStatus({ action: 'cancelMine', orderId: created.order.id, userId: 'demo-user-1' }),
    /不能重复取消/
  );
  assert.equal((await products.getProduct({ id: 1 })).product.stock, before);
});

test('门店反馈和账号资料可以在本地更新', async () => {
  await shop.updateConfig({ config: { status: 'pause' } });
  const created = await feedback.create({ userId: 'demo-user-1', feedback: { content: '口味很好' } });
  await feedback.updateStatus({ action: 'markProcessed', feedbackId: created.feedback.id });
  wx.setStorageSync('authInfo', { userId: 'demo-user-1', role: 'user' });
  const changed = await account.update({ currentPassword: '123456', nickname: '新昵称' });

  assert.equal((await shop.getConfig()).config.status, 'pause');
  assert.equal((await feedback.list({ scope: 'all' })).list[0].status, '已处理');
  assert.equal(changed.authInfo.nickname, '新昵称');
});

test('demo 模式通过统一入口调用且不会请求云函数', async () => {
  const productResult = await dataRuntime.callFunction('productList');
  assert.ok(productResult.list.length >= 12);
  assert.equal(wx.__cloudCallCount(), 0);
  await assert.rejects(() => dataRuntime.callFunction('unknownFunction'), /不支持的演示操作/);
});
