const test = require('node:test');
const assert = require('node:assert/strict');

const runtime = require('../config/runtime');

test('公开源码默认使用本地演示模式', () => {
  assert.equal(runtime.mode, 'demo');
  assert.equal(runtime.cloudEnvId, '');
  assert.equal(runtime.isDemo(), true);
  assert.doesNotThrow(() => runtime.validate());
});
