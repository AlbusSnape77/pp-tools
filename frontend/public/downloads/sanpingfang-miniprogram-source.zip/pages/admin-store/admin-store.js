const cloudShop = require('../../utils/cloud-shop');
const mediaUploader = require('../../utils/media-uploader');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    activeStatus: 'open',
    storeLogo: '',
    storeLogoDisplay: '',
    storeCover: '',
    storeCoverDisplay: '',
    savingConfig: false,
    statusList: [
      {
        value: 'open',
        title: '营业中',
        desc: '顾客端可正常下单'
      },
      {
        value: 'pause',
        title: '暂停接单',
        desc: '顾客端可浏览，但暂不可提交订单'
      },
      {
        value: 'closed',
        title: '已打烊',
        desc: '顾客端显示打烊状态，暂不可下单'
      }
    ]
  },

  async onShow() {
    await this.loadStoreStatus();
  },

  async loadStoreStatus() {
    try {
      const res = await cloudShop.getStoreConfig();

      const config = (res && res.config) || {};
      const mediaConfig = await cloudFile.attachDisplayUrls({
        storeLogo: config.storeLogo || '',
        storeCover: config.storeCover || ''
      }, ['storeLogo', 'storeCover']);

      this.setData({
        activeStatus: config.status || 'open',
        storeLogo: mediaConfig.storeLogo || '',
        storeLogoDisplay: mediaConfig.storeLogoDisplay || '',
        storeCover: mediaConfig.storeCover || '',
        storeCoverDisplay: mediaConfig.storeCoverDisplay || ''
      });
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '读取门店状态失败',
        icon: 'none'
      });
    }
  },

  chooseStatus(e) {
    const value = e.currentTarget.dataset.value || 'open';

    this.setData({
      activeStatus: value
    });
  },

  async persistStoreConfig(extraPatch = {}, options = {}) {
    if (this.data.savingConfig) {
      throw new Error('正在保存，请稍候');
    }

    const hasStoreLogo = Object.prototype.hasOwnProperty.call(extraPatch, 'storeLogo');
    const hasStoreCover = Object.prototype.hasOwnProperty.call(extraPatch, 'storeCover');
    const hasStatus = Object.prototype.hasOwnProperty.call(extraPatch, 'status');

    const nextConfig = {
      status: hasStatus ? extraPatch.status : this.data.activeStatus,
      storeLogo: hasStoreLogo ? extraPatch.storeLogo : this.data.storeLogo,
      storeCover: hasStoreCover ? extraPatch.storeCover : this.data.storeCover
    };

    const previewPatch = options.previewPatch || {};

    this.setData({
      ...nextConfig,
      ...previewPatch,
      savingConfig: true
    });

    try {
      const res = await cloudShop.updateStoreConfig(nextConfig);
      const savedConfig = (res && res.config) || nextConfig;
      const mediaConfig = await cloudFile.attachDisplayUrls({
        storeLogo: savedConfig.storeLogo || '',
        storeCover: savedConfig.storeCover || ''
      }, ['storeLogo', 'storeCover']);

      this.setData({
        activeStatus: savedConfig.status || 'open',
        storeLogo: mediaConfig.storeLogo || '',
        storeLogoDisplay: mediaConfig.storeLogoDisplay || '',
        storeCover: mediaConfig.storeCover || '',
        storeCoverDisplay: mediaConfig.storeCoverDisplay || ''
      });

      if (options.successTitle) {
        wx.showToast({
          title: options.successTitle,
          icon: 'success'
        });
      }

      return savedConfig;
    } finally {
      this.setData({
        savingConfig: false
      });
    }
  },

  async chooseStoreLogo() {
    try {
      const upload = await mediaUploader.chooseAndUploadImage('store/logo');
      await this.persistStoreConfig({
        storeLogo: upload.fileID
      }, {
        previewPatch: {
          storeLogoDisplay: upload.tempFilePath || upload.fileID
        },
        successTitle: '门店头像已保存'
      });
    } catch (err) {
      if ((err && err.message) === '已取消选择图片') return;
      await this.loadStoreStatus();
      wx.showToast({ title: (err && err.message) || '上传失败', icon: 'none' });
    }
  },

  async chooseStoreCover() {
    try {
      const upload = await mediaUploader.chooseAndUploadImage('store/cover');
      await this.persistStoreConfig({
        storeCover: upload.fileID
      }, {
        previewPatch: {
          storeCoverDisplay: upload.tempFilePath || upload.fileID
        },
        successTitle: '门店封面已保存'
      });
    } catch (err) {
      if ((err && err.message) === '已取消选择图片') return;
      await this.loadStoreStatus();
      wx.showToast({ title: (err && err.message) || '上传失败', icon: 'none' });
    }
  },

  async clearStoreImage(e) {
    const field = e.currentTarget.dataset.field;
    if (!field) return;

    const patch = { [field]: '' };
    const previewPatch = {};
    if (field === 'storeLogo') previewPatch.storeLogoDisplay = '';
    if (field === 'storeCover') previewPatch.storeCoverDisplay = '';

    try {
      await this.persistStoreConfig(patch, {
        previewPatch,
        successTitle: field === 'storeLogo' ? '门店头像已清空' : '门店封面已清空'
      });
    } catch (err) {
      await this.loadStoreStatus();
      wx.showToast({
        title: (err && err.message) || '操作失败',
        icon: 'none'
      });
    }
  },

  async saveStoreStatus() {
    try {
      await this.persistStoreConfig({
        status: this.data.activeStatus
      }, {
        successTitle: '门店状态已更新'
      });
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '更新失败',
        icon: 'none'
      });
    }
  }
});
