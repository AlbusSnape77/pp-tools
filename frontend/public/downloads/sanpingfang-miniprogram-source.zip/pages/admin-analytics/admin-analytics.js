const echarts = require('../../ec-canvas/echarts');
const cloudOrder = require('../../utils/cloud-order');
const cloudFeedback = require('../../utils/cloud-feedback');

let pageRef = null;
let trendChart = null;
let statusChart = null;
let categoryChart = null;
let hourlyChart = null;
let pickupChart = null;

function getEmptyOption(text) {
  return {
    animation: false,
    graphic: {
      type: 'text',
      left: 'center',
      top: 'middle',
      style: {
        text,
        fill: '#98A2B3',
        fontSize: 14
      }
    }
  };
}

function getTrendOption(data) {
  if (!data.length) {
    return getEmptyOption('当前范围暂无趋势数据');
  }

  const xData = data.map(item => item.label);
  const orderData = data.map(item => item.orders);
  const revenueData = data.map(item => Number(item.revenue || 0));
  const totalOrders = orderData.reduce((sum, n) => sum + n, 0);

  if (totalOrders === 0) {
    return getEmptyOption('当前范围暂无订单数据');
  }

  const rotate = data.length > 10 ? 35 : 0;

  return {
    animation: false,
    color: ['#36CFC9', '#5B8FF9'],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'line',
        link: [
          {
            xAxisIndex: 'all'
          }
        ]
      },
      formatter(params) {
        if (!params || !params.length) return '';
        const label = params[0].axisValue || '';
        let revenue = 0;
        let orders = 0;

        params.forEach(item => {
          if (item.seriesName === '营收') revenue = Number(item.value || 0);
          if (item.seriesName === '订单') orders = Number(item.value || 0);
        });

        return `${label}<br/>营收：￥${revenue.toFixed(2)}<br/>订单：${orders} 单`;
      }
    },
    legend: {
      top: 0,
      right: 0,
      itemWidth: 12,
      itemHeight: 8,
      textStyle: {
        fontSize: 10,
        color: '#667085'
      }
    },
    grid: [
      {
        left: 44,
        right: 18,
        top: 46,
        height: 160
      },
      {
        left: 44,
        right: 18,
        top: 270,
        height: 120
      }
    ],
    xAxis: [
      {
        type: 'category',
        boundaryGap: false,
        data: xData,
        axisLine: {
          lineStyle: {
            color: '#DCE3F0'
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          show: false
        }
      },
      {
        type: 'category',
        data: xData,
        axisLine: {
          lineStyle: {
            color: '#DCE3F0'
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          color: '#667085',
          fontSize: 10,
          rotate
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: '营收',
        axisLine: {
          show: false
        },
        splitLine: {
          lineStyle: {
            color: '#EEF2F7'
          }
        },
        axisLabel: {
          color: '#667085',
          fontSize: 10,
          formatter(value) {
            return `￥${value}`;
          }
        }
      },
      {
        type: 'value',
        name: '订单',
        minInterval: 1,
        axisLine: {
          show: false
        },
        splitLine: {
          lineStyle: {
            color: '#EEF2F7'
          }
        },
        axisLabel: {
          color: '#667085',
          fontSize: 10
        }
      }
    ],
    series: [
      {
        name: '营收',
        type: 'line',
        smooth: true,
        xAxisIndex: 0,
        yAxisIndex: 0,
        symbol: 'circle',
        symbolSize: 6,
        lineStyle: {
          width: 3
        },
        areaStyle: {
          opacity: 0.1
        },
        data: revenueData
      },
      {
        name: '订单',
        type: 'bar',
        xAxisIndex: 1,
        yAxisIndex: 1,
        barWidth: 14,
        borderRadius: 8,
        data: orderData
      }
    ]
  };
}

function getStatusOption(data) {
  const total = data.reduce((sum, item) => sum + Number(item.value || 0), 0);

  if (!data.length || total === 0) {
    return getEmptyOption('暂无订单结构数据');
  }

  return {
    animation: false,
    color: ['#F6BD16', '#5B8FF9', '#36CFC9', '#52C41A', '#FF7875'],
    tooltip: {
      trigger: 'item'
    },
    legend: {
      bottom: 0,
      left: 'center',
      itemWidth: 10,
      itemHeight: 10,
      textStyle: {
        fontSize: 10,
        color: '#667085'
      }
    },
    graphic: [
      {
        type: 'text',
        left: 'center',
        top: '38%',
        style: {
          text: `订单\n${total}`,
          textAlign: 'center',
          fill: '#273142',
          fontSize: 14,
          fontWeight: 700
        }
      }
    ],
    series: [
      {
        name: '订单结构',
        type: 'pie',
        radius: ['50%', '68%'],
        center: ['50%', '40%'],
        avoidLabelOverlap: true,
        label: {
          show: false
        },
        labelLine: {
          show: false
        },
        data
      }
    ]
  };
}

function getCategoryOption(data) {
  if (!data.length) {
    return getEmptyOption('暂无品类表现数据');
  }

  const yData = data.map(item => item.name).reverse();
  const xData = data.map(item => Number(item.revenue || 0)).reverse();

  return {
    animation: false,
    color: ['#7B61FF'],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    grid: {
      left: 72,
      right: 18,
      top: 18,
      bottom: 18
    },
    xAxis: {
      type: 'value',
      axisLine: {
        show: false
      },
      splitLine: {
        lineStyle: {
          color: '#EEF2F7'
        }
      },
      axisLabel: {
        color: '#667085',
        fontSize: 10,
        formatter(value) {
          return `￥${value}`;
        }
      }
    },
    yAxis: {
      type: 'category',
      data: yData,
      axisLabel: {
        color: '#667085',
        fontSize: 10
      },
      axisLine: {
        show: false
      }
    },
    series: [
      {
        name: '营收',
        type: 'bar',
        barWidth: 16,
        borderRadius: 8,
        data: xData
      }
    ]
  };
}

function getHourlyOption(data) {
  if (!data.length) {
    return getEmptyOption('暂无分时数据');
  }

  const xData = data.map(item => item.label);
  const yData = data.map(item => item.orders);
  const total = yData.reduce((sum, n) => sum + n, 0);

  if (total === 0) {
    return getEmptyOption('当前范围暂无分时订单数据');
  }

  return {
    animation: false,
    color: ['#FF8F5A'],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    grid: {
      left: 36,
      right: 16,
      top: 18,
      bottom: 44
    },
    xAxis: {
      type: 'category',
      data: xData,
      axisLine: {
        lineStyle: {
          color: '#DCE3F0'
        }
      },
      axisLabel: {
        color: '#667085',
        fontSize: 10,
        rotate: 35
      }
    },
    yAxis: {
      type: 'value',
      minInterval: 1,
      axisLine: {
        show: false
      },
      splitLine: {
        lineStyle: {
          color: '#EEF2F7'
        }
      },
      axisLabel: {
        color: '#667085',
        fontSize: 10
      }
    },
    series: [
      {
        name: '订单数',
        type: 'bar',
        barWidth: 12,
        borderRadius: 8,
        data: yData
      }
    ]
  };
}

function getPickupOption(data) {
  const total = data.reduce((sum, item) => sum + Number(item.value || 0), 0);

  if (!data.length || total === 0) {
    return getEmptyOption('暂无取单方式数据');
  }

  return {
    animation: false,
    color: ['#5B8FF9', '#FF8F5A'],
    tooltip: {
      trigger: 'item'
    },
    legend: {
      bottom: 0,
      left: 'center',
      itemWidth: 10,
      itemHeight: 10,
      textStyle: {
        fontSize: 10,
        color: '#667085'
      }
    },
    graphic: [
      {
        type: 'text',
        left: 'center',
        top: '38%',
        style: {
          text: `取单\n${total}`,
          textAlign: 'center',
          fill: '#273142',
          fontSize: 14,
          fontWeight: 700
        }
      }
    ],
    series: [
      {
        name: '取单方式',
        type: 'pie',
        radius: ['50%', '68%'],
        center: ['50%', '40%'],
        label: {
          show: false
        },
        labelLine: {
          show: false
        },
        data
      }
    ]
  };
}

Page({
  data: {
    ordersList: [],
    feedbackList: [],

    activeRange: '7d',
    rangeOptions: [
      { label: '今日', value: 'today' },
      { label: '近7天', value: '7d' },
      { label: '近30天', value: '30d' },
      { label: '全部', value: 'all' }
    ],

    dashboard: {
      orderCount: 0,
      completedRevenue: '0.00',
      expectedRevenue: '0.00',
      avgOrderValue: '0.00',
      activeUserCount: 0,
      repeatRate: '0.0',
      riskOrderCount: 0,
      cancelRate: '0.0',
      pendingFeedbackCount: 0,
      backlogCount: 0
    },

    compareCards: [
      {
        key: 'todayOrderCount',
        icon: '🧾',
        title: '今日订单',
        currentText: '0',
        compareText: '较昨日 持平',
        trend: 'flat'
      },
      {
        key: 'todayRevenue',
        icon: '💰',
        title: '今日营收',
        currentText: '￥0.00',
        compareText: '较昨日 持平',
        trend: 'flat'
      },
      {
        key: 'rangeOrderCount',
        icon: '📦',
        title: '当前范围订单',
        currentText: '0',
        compareText: '较上一周期 持平',
        trend: 'flat'
      },
      {
        key: 'rangeRevenue',
        icon: '📈',
        title: '当前范围营收',
        currentText: '￥0.00',
        compareText: '较上一周期 持平',
        trend: 'flat'
      }
    ],

    trendSummary: {
      totalRevenueText: '￥0.00',
      totalOrderText: '0 单',
      peakRevenueText: '暂无'
    },

    insightSummary: {
      rangeText: '近7天',
      topProductText: '暂无主推商品',
      topCategoryText: '暂无主力品类',
      peakTimeText: '暂无高峰时段',
      tasteText: '暂无偏好'
    },

    warnings: [],
    trendData: [],
    statusChartData: [],
    categoryChartData: [],
    hourlyData: [],
    pickupChartData: [],
    topProducts: [],
    repeatCustomers: [],
    pickupModes: [],
    sizePrefList: [],
    sweetPrefList: [],
    icePrefList: [],

    userQuery: '',
    userMatchedList: [],
    selectedUserKey: '',
    selectedUserProfile: null,
    selectedUserStats: null,

    ecTrend: {
      onInit: (canvas, width, height, dpr) => {
        trendChart = echarts.init(canvas, null, {
          width,
          height,
          devicePixelRatio: dpr
        });
        canvas.setChart(trendChart);
        if (pageRef) pageRef.renderCharts();
        return trendChart;
      }
    },

    ecStatus: {
      onInit: (canvas, width, height, dpr) => {
        statusChart = echarts.init(canvas, null, {
          width,
          height,
          devicePixelRatio: dpr
        });
        canvas.setChart(statusChart);
        if (pageRef) pageRef.renderCharts();
        return statusChart;
      }
    },

    ecCategory: {
      onInit: (canvas, width, height, dpr) => {
        categoryChart = echarts.init(canvas, null, {
          width,
          height,
          devicePixelRatio: dpr
        });
        canvas.setChart(categoryChart);
        if (pageRef) pageRef.renderCharts();
        return categoryChart;
      }
    },

    ecHourly: {
      onInit: (canvas, width, height, dpr) => {
        hourlyChart = echarts.init(canvas, null, {
          width,
          height,
          devicePixelRatio: dpr
        });
        canvas.setChart(hourlyChart);
        if (pageRef) pageRef.renderCharts();
        return hourlyChart;
      }
    },

    ecPickup: {
      onInit: (canvas, width, height, dpr) => {
        pickupChart = echarts.init(canvas, null, {
          width,
          height,
          devicePixelRatio: dpr
        });
        canvas.setChart(pickupChart);
        if (pageRef) pageRef.renderCharts();
        return pickupChart;
      }
    }
  },

  onLoad() {
    pageRef = this;
  },

  async onShow() {
    await this.refreshData();
  },

  async switchRange(e) {
    const range = e.currentTarget.dataset.range;

    this.setData({
      activeRange: range
    });

    await this.refreshData();
  },

  async refreshData() {
    try {
      const [orderRes, feedbackList] = await Promise.all([
        cloudOrder.listAllOrders(),
        cloudFeedback.syncAllFeedbackToLocal()
      ]);

      const ordersList = Array.isArray(orderRes.list) ? orderRes.list : (Array.isArray(orderRes.ordersList) ? orderRes.ordersList : []);
      const nextFeedbackList = Array.isArray(feedbackList) ? feedbackList : [];

      this.setData({
        ordersList,
        feedbackList: nextFeedbackList
      });

      if (this.data.userQuery) {
        this.searchUserCandidates(ordersList, nextFeedbackList);
      }

      const filteredOrders = this.filterOrdersByRange(ordersList, this.data.activeRange);
      const filteredFeedback = this.filterFeedbackByRange(nextFeedbackList, this.data.activeRange);

      this.buildDashboardData(filteredOrders, filteredFeedback, ordersList);
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '读取分析数据失败',
        icon: 'none'
      });
    }
  },

  filterOrdersByRange(orderList, range) {
    if (range === 'all') return orderList;

    const now = new Date();
    const start = new Date(now);

    if (range === 'today') {
      return orderList.filter(order => {
        const d = this.parseDate(order.createTime);
        return this.isSameDay(d, now);
      });
    }

    if (range === '7d') {
      start.setDate(now.getDate() - 6);
    }

    if (range === '30d') {
      start.setDate(now.getDate() - 29);
    }

    start.setHours(0, 0, 0, 0);

    return orderList.filter(order => {
      const d = this.parseDate(order.createTime);
      return d >= start && d <= now;
    });
  },

  filterFeedbackByRange(feedbackList, range) {
    if (range === 'all') return feedbackList;

    const now = new Date();
    const start = new Date(now);

    if (range === 'today') {
      return feedbackList.filter(item => {
        const d = this.parseDate(item.createTime);
        return this.isSameDay(d, now);
      });
    }

    if (range === '7d') {
      start.setDate(now.getDate() - 6);
    }

    if (range === '30d') {
      start.setDate(now.getDate() - 29);
    }

    start.setHours(0, 0, 0, 0);

    return feedbackList.filter(item => {
      const d = this.parseDate(item.createTime);
      return d >= start && d <= now;
    });
  },

  buildDashboardData(orderList, feedbackList, allOrders) {
    const dashboard = this.getDashboard(orderList, feedbackList);
    const trendData = this.getTrendData(orderList, this.data.activeRange);
    const trendSummary = this.getTrendSummary(trendData);
    const statusChartData = this.getStatusChartData(orderList);
    const categoryChartData = this.getCategoryChartData(orderList);
    const hourlyData = this.getHourlyData(orderList);
    const pickupModes = this.getPickupModes(orderList);
    const pickupChartData = pickupModes.map(item => ({
      name: item.label,
      value: item.count
    }));

    const topProducts = this.getTopProducts(orderList);
    const repeatCustomers = this.getRepeatCustomers(orderList);
    const sizePrefList = this.getPreferenceList(orderList, 'size');
    const sweetPrefList = this.getPreferenceList(orderList, 'sweet');
    const icePrefList = this.getPreferenceList(orderList, 'ice');
    const compareCards = this.getCompareCards(allOrders, this.data.activeRange);

    const peakHour = hourlyData.length
      ? [...hourlyData].sort((a, b) => b.orders - a.orders)[0]
      : null;

    const insightSummary = {
      rangeText: this.getRangeText(this.data.activeRange),
      topProductText: topProducts.length ? `主推：${topProducts[0].name}` : '暂无主推商品',
      topCategoryText: categoryChartData.length ? `主力：${categoryChartData[0].name}` : '暂无主力品类',
      peakTimeText: peakHour ? `高峰：${peakHour.label}` : '暂无高峰时段',
      tasteText: sweetPrefList.length ? `甜度：${sweetPrefList[0].label}` : '暂无偏好'
    };

    const warnings = this.getWarnings(
      dashboard,
      topProducts,
      peakHour,
      pickupModes
    );

    this.setData({
      dashboard,
      compareCards,
      trendSummary,
      trendData,
      statusChartData,
      categoryChartData,
      hourlyData,
      pickupChartData,
      topProducts,
      repeatCustomers,
      pickupModes,
      sizePrefList,
      sweetPrefList,
      icePrefList,
      insightSummary,
      warnings
    }, () => {
      this.renderCharts();
    });
  },


  getUserKey(record = {}) {
    return String(
      record.userOpenId ||
      record.creatorOpenId ||
      record.accountUsername ||
      ''
    );
  },

  getUserDisplayName(record = {}) {
    return (
      record.userDisplayName ||
      record.accountNickname ||
      record.accountUsername ||
      (record.creatorOpenId ? `用户${String(record.creatorOpenId).slice(-6)}` : '未知用户')
    );
  },

  onUserQueryInput(e) {
    const userQuery = String(e.detail.value || '').trim();
    this.setData({ userQuery }, () => {
      this.searchUserCandidates();
    });
  },

  clearUserQuery() {
    this.setData({
      userQuery: '',
      userMatchedList: [],
      selectedUserKey: '',
      selectedUserProfile: null,
      selectedUserStats: null
    });
  },

  searchUserCandidates(ordersListArg, feedbackListArg) {
    const query = String(this.data.userQuery || '').trim();
    const ordersList = Array.isArray(ordersListArg) ? ordersListArg : (this.data.ordersList || []);
    const feedbackList = Array.isArray(feedbackListArg) ? feedbackListArg : (this.data.feedbackList || []);

    if (!query) {
      this.setData({
        userMatchedList: [],
        selectedUserKey: '',
        selectedUserProfile: null,
        selectedUserStats: null
      });
      return;
    }

    const pool = [...ordersList, ...feedbackList];
    const map = {};

    pool.forEach(item => {
      const userKey = this.getUserKey(item);
      if (!userKey) return;

      const allText = `
        ${this.getUserDisplayName(item)}
        ${item.accountUsername || ''}
        ${item.accountNickname || ''}
        ${item.userOpenId || item.creatorOpenId || ''}
      `.trim();

      if (!allText.includes(query)) return;

      if (!map[userKey]) {
        map[userKey] = {
          userKey,
          userDisplayName: this.getUserDisplayName(item),
          accountUsername: item.accountUsername || '',
          accountNickname: item.accountNickname || '',
          userOpenId: item.userOpenId || item.creatorOpenId || ''
        };
      }
    });

    this.setData({
      userMatchedList: Object.values(map).slice(0, 20)
    });
  },

  chooseUserForAnalysis(e) {
    const userKey = String(e.currentTarget.dataset.userkey || '');
    this.buildSingleUserAnalysis(userKey);
  },

  buildSingleUserAnalysis(userKey) {
    const ordersList = this.data.ordersList || [];
    const feedbackList = this.data.feedbackList || [];

    const userOrders = ordersList.filter(item => this.getUserKey(item) === userKey);
    const userFeedback = feedbackList.filter(item => this.getUserKey(item) === userKey);
    const profileSource = userOrders[0] || userFeedback[0];

    if (!profileSource) {
      this.setData({
        selectedUserKey: '',
        selectedUserProfile: null,
        selectedUserStats: null
      });
      return;
    }

    const completedOrders = userOrders.filter(item => item.status === '已完成');
    const cancelledOrders = userOrders.filter(item => item.status === '已取消');
    const pendingOrders = userOrders.filter(item => ['待处理', '制作中', '待取餐'].includes(item.status));

    const totalSpent = completedOrders.reduce((sum, item) => {
      return sum + Number(item.payablePrice || item.totalPrice || 0);
    }, 0);

    const cupCount = userOrders.reduce((sum, order) => {
      const items = Array.isArray(order.items) ? order.items : [];
      return sum + items.reduce((n, item) => n + Number(item.quantity || 0), 0);
    }, 0);

    const favoriteMap = {};
    userOrders.forEach(order => {
      const items = Array.isArray(order.items) ? order.items : [];
      items.forEach(item => {
        const name = item.name || '未知商品';
        favoriteMap[name] = (favoriteMap[name] || 0) + Number(item.quantity || 0);
      });
    });

    const topProduct = Object.keys(favoriteMap)
      .map(name => ({ name, qty: favoriteMap[name] }))
      .sort((a, b) => b.qty - a.qty)[0] || null;

    this.setData({
      selectedUserKey: userKey,
      selectedUserProfile: {
        userDisplayName: this.getUserDisplayName(profileSource),
        accountUsername: profileSource.accountUsername || '',
        accountNickname: profileSource.accountNickname || '',
        userOpenId: profileSource.userOpenId || profileSource.creatorOpenId || ''
      },
      selectedUserStats: {
        totalOrders: userOrders.length,
        completedOrders: completedOrders.length,
        cancelledOrders: cancelledOrders.length,
        pendingOrders: pendingOrders.length,
        totalSpent: totalSpent.toFixed(2),
        avgOrderValue: completedOrders.length ? (totalSpent / completedOrders.length).toFixed(2) : '0.00',
        cupCount,
        feedbackCount: userFeedback.length,
        pendingFeedbackCount: userFeedback.filter(item => item.status !== '已处理').length,
        topProductText: topProduct ? `${topProduct.name} · ${topProduct.qty}杯` : '暂无'
      }
    });
  },

  renderCharts() {
    if (trendChart) {
      trendChart.clear();
      trendChart.setOption(getTrendOption(this.data.trendData), true);
    }

    if (statusChart) {
      statusChart.clear();
      statusChart.setOption(getStatusOption(this.data.statusChartData), true);
    }

    if (categoryChart) {
      categoryChart.clear();
      categoryChart.setOption(getCategoryOption(this.data.categoryChartData), true);
    }

    if (hourlyChart) {
      hourlyChart.clear();
      hourlyChart.setOption(getHourlyOption(this.data.hourlyData), true);
    }

    if (pickupChart) {
      pickupChart.clear();
      pickupChart.setOption(getPickupOption(this.data.pickupChartData), true);
    }
  },

  getTrendSummary(trendData) {
    if (!trendData.length) {
      return {
        totalRevenueText: '￥0.00',
        totalOrderText: '0 单',
        peakRevenueText: '暂无'
      };
    }

    const totalRevenue = trendData.reduce((sum, item) => sum + Number(item.revenue || 0), 0);
    const totalOrders = trendData.reduce((sum, item) => sum + Number(item.orders || 0), 0);
    const peakRevenueItem = [...trendData].sort((a, b) => b.revenue - a.revenue)[0];

    return {
      totalRevenueText: `￥${totalRevenue.toFixed(2)}`,
      totalOrderText: `${totalOrders} 单`,
      peakRevenueText: peakRevenueItem && peakRevenueItem.revenue > 0
        ? `${peakRevenueItem.label} · ￥${Number(peakRevenueItem.revenue).toFixed(2)}`
        : '暂无'
    };
  },

  getDashboard(orderList, feedbackList) {
    let completedRevenue = 0;
    let expectedRevenue = 0;
    let completedCount = 0;
    let cancelledCount = 0;
    let backlogCount = 0;
    let riskOrderCount = 0;
    const userMap = {};

    orderList.forEach(order => {
      const status = order.status || '';
      const payable = Number(order.payablePrice || order.totalPrice || 0);
      const createdAt = this.parseDate(order.createTime);
      const waitingMinutes = (Date.now() - createdAt.getTime()) / 60000;

      if (status !== '已取消') {
        expectedRevenue += payable;
      }

      if (status === '已完成') {
        completedCount += 1;
        completedRevenue += payable;
      }

      if (status === '已取消') {
        cancelledCount += 1;
      }

      if (status === '待处理' || status === '制作中' || status === '待取餐') {
        backlogCount += 1;
      }

      if (
        (status === '待处理' && waitingMinutes >= 20) ||
        (status === '制作中' && waitingMinutes >= 30) ||
        (status === '待取餐' && waitingMinutes >= 45)
      ) {
        riskOrderCount += 1;
      }

      const userKey = String(order.userId || order.accountUsername || order.openid || '');
      if (userKey && status !== '已取消') {
        userMap[userKey] = (userMap[userKey] || 0) + 1;
      }
    });

    const activeUserCount = Object.keys(userMap).length;
    const repeatUserCount = Object.values(userMap).filter(count => count >= 2).length;
    const repeatRate = activeUserCount > 0 ? ((repeatUserCount / activeUserCount) * 100) : 0;
    const cancelRate = orderList.length > 0 ? ((cancelledCount / orderList.length) * 100) : 0;
    const avgOrderValue = completedCount > 0 ? (completedRevenue / completedCount) : 0;
    const pendingFeedbackCount = (feedbackList || []).filter(item => item.status !== '已处理').length;

    return {
      orderCount: orderList.length,
      completedRevenue: completedRevenue.toFixed(2),
      expectedRevenue: expectedRevenue.toFixed(2),
      avgOrderValue: avgOrderValue.toFixed(2),
      activeUserCount,
      repeatRate: repeatRate.toFixed(1),
      riskOrderCount,
      cancelRate: cancelRate.toFixed(1),
      pendingFeedbackCount,
      backlogCount
    };
  },

  getCompareCards(allOrders, range) {
    const todayStats = this.calcRangeStats(allOrders, this.getTodayRange());
    const yesterdayStats = this.calcRangeStats(allOrders, this.getYesterdayRange());

    const currentRange = this.getRangeBounds(range);
    const previousRange = this.getPreviousRangeBounds(range);

    const currentStats = this.calcRangeStats(allOrders, currentRange);
    const previousStats = this.calcRangeStats(allOrders, previousRange);

    return [
      {
        key: 'todayOrderCount',
        icon: '🧾',
        title: '今日订单',
        currentText: String(todayStats.orderCount),
        compareText: this.buildCompareText('较昨日', todayStats.orderCount, yesterdayStats.orderCount),
        trend: this.getTrendType(todayStats.orderCount, yesterdayStats.orderCount)
      },
      {
        key: 'todayRevenue',
        icon: '💰',
        title: '今日营收',
        currentText: `￥${todayStats.completedRevenue.toFixed(2)}`,
        compareText: this.buildCompareText('较昨日', todayStats.completedRevenue, yesterdayStats.completedRevenue),
        trend: this.getTrendType(todayStats.completedRevenue, yesterdayStats.completedRevenue)
      },
      {
        key: 'rangeOrderCount',
        icon: '📦',
        title: '当前范围订单',
        currentText: String(currentStats.orderCount),
        compareText: this.buildCompareText('较上一周期', currentStats.orderCount, previousStats.orderCount),
        trend: this.getTrendType(currentStats.orderCount, previousStats.orderCount)
      },
      {
        key: 'rangeRevenue',
        icon: '📈',
        title: '当前范围营收',
        currentText: `￥${currentStats.completedRevenue.toFixed(2)}`,
        compareText: this.buildCompareText('较上一周期', currentStats.completedRevenue, previousStats.completedRevenue),
        trend: this.getTrendType(currentStats.completedRevenue, previousStats.completedRevenue)
      }
    ];
  },

  calcRangeStats(allOrders, rangeObj) {
    if (!rangeObj) {
      return {
        orderCount: 0,
        completedRevenue: 0
      };
    }

    const { start, end } = rangeObj;

    const list = allOrders.filter(order => {
      const d = this.parseDate(order.createTime);
      return d >= start && d <= end;
    });

    let completedRevenue = 0;
    list.forEach(order => {
      if (order.status === '已完成') {
        completedRevenue += Number(order.payablePrice || order.totalPrice || 0);
      }
    });

    return {
      orderCount: list.length,
      completedRevenue
    };
  },

  getTodayRange() {
    const now = new Date();
    const start = new Date(now);
    start.setHours(0, 0, 0, 0);
    return {
      start,
      end: now
    };
  },

  getYesterdayRange() {
    const now = new Date();
    const start = new Date(now);
    start.setDate(now.getDate() - 1);
    start.setHours(0, 0, 0, 0);

    const end = new Date(start);
    end.setHours(23, 59, 59, 999);

    return { start, end };
  },

  getRangeBounds(range) {
    const now = new Date();

    if (range === 'today') {
      const start = new Date(now);
      start.setHours(0, 0, 0, 0);
      return { start, end: now };
    }

    if (range === '7d') {
      const start = new Date(now);
      start.setDate(now.getDate() - 6);
      start.setHours(0, 0, 0, 0);
      return { start, end: now };
    }

    if (range === '30d') {
      const start = new Date(now);
      start.setDate(now.getDate() - 29);
      start.setHours(0, 0, 0, 0);
      return { start, end: now };
    }

    return null;
  },

  getPreviousRangeBounds(range) {
    const now = new Date();

    if (range === 'today') {
      return this.getYesterdayRange();
    }

    if (range === '7d') {
      const end = new Date(now);
      end.setDate(now.getDate() - 7);
      end.setHours(23, 59, 59, 999);

      const start = new Date(end);
      start.setDate(end.getDate() - 6);
      start.setHours(0, 0, 0, 0);

      return { start, end };
    }

    if (range === '30d') {
      const end = new Date(now);
      end.setDate(now.getDate() - 30);
      end.setHours(23, 59, 59, 999);

      const start = new Date(end);
      start.setDate(end.getDate() - 29);
      start.setHours(0, 0, 0, 0);

      return { start, end };
    }

    return null;
  },

  buildCompareText(prefix, current, previous) {
    if (previous === 0) {
      if (current === 0) return `${prefix} 持平`;
      return `${prefix} 新增`;
    }

    const diff = ((current - previous) / previous) * 100;
    const sign = diff > 0 ? '+' : '';
    return `${prefix} ${sign}${diff.toFixed(1)}%`;
  },

  getTrendType(current, previous) {
    if (current > previous) return 'up';
    if (current < previous) return 'down';
    return 'flat';
  },

  getTrendData(orderList, range) {
    if (!orderList.length) return [];

    if (range === 'today') {
      const hourMap = {};
      for (let i = 8; i <= 22; i += 1) {
        const key = `${this.addZero(i)}:00`;
        hourMap[key] = {
          label: key,
          orders: 0,
          revenue: 0
        };
      }

      orderList.forEach(order => {
        const d = this.parseDate(order.createTime);
        const key = `${this.addZero(d.getHours())}:00`;

        if (hourMap[key]) {
          hourMap[key].orders += 1;
          if (order.status === '已完成') {
            hourMap[key].revenue += Number(order.payablePrice || order.totalPrice || 0);
          }
        }
      });

      return Object.keys(hourMap).map(key => ({
        label: hourMap[key].label,
        orders: hourMap[key].orders,
        revenue: Number(hourMap[key].revenue.toFixed(2))
      }));
    }

    const dayMap = {};

    orderList.forEach(order => {
      const d = this.parseDate(order.createTime);
      const key = this.getDateKey(d);

      if (!dayMap[key]) {
        dayMap[key] = {
          label: key.slice(5),
          sortKey: key,
          orders: 0,
          revenue: 0
        };
      }

      dayMap[key].orders += 1;
      if (order.status === '已完成') {
        dayMap[key].revenue += Number(order.payablePrice || order.totalPrice || 0);
      }
    });

    return Object.values(dayMap)
      .sort((a, b) => a.sortKey.localeCompare(b.sortKey))
      .map(item => ({
        label: item.label,
        orders: item.orders,
        revenue: Number(item.revenue.toFixed(2))
      }));
  },

  getStatusChartData(orderList) {
    const statusMap = {
      待处理: 0,
      制作中: 0,
      待取餐: 0,
      已完成: 0,
      已取消: 0
    };

    orderList.forEach(order => {
      const status = order.status || '';
      if (Object.prototype.hasOwnProperty.call(statusMap, status)) {
        statusMap[status] += 1;
      }
    });

    return Object.keys(statusMap).map(name => ({
      name,
      value: statusMap[name]
    }));
  },

  getCategoryChartData(orderList) {
    const categoryMap = {};

    orderList.forEach(order => {
      if (order.status === '已取消') return;

      const items = Array.isArray(order.items) ? order.items : [];
      items.forEach(item => {
        const category = item.category || '未分类';
        const amount = Number(item.price || 0) * Number(item.quantity || 0);

        if (!categoryMap[category]) {
          categoryMap[category] = {
            name: category,
            revenue: 0,
            cups: 0
          };
        }

        categoryMap[category].revenue += amount;
        categoryMap[category].cups += Number(item.quantity || 0);
      });
    });

    return Object.values(categoryMap)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 6)
      .map(item => ({
        ...item,
        revenue: Number(item.revenue.toFixed(2))
      }));
  },

  getHourlyData(orderList) {
    const hourMap = {};
    for (let i = 8; i <= 22; i += 1) {
      const label = `${this.addZero(i)}:00`;
      hourMap[label] = {
        label,
        orders: 0
      };
    }

    orderList.forEach(order => {
      const d = this.parseDate(order.createTime);
      const label = `${this.addZero(d.getHours())}:00`;

      if (hourMap[label]) {
        hourMap[label].orders += 1;
      }
    });

    return Object.keys(hourMap).map(key => hourMap[key]);
  },

  getTopProducts(orderList) {
    const productMap = {};

    orderList.forEach(order => {
      if (order.status === '已取消') return;

      const items = Array.isArray(order.items) ? order.items : [];
      items.forEach(item => {
        const name = item.name || '未知商品';
        const qty = Number(item.quantity || 0);
        const amount = Number(item.price || 0) * qty;

        if (!productMap[name]) {
          productMap[name] = {
            name,
            qty: 0,
            amount: 0
          };
        }

        productMap[name].qty += qty;
        productMap[name].amount += amount;
      });
    });

    return Object.values(productMap)
      .sort((a, b) => b.qty - a.qty)
      .slice(0, 6)
      .map((item, index) => ({
        rank: index + 1,
        name: item.name,
        qty: item.qty,
        amount: item.amount.toFixed(2)
      }));
  },

  getRepeatCustomers(orderList) {
    const customerMap = {};

    orderList.forEach(order => {
      if (order.status === '已取消') return;

      const userKey = String(order.userId || order.accountUsername || order.openid || '');
      const displayName = order.accountNickname || order.accountUsername || `用户${userKey.slice(-4)}`;
      const payable = Number(order.payablePrice || order.totalPrice || 0);

      if (!userKey) return;

      if (!customerMap[userKey]) {
        customerMap[userKey] = {
          name: displayName,
          count: 0,
          revenue: 0
        };
      }

      customerMap[userKey].count += 1;
      customerMap[userKey].revenue += payable;
    });

    return Object.values(customerMap)
      .filter(item => item.count >= 2)
      .sort((a, b) => {
        if (b.count !== a.count) return b.count - a.count;
        return b.revenue - a.revenue;
      })
      .slice(0, 5)
      .map((item, index) => ({
        rank: index + 1,
        name: item.name,
        count: item.count,
        revenue: item.revenue.toFixed(2)
      }));
  },

  getPickupModes(orderList) {
    const modeMap = {
      立即自取: 0,
      预约取单: 0
    };

    orderList.forEach(order => {
      if (order.status === '已取消') return;
      const mode = order.pickupMode === '预约取单' ? '预约取单' : '立即自取';
      modeMap[mode] += 1;
    });

    const total = modeMap['立即自取'] + modeMap['预约取单'] || 1;

    return [
      {
        icon: '⚡',
        label: '立即自取',
        count: modeMap['立即自取'],
        percent: ((modeMap['立即自取'] / total) * 100).toFixed(1)
      },
      {
        icon: '🗓️',
        label: '预约取单',
        count: modeMap['预约取单'],
        percent: ((modeMap['预约取单'] / total) * 100).toFixed(1)
      }
    ];
  },

  getPreferenceList(orderList, field) {
    const map = {};

    orderList.forEach(order => {
      if (order.status === '已取消') return;

      const items = Array.isArray(order.items) ? order.items : [];
      items.forEach(item => {
        const qty = Number(item.quantity || 0);
        let label = '未设置';

        if (field === 'size') label = item.size || '未设置';
        if (field === 'sweet') label = item.sweet || '未设置';
        if (field === 'ice') label = item.ice || '未设置';

        map[label] = (map[label] || 0) + qty;
      });
    });

    const total = Object.values(map).reduce((sum, n) => sum + n, 0) || 1;

    return Object.keys(map)
      .map(label => {
        const count = map[label];
        return {
          label,
          count,
          percent: ((count / total) * 100).toFixed(1),
          width: `${Math.max((count / total) * 100, count > 0 ? 8 : 0)}%`
        };
      })
      .sort((a, b) => b.count - a.count)
      .slice(0, 6);
  },

  getWarnings(dashboard, topProducts, peakHour, pickupModes) {
    const warnings = [];

    if (dashboard.riskOrderCount >= 2) {
      warnings.push({
        type: 'warning',
        icon: '⏱️',
        title: '存在超时风险订单',
        text: `当前有 ${dashboard.riskOrderCount} 单等待时间偏长，建议优先处理积压订单。`
      });
    }

    if (Number(dashboard.cancelRate) >= 15) {
      warnings.push({
        type: 'warning',
        icon: '⚠️',
        title: '取消率偏高',
        text: `当前取消率为 ${dashboard.cancelRate}% ，建议复查高峰时段出餐节奏和商品可售状态。`
      });
    }

    if (dashboard.pendingFeedbackCount >= 3) {
      warnings.push({
        type: 'info',
        icon: '💬',
        title: '待处理反馈较多',
        text: `当前有 ${dashboard.pendingFeedbackCount} 条反馈未处理，建议尽快跟进。`
      });
    }

    if (peakHour && peakHour.orders > 0) {
      warnings.push({
        type: 'info',
        icon: '📈',
        title: '高峰时段建议',
        text: `${peakHour.label} 为当前最高峰时段，建议提前备料并提升该时段出杯效率。`
      });
    }

    if (topProducts.length > 0) {
      warnings.push({
        type: 'good',
        icon: '🔥',
        title: '主推商品建议',
        text: `${topProducts[0].name} 当前销量领先，适合继续放在首页推荐位或做组合促销。`
      });
    }

    if (!warnings.length) {
      warnings.push({
        type: 'good',
        icon: '✅',
        title: '当前经营状态平稳',
        text: '目前没有明显异常，可继续关注热销商品、复购用户和时段分布。'
      });
    }

    return warnings.slice(0, 5);
  },

  getRangeText(range) {
    if (range === 'today') return '今日';
    if (range === '7d') return '近7天';
    if (range === '30d') return '近30天';
    return '全部范围';
  },

  parseDate(str) {
    if (!str) return new Date();
    if (str instanceof Date) return str;
    return new Date(String(str).replace(/-/g, '/'));
  },

  isSameDay(date1, date2) {
    return (
      date1.getFullYear() === date2.getFullYear() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getDate() === date2.getDate()
    );
  },

  getDateKey(date) {
    const y = date.getFullYear();
    const m = this.addZero(date.getMonth() + 1);
    const d = this.addZero(date.getDate());
    return `${y}-${m}-${d}`;
  },

  addZero(n) {
    return n < 10 ? `0${n}` : `${n}`;
  },

  goWorkbench() {
    wx.redirectTo({
      url: '/pages/admin/admin'
    });
  }
});