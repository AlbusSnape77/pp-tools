const cloudOrder = require('../../utils/cloud-order');

Page({
  data: {
    ordersList: [],
    filteredOrders: [],
    activeStatus: '全部',
    activeVerifyStatus: '全部',
    keyword: '',
    verifyCode: '',
    statusTabs: ['全部', '待处理', '制作中', '待取餐', '已完成', '已取消'],
    verifyTabs: ['全部', '未核销', '已核销'],
    summary: {
      all: 0,
      pending: 0,
      making: 0,
      ready: 0,
      completed: 0,
      cancelled: 0,
      unverified: 0,
      verified: 0
    }
  },

  async onShow() {
    await this.getOrdersList();
  },

  async getOrdersList() {
    try {
      const res = await cloudOrder.listAllOrders();
      let ordersList = Array.isArray(res.list) ? res.list : (Array.isArray(res.ordersList) ? res.ordersList : []);
      ordersList = this.normalizeOrdersList(ordersList);

      this.setData({
        ordersList
      });

      this.calculateSummary();
      this.filterOrders();
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '读取订单失败',
        icon: 'none'
      });
    }
  },

  normalizeOrdersList(list) {
    const normalized = (list || []).map(order => {
      const items = Array.isArray(order.items) ? order.items : [];
      const itemCount = items.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
      const itemPreview = items.length
        ? items.slice(0, 3).map(item => `${item.name} x${item.quantity || 0}`).join('、')
        : '暂无商品';

      const normalizedItems = items.map(item => {
        const specList = [
          item.size ? item.size : '',
          item.sweet ? item.sweet : '',
          item.ice ? item.ice : ''
        ].filter(Boolean);

        return {
          ...item,
          priceText: Number(item.price || 0).toFixed(2),
          subtotalText: (Number(item.price || 0) * Number(item.quantity || 0)).toFixed(2),
          specText: specList.join(' / '),
          toppingText: item.toppingsText || '不加小料',
          toppingModeText: item.toppingModeText || '无'
        };
      });

      const remarkText = String(order.remark || '').trim();
      const userDisplayName =
        order.userDisplayName ||
        order.accountNickname ||
        order.accountUsername ||
        (order.userOpenId || order.creatorOpenId ? `用户${String(order.userOpenId || order.creatorOpenId).slice(-6)}` : '未知用户');
      const userAccountText = order.accountUsername || '未绑定账号名';
      const userNicknameText = order.accountNickname || '未设置昵称';
      const userOpenIdText = order.userOpenId || order.creatorOpenId || '';
      const pickupModeText = order.pickupModeText || order.pickupMode || '立即自取';
      const couponText = order.couponText || '未使用优惠';
      const id = Number(order.id || order._id || 0);
      const verifyStatusText = this.getVerifyStatusText(order);

      return {
        ...order,
        id,
        items: normalizedItems,
        itemCount,
        itemPreview,
        remarkText,
        hasRemark: !!remarkText,
        pickupCode: order.pickupCode || String(order.orderNo || order.id || '').slice(-4),
        totalPriceText: Number(order.totalPrice || 0).toFixed(2),
        payablePriceText: Number(order.payablePrice || order.totalPrice || 0).toFixed(2),
        discountAmountText: Number(order.discountAmount || 0).toFixed(2),
        statusClass: this.getStatusClass(order.status),
        verifyStatusText,
        verifyStatusClass: this.getVerifyStatusClass(verifyStatusText),
        canVerify: order.status === '待取餐' && verifyStatusText !== '已核销',
        pickupModeText,
        couponText,
        userDisplayName,
        userAccountText,
        userNicknameText,
        userOpenIdText,
        createTimestamp: Number(order.createTimestamp || order.id || 0),
        verifyTimestamp: Number(order.verifyTimestamp || 0)
      };
    });

    return this.sortOrdersList(normalized);
  },

  getStatusClass(status) {
    if (status === '待处理') return 'status-pending';
    if (status === '制作中') return 'status-making';
    if (status === '待取餐') return 'status-ready';
    if (status === '已完成') return 'status-finished';
    return 'status-cancelled';
  },

  getVerifyStatusText(order = {}) {
    const verifyStatus = String(order.verifyStatus || '').trim();
    if (verifyStatus === '已核销') return '已核销';
    if (String(order.status || '').trim() === '已完成') return '已核销';
    if (String(order.verifyTime || '').trim()) return '已核销';
    return '未核销';
  },

  getVerifyStatusClass(status) {
    return status === '已核销' ? 'verify-badge-verified' : 'verify-badge-unverified';
  },

  sortOrdersList(list = []) {
    return (list || []).slice().sort((a, b) => {
      const verifyWeightA = a.verifyStatusText === '已核销' ? 1 : 0;
      const verifyWeightB = b.verifyStatusText === '已核销' ? 1 : 0;

      if (verifyWeightA !== verifyWeightB) {
        return verifyWeightA - verifyWeightB;
      }

      const timeA = Number(a.createTimestamp || a.id || 0);
      const timeB = Number(b.createTimestamp || b.id || 0);
      if (timeA !== timeB) {
        return timeB - timeA;
      }

      return Number(b.id || 0) - Number(a.id || 0);
    });
  },

  calculateSummary() {
    const ordersList = this.data.ordersList || [];

    let all = ordersList.length;
    let pending = 0;
    let making = 0;
    let ready = 0;
    let completed = 0;
    let cancelled = 0;
    let unverified = 0;
    let verified = 0;

    ordersList.forEach(order => {
      if (order.status === '待处理') pending += 1;
      if (order.status === '制作中') making += 1;
      if (order.status === '待取餐') ready += 1;
      if (order.status === '已完成') completed += 1;
      if (order.status === '已取消') cancelled += 1;
      if (order.verifyStatusText === '已核销') {
        verified += 1;
      } else {
        unverified += 1;
      }
    });

    this.setData({
      summary: {
        all,
        pending,
        making,
        ready,
        completed,
        cancelled,
        unverified,
        verified
      }
    });
  },

  chooseStatus(e) {
    const status = e.currentTarget.dataset.status;

    this.setData({
      activeStatus: status
    });

    this.filterOrders();
  },

  chooseVerifyStatus(e) {
    const status = e.currentTarget.dataset.status || '全部';

    this.setData({
      activeVerifyStatus: status
    });

    this.filterOrders();
  },

  onSearchInput(e) {
    this.setData({
      keyword: e.detail.value || ''
    });

    this.filterOrders();
  },

  onVerifyCodeInput(e) {
    this.setData({
      verifyCode: e.detail.value || ''
    });
  },

  clearSearch() {
    this.setData({
      keyword: ''
    });

    this.filterOrders();
  },

  filterOrders() {
    const { activeStatus, activeVerifyStatus, keyword, ordersList } = this.data;
    const text = String(keyword || '').trim();

    let filteredOrders = ordersList;

    if (activeStatus !== '全部') {
      filteredOrders = filteredOrders.filter(order => order.status === activeStatus);
    }

    if (activeVerifyStatus !== '全部') {
      filteredOrders = filteredOrders.filter(order => order.verifyStatusText === activeVerifyStatus);
    }

    if (text) {
      filteredOrders = filteredOrders.filter(order => {
        const allText = `
          ${order.orderNo || ''}
          ${(order.items || []).map(item => item.name || '').join(' ')}
          ${order.remarkText || ''}
          ${order.pickupCode || ''}
          ${order.userDisplayName || ''}
          ${order.userAccountText || ''}
          ${order.userNicknameText || ''}
          ${order.userOpenIdText || ''}
          ${order.verifyStatusText || ''}
        `.trim();
        return allText.includes(text);
      });
    }

    this.setData({
      filteredOrders: this.sortOrdersList(filteredOrders)
    });
  },

  async updateStatus(e) {
    const id = Number(e.currentTarget.dataset.id);
    const status = String(e.currentTarget.dataset.status || '').trim();

    if (!id || !status) {
      wx.showToast({
        title: '参数异常',
        icon: 'none'
      });
      return;
    }

    try {
      await cloudOrder.adminUpdateStatus(id, status);

      wx.showToast({
        title: '状态已更新',
        icon: 'success'
      });

      await this.getOrdersList();
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '更新失败',
        icon: 'none'
      });
    }
  },

  async verifyOrderByCard(e) {
    const id = Number(e.currentTarget.dataset.id);
    const order = (this.data.ordersList || []).find(item => Number(item.id) === id);

    if (!order || order.status !== '待取餐') {
      wx.showToast({
        title: '当前订单不可核销',
        icon: 'none'
      });
      return;
    }

    try {
      await cloudOrder.adminVerifyByCode(order.pickupCode);

      wx.showToast({
        title: '核销完成',
        icon: 'success'
      });

      await this.getOrdersList();
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '核销失败',
        icon: 'none'
      });
    }
  },

  async verifyByCode() {
    const code = String(this.data.verifyCode || '').trim();

    if (!code) {
      wx.showToast({
        title: '请输入取餐码',
        icon: 'none'
      });
      return;
    }

    try {
      await cloudOrder.adminVerifyByCode(code);

      this.setData({
        verifyCode: ''
      });

      wx.showToast({
        title: '核销完成',
        icon: 'success'
      });

      await this.getOrdersList();
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '核销失败',
        icon: 'none'
      });
    }
  },

  goWorkbench() {
    wx.redirectTo({
      url: '/pages/admin/admin'
    });
  }
});