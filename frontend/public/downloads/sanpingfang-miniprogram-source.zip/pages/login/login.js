const cloudAuth = require('../../utils/cloud-auth');
const cloudShop = require('../../utils/cloud-shop');
const cloudFile = require('../../utils/cloud-file');

const STORE_VISUAL_REFRESH_INTERVAL = 5 * 60 * 1000;
const STORE_VISUAL_REFRESH_KEY = 'loginStoreVisualLastSyncAt';

Page({
  data: {
    roleList: [
      {
        key: 'user',
        title: '用户入口',
        desc: '支持注册账号与密码，登录后进入点单系统'
      },
      {
        key: 'admin',
        title: '管理员入口',
        desc: '使用管理员账号密码进入门店后台'
      }
    ],
    activeRole: 'user',
    userAction: 'login',
    username: '',
    password: '',
    nickname: '',
    loading: false,
    passwordVisible: false,
    storeLogo: '',
    storeLogoDisplay: '',
    storeCover: '',
    storeCoverDisplay: ''
  },

  onLoad() {
    this.syncStoreVisualFromLocal();
  },

  onShow() {
    const app = getApp();
    const authInfo = app.getAuthInfo ? app.getAuthInfo() : null;

    if (authInfo && authInfo.role) {
      app.routeAfterLogin(authInfo.role);
      return;
    }

    this.syncStoreVisualFromLocal();
    this.ensureStoreVisualFresh();
  },

  syncStoreVisualFromLocal() {
    const config = wx.getStorageSync('storeStatusConfig') || {};
    this.applyStoreVisual(config).catch(err => {
      console.error('登录页读取本地门店图片失败', err);
    });
  },

  ensureStoreVisualFresh(force = false) {
    const lastSyncAt = Number(wx.getStorageSync(STORE_VISUAL_REFRESH_KEY) || 0);
    const hasLocalVisual = !!(this.data.storeLogo || this.data.storeLogoDisplay || this.data.storeCover || this.data.storeCoverDisplay);

    if (!force && this._storeVisualPromise) {
      return this._storeVisualPromise;
    }

    if (!force && hasLocalVisual && Date.now() - lastSyncAt < STORE_VISUAL_REFRESH_INTERVAL) {
      return Promise.resolve();
    }

    this._storeVisualPromise = this.loadStoreVisual(force)
      .catch(err => {
        console.error('登录页刷新门店图片失败', err);
      })
      .finally(() => {
        this._storeVisualPromise = null;
      });

    return this._storeVisualPromise;
  },

  async loadStoreVisual(force = false) {
    const lastSyncAt = Number(wx.getStorageSync(STORE_VISUAL_REFRESH_KEY) || 0);
    const hasLocalVisual = !!(this.data.storeLogo || this.data.storeLogoDisplay || this.data.storeCover || this.data.storeCoverDisplay);

    if (!force && hasLocalVisual && Date.now() - lastSyncAt < STORE_VISUAL_REFRESH_INTERVAL) {
      return;
    }

    const res = await cloudShop.getStoreConfig();
    const config = (res && res.config) || {};
    await this.applyStoreVisual(config);
    wx.setStorageSync(STORE_VISUAL_REFRESH_KEY, Date.now());
  },

  async applyStoreVisual(config = {}) {
    const mediaConfig = await cloudFile.attachDisplayUrls({
      storeLogo: config.storeLogo || '',
      storeCover: config.storeCover || ''
    }, ['storeLogo', 'storeCover'], {
      preferTempUrl: true
    });

    this.setData({
      storeLogo: mediaConfig.storeLogo || '',
      storeLogoDisplay: mediaConfig.storeLogoDisplay || '',
      storeCover: mediaConfig.storeCover || '',
      storeCoverDisplay: mediaConfig.storeCoverDisplay || ''
    });
  },

  chooseRole(e) {
    const role = e.currentTarget.dataset.role || 'user';

    this.setData({
      activeRole: role,
      userAction: 'login',
      username: '',
      password: '',
      nickname: ''
    });
  },

  chooseUserAction(e) {
    const action = e.currentTarget.dataset.action || 'login';

    this.setData({
      userAction: action,
      username: '',
      password: '',
      nickname: ''
    });
  },

  onUsernameInput(e) {
    this.setData({
      username: (e.detail.value || '').trim()
    });
  },

  onPasswordInput(e) {
    this.setData({
      password: e.detail.value || ''
    });
  },

  onNicknameInput(e) {
    this.setData({
      nickname: (e.detail.value || '').trim()
    });
  },

  togglePasswordVisible() {
    this.setData({
      passwordVisible: !this.data.passwordVisible
    });
  },

  async submitLogin() {
    if (this.data.loading) return;

    const { activeRole, userAction } = this.data;
    const username = this.data.username.trim();
    const password = this.data.password;
    const nickname = this.data.nickname.trim();

    if (activeRole === 'admin') {
      if (!username) {
        wx.showToast({ title: '请输入管理员账号', icon: 'none' });
        return;
      }
      if (!password) {
        wx.showToast({ title: '请输入管理员密码', icon: 'none' });
        return;
      }
    } else {
      if (userAction === 'register') {
        if (!nickname) {
          wx.showToast({ title: '请输入昵称', icon: 'none' });
          return;
        }
        if (username.length < 3) {
          wx.showToast({ title: '用户账号至少 3 位', icon: 'none' });
          return;
        }
        if (password.length < 6) {
          wx.showToast({ title: '用户密码至少 6 位', icon: 'none' });
          return;
        }
      } else {
        if (!username) {
          wx.showToast({ title: '请输入用户账号', icon: 'none' });
          return;
        }
        if (!password) {
          wx.showToast({ title: '请输入用户密码', icon: 'none' });
          return;
        }
      }
    }

    this.setData({ loading: true });

    try {
      let res;
      if (activeRole === 'admin') {
        res = await cloudAuth.adminEntry(username, password);
      } else if (userAction === 'register') {
        res = await cloudAuth.userRegister(username, password, nickname);
      } else {
        res = await cloudAuth.userLogin(username, password);
      }

      const authInfo = res.authInfo || {};
      const app = getApp();
      if (app.setAuthInfo) {
        app.setAuthInfo(authInfo);
      } else {
        wx.setStorageSync('authInfo', authInfo);
      }

      wx.showToast({
        title: userAction === 'register' && activeRole === 'user' ? '注册成功' : '登录成功',
        icon: 'success'
      });

      if (app.routeAfterLogin) {
        app.routeAfterLogin(authInfo.role);
      }
    } catch (err) {
      wx.showToast({ title: (err && err.message) || '操作失败', icon: 'none' });
    } finally {
      this.setData({ loading: false });
    }
  }
});
