const cloudOrder = require('../../utils/cloud-order');
const cloudUser = require('../../utils/cloud-user');
const cloudShop = require('../../utils/cloud-shop');
const cloudProduct = require('../../utils/cloud-product');
const productState = require('../../utils/product-state');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    viewModeTabs: ['确认下单', '历史订单'],
    activeViewMode: '确认下单',

    checkoutCartList: [],
    checkoutTotalPrice: '0.00',
    checkoutTotalCount: 0,
    checkoutTypeCount: 0,
    discountAmount: '0.00',
    payablePrice: '0.00',

    ordersList: [],
    filteredOrders: [],

    activeTab: '全部',
    orderTabs: ['全部', '进行中', '已完成', '已取消'],

    orderRemark: '',
    remarkCount: 0,
    remarkMaxLength: 40,
    remarkQuickList: [
      '少冰但别太淡',
      '珍珠分开装',
      '马上来取',
      '不要太甜',
      '请尽快制作'
    ],

    pickupModeList: ['立即自取', '预约取单'],
    activePickupMode: '立即自取',

    reserveDateOptions: [],
    reserveDate: '',
    reserveDateLabel: '',
    reserveTime: '',

    couponList: [],
    selectedCouponId: '',
    selectedCouponText: '未使用优惠',

    storeStatus: 'open',
    storeStatusText: '营业中',
    storeStatusDesc: '当前可正常下单',
    storeCanSubmitOrder: true,
    canSubmitOrder: true,
    submitActionText: '提交订单'
  },

  async onShow() {
    try {
      await Promise.all([
        cloudShop.syncShopStateToLocal(),
        cloudProduct.listProducts()
      ]);
    } catch (err) {
      console.error('订单页同步商品与门店状态失败', err);
    }

    this.syncStoreStatus();
    this.initReserveOptions();
    await this.getPageData();
    this.loadCouponData();
  },

  switchViewMode(e) {
    const value = e.currentTarget.dataset.value || '确认下单';
    this.setData({
      activeViewMode: value
    });
  },

  syncStoreStatus() {
    const config = wx.getStorageSync('storeStatusConfig') || {};
    const status = config.status || 'open';

    if (status === 'pause') {
      this.setData({
        storeStatus: 'pause',
        storeStatusText: '暂停接单',
        storeStatusDesc: '门店当前暂停接单，请稍后再试',
        storeCanSubmitOrder: false,
        canSubmitOrder: false,
        submitActionText: '暂停接单'
      });
      return;
    }

    if (status === 'closed') {
      this.setData({
        storeStatus: 'closed',
        storeStatusText: '已打烊',
        storeStatusDesc: '门店当前已打烊，暂时无法下单',
        storeCanSubmitOrder: false,
        canSubmitOrder: false,
        submitActionText: '已打烊'
      });
      return;
    }

    this.setData({
      storeStatus: 'open',
      storeStatusText: '营业中',
      storeStatusDesc: '当前可正常下单',
      storeCanSubmitOrder: true,
      canSubmitOrder: true,
      submitActionText: '提交订单'
    });
  },

  initReserveOptions() {
    const today = new Date();
    const tomorrow = this.addDays(today, 1);
    const dayAfterTomorrow = this.addDays(today, 2);

    const reserveDateOptions = [
      { label: '今天', value: this.formatDate(today) },
      { label: '明天', value: this.formatDate(tomorrow) },
      { label: '后天', value: this.formatDate(dayAfterTomorrow) }
    ];

    const suggested = this.getSuggestedReserveSelection();

    this.setData({
      reserveDateOptions,
      reserveDate: this.data.reserveDate || suggested.date,
      reserveDateLabel: this.data.reserveDateLabel || suggested.label,
      reserveTime: this.data.reserveTime || suggested.time
    });
  },

  getSuggestedReserveSelection() {
    const now = new Date();
    const next = new Date(now.getTime() + 10 * 60 * 1000);

    let hour = next.getHours();
    let minute = next.getMinutes();
    minute = Math.ceil(minute / 10) * 10;

    if (minute >= 60) {
      hour += 1;
      minute = 0;
      next.setHours(hour);
    }

    next.setMinutes(minute, 0, 0);

    return {
      date: this.formatDate(next),
      label: '今天',
      time: this.formatHM(next)
    };
  },

  chooseReserveDate(e) {
    const value = e.currentTarget.dataset.value;
    const label = e.currentTarget.dataset.label;

    this.setData({
      reserveDate: value,
      reserveDateLabel: label
    });

    wx.setStorageSync('checkoutReserveDate', value);
    wx.setStorageSync('checkoutReserveDateLabel', label);

    if (!this.validateReserveDateTime(value, this.data.reserveTime) && label === '今天') {
      const suggested = this.getSuggestedReserveSelection();
      this.setData({
        reserveTime: suggested.time
      });
      wx.setStorageSync('checkoutReserveTime', suggested.time);
    }
  },

  onReserveTimeChange(e) {
    const value = e.detail.value || this.data.reserveTime;
    const reserveDate = this.data.reserveDate;

    if (!this.validateReserveDateTime(reserveDate, value)) {
      wx.showToast({
        title: '预约时间必须晚于当前时间',
        icon: 'none'
      });

      if (this.data.reserveDateLabel === '今天') {
        const suggested = this.getSuggestedReserveSelection();
        this.setData({
          reserveTime: suggested.time
        });
        wx.setStorageSync('checkoutReserveTime', suggested.time);
      }
      return;
    }

    this.setData({
      reserveTime: value
    });

    wx.setStorageSync('checkoutReserveTime', value);
  },

  formatDate(date) {
    const y = date.getFullYear();
    const m = this.addZero(date.getMonth() + 1);
    const d = this.addZero(date.getDate());
    return `${y}-${m}-${d}`;
  },

  formatHM(date) {
    const h = this.addZero(date.getHours());
    const m = this.addZero(date.getMinutes());
    return `${h}:${m}`;
  },

  addDays(date, days) {
    const d = new Date(date);
    d.setDate(d.getDate() + days);
    return d;
  },

  validateReserveDateTime(dateStr, timeStr) {
    if (!dateStr || !timeStr) return false;
    const selected = new Date(`${dateStr}T${timeStr}:00`);
    return selected.getTime() > Date.now();
  },

  getDefaultCouponList() {
    return [
      {
        id: 'new-3',
        title: '新人立减 3 元',
        desc: '首单可用',
        type: 'new_user',
        threshold: 0,
        minus: 3
      },
      {
        id: 'full-25-2',
        title: '满 25 减 2',
        desc: '订单满 25 元可用',
        type: 'full_reduce',
        threshold: 25,
        minus: 2
      },
      {
        id: 'full-40-5',
        title: '满 40 减 5',
        desc: '订单满 40 元可用',
        type: 'full_reduce',
        threshold: 40,
        minus: 5
      }
    ];
  },

  loadCouponData() {
    const allCoupons = wx.getStorageSync('couponList') || this.getDefaultCouponList();
    const ordersList = this.data.ordersList || [];
    const isNewUser = ordersList.length === 0;
    const total = Number(this.data.checkoutTotalPrice || 0);
  
    const couponList = allCoupons.map(item => {
      let usable = true;
      let reason = '';
  
      if (item.type === 'new_user' && !isNewUser) {
        usable = false;
        reason = '仅首单可用';
      }
  
      if (item.type === 'full_reduce' && total < Number(item.threshold || 0)) {
        usable = false;
        reason = `还差￥${(Number(item.threshold || 0) - total).toFixed(2)}`;
      }
  
      return {
        ...item,
        usable,
        reason
      };
    });
  
    let selectedCouponId = this.data.selectedCouponId;
    const selectedCoupon = couponList.find(item => item.id === selectedCouponId && item.usable);
  
    if (!selectedCoupon) {
      selectedCouponId = '';
    }
  
    this.setData({
      couponList,
      selectedCouponId
    });
  
    this.calculateAmount();
  },

  async getPageData() {
    let checkoutCartList = wx.getStorageSync('checkoutCartList') || [];
    const savedRemark = wx.getStorageSync('checkoutOrderRemark') || '';
    const savedPickupMode = wx.getStorageSync('checkoutPickupMode') || '立即自取';
    const savedReserveDate = wx.getStorageSync('checkoutReserveDate') || this.data.reserveDate;
    const savedReserveDateLabel = wx.getStorageSync('checkoutReserveDateLabel') || this.data.reserveDateLabel;
    const savedReserveTime = wx.getStorageSync('checkoutReserveTime') || this.data.reserveTime;
    const savedCouponId = wx.getStorageSync('checkoutCouponId') || '';

    let ordersList = [];

    try {
      const res = await cloudOrder.listMyOrders();
      ordersList = Array.isArray(res.ordersList) ? res.ordersList : [];
    } catch (err) {
      console.error('读取云端订单失败', err);
      wx.showToast({
        title: (err && err.message) || '读取订单失败',
        icon: 'none'
      });
    }

    checkoutCartList = await this.formatItemList(checkoutCartList);
    ordersList = await this.formatOrdersList(ordersList);

    let reserveDate = savedReserveDate;
    let reserveDateLabel = savedReserveDateLabel;
    let reserveTime = savedReserveTime;

    if (!this.validateReserveDateTime(reserveDate, reserveTime)) {
      const suggested = this.getSuggestedReserveSelection();
      reserveDate = suggested.date;
      reserveDateLabel = suggested.label;
      reserveTime = suggested.time;
    }

    const activeViewMode = checkoutCartList.length > 0 ? '确认下单' : '历史订单';
    const checkoutBlockedReason = ((checkoutCartList.find(item => item.unavailableReason) || {}).unavailableReason) || '';
    const canSubmitOrder = this.data.storeCanSubmitOrder && !checkoutBlockedReason;
    const submitActionText = this.data.storeCanSubmitOrder
      ? (checkoutBlockedReason || '提交订单')
      : this.data.storeStatusText;

    this.setData({
      checkoutCartList,
      ordersList,
      orderRemark: checkoutCartList.length ? savedRemark : '',
      remarkCount: checkoutCartList.length ? savedRemark.length : 0,
      activePickupMode: savedPickupMode,
      reserveDate,
      reserveDateLabel,
      reserveTime,
      selectedCouponId: savedCouponId,
      activeViewMode,
      canSubmitOrder,
      submitActionText
    });

    this.calculateAmount();
    this.applyOrderFilter();
  },

  async formatItemList(list) {
    const itemList = list.map(item => {
      const price = Number(item.price || 0);
      const quantity = Number(item.quantity || 0);
      const runtime = productState.buildProductRuntime({ id: item.id });
      const unavailableReason = productState.getUnavailableReason({ id: item.id }, quantity);

      const specList = [
        item.size ? `杯型：${item.size}` : '',
        item.sweet ? `甜度：${item.sweet}` : '',
        item.ice ? `冰量：${item.ice}` : ''
      ].filter(Boolean);

      return {
        ...item,
        priceText: price.toFixed(2),
        subtotalText: (price * quantity).toFixed(2),
        specSummary: specList.join(' / '),
        toppingSummary: `小料：${item.toppingsText || '不加小料'}`,
        toppingModeSummary: `处理方式：${item.toppingModeText || '无'}`,
        tagText: item.tag || item.category || '本店精选',
        stock: runtime.stock,
        stockText: runtime.stockText,
        unavailableReason,
        isAvailable: !unavailableReason
      };
    });

    return cloudFile.attachDisplayUrlsForList(itemList, ['icon']);
  },

  async formatOrdersList(ordersList) {
    const orderList = await Promise.all(ordersList.map(async (order, index) => {
      const rawItems = (order.items || []).map(item => {
        const price = Number(item.price || 0);
        const quantity = Number(item.quantity || 0);

        const specList = [
          item.size ? item.size : '',
          item.sweet ? item.sweet : '',
          item.ice ? item.ice : ''
        ].filter(Boolean);

        return {
          ...item,
          priceText: price.toFixed(2),
          subtotalText: (price * quantity).toFixed(2),
          specSummary: specList.join(' / '),
          toppingSummary: `小料：${item.toppingsText || '不加小料'}`,
          toppingModeSummary: `处理方式：${item.toppingModeText || '无'}`,
          tagText: item.tag || '本店精选'
        };
      });

      const items = await cloudFile.attachDisplayUrlsForList(rawItems, ['icon']);
      const itemCount = items.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
      const progressInfo = this.getOrderProgressInfo(order, ordersList, index, itemCount);
      const remarkText = String(order.remark || '').trim();

      return {
        ...order,
        totalPriceText: Number(order.totalPrice || 0).toFixed(2),
        discountAmountText: Number(order.discountAmount || 0).toFixed(2),
        payablePriceText: Number(order.payablePrice || order.totalPrice || 0).toFixed(2),
        items,
        itemCount,
        remarkText,
        hasRemark: !!remarkText,
        statusClass: this.getStatusClass(order.status),
        statusLabel: this.getStatusLabel(order),
        statusText: this.getStatusText(order),
        canCancel: order.status === '待处理' || order.status === '制作中',
        ...progressInfo
      };
    }));

    return orderList;
  },

  getOrderProgressInfo(order, ordersList, currentIndex, itemCount) {
    const pickupCode = order.pickupCode || this.getPickupCode(order);
    const status = order.status;

    const queueAhead = ordersList.filter((target, targetIndex) => {
      const isActive = target.status === '待处理' || target.status === '制作中';
      return isActive && targetIndex > currentIndex;
    }).length;

    if (status === '待处理') {
      const progressPercent = Math.min(40, Math.max(14, 24 - queueAhead * 3));

      if (order.pickupMode === '预约取单') {
        const reserveText = this.getReservePickupText(order);
        return {
          showProgress: true,
          pickupCode,
          progressWidth: `width:${Math.max(16, progressPercent - 4)}%`,
          progressBarClass: 'progress-fill-pending',
          progressMainText: '已预约',
          queueText: reserveText ? `预约时间 ${reserveText}` : '已提交预约单',
          estimateText: '该订单不会立即进入制作队列',
          stageHint: '门店会在预约时间前安排备餐，请按预约时间到店取餐'
        };
      }

      const estimateMinutes = Math.max(8, 6 + queueAhead * 4 + Math.max(itemCount - 1, 0) * 2);

      return {
        showProgress: true,
        pickupCode,
        progressWidth: `width:${progressPercent}%`,
        progressBarClass: 'progress-fill-pending',
        progressMainText: '排队中',
        queueText: queueAhead > 0 ? `前面还有 ${queueAhead} 单` : '马上开始制作',
        estimateText: `预计 ${estimateMinutes} 分钟出杯`,
        stageHint: '门店会按下单顺序开始制作'
      };
    }

    if (status === '制作中') {
      const estimateMinutes = Math.max(3, 5 + Math.max(itemCount - 1, 0));
      return {
        showProgress: true,
        pickupCode,
        progressWidth: 'width:72%',
        progressBarClass: 'progress-fill-making',
        progressMainText: '制作中',
        queueText: '门店正在现做饮品',
        estimateText: `预计还有 ${estimateMinutes} 分钟`,
        stageHint: '制作完成后会进入待取餐状态'
      };
    }

    if (status === '待取餐') {
      return {
        showProgress: true,
        pickupCode,
        progressWidth: 'width:92%',
        progressBarClass: 'progress-fill-ready',
        progressMainText: '待取餐',
        queueText: `请到店出示取餐码 ${pickupCode}`,
        estimateText: '店员核销后订单完成',
        stageHint: '到店向店员报码或出示取餐码即可'
      };
    }

    if (status === '已完成') {
      return {
        showProgress: true,
        pickupCode,
        progressWidth: 'width:100%',
        progressBarClass: 'progress-fill-finished',
        progressMainText: '已完成',
        queueText: '订单已核销完成',
        estimateText: '感谢光临，欢迎下次再来',
        stageHint: order.verifyTime ? `核销时间：${order.verifyTime}` : '订单已完成'
      };
    }

    return {
      showProgress: false,
      pickupCode,
      progressWidth: 'width:0%',
      progressBarClass: 'progress-fill-cancelled',
      progressMainText: '',
      queueText: '',
      estimateText: '',
      stageHint: ''
    };
  },

  getPickupCode(order) {
    const source = String(order.orderNo || order.id || '');
    return source.slice(-4) || '0000';
  },

  getStatusClass(status) {
    if (status === '待处理') return 'status-pending';
    if (status === '制作中') return 'status-making';
    if (status === '待取餐') return 'status-ready';
    if (status === '已完成') return 'status-finished';
    return 'status-cancelled';
  },

  getReservePickupText(order) {
    if (!order) return '';
    if (order.reserveDateLabel && order.reserveTime) {
      return `${order.reserveDateLabel} ${order.reserveTime}`;
    }
    if (order.reserveDate && order.reserveTime) {
      return `${order.reserveDate} ${order.reserveTime}`;
    }
    return String(order.pickupModeText || '').replace(/^预约取单\s*/, '').trim();
  },

  getStatusLabel(order) {
    if (order.status === '待处理' && order.pickupMode === '预约取单') {
      return '已预约';
    }
    return order.status;
  },

  getStatusText(order) {
    const status = order.status;
    if (status === '待处理') {
      return order.pickupMode === '预约取单'
        ? '已预约，等待门店按预约时间备餐'
        : '商家待处理';
    }
    if (status === '制作中') return '饮品制作中';
    if (status === '待取餐') return '饮品已做好，等待到店取餐';
    if (status === '已完成') return '订单已完成';
    return '订单已取消';
  },

  calculateAmount() {
    const checkoutCartList = this.data.checkoutCartList;

    let checkoutTotalPrice = 0;
    let checkoutTotalCount = 0;

    checkoutCartList.forEach(item => {
      const price = Number(item.price || 0);
      const quantity = Number(item.quantity || 0);
      checkoutTotalPrice += price * quantity;
      checkoutTotalCount += quantity;
    });

    const checkoutTypeCount = checkoutCartList.length;
    const couponInfo = this.getSelectedCouponInfo(checkoutTotalPrice);
    const discountAmount = couponInfo.discountAmount;
    const payablePrice = Math.max(checkoutTotalPrice - discountAmount, 0);

    this.setData({
      checkoutTotalPrice: checkoutTotalPrice.toFixed(2),
      checkoutTotalCount,
      checkoutTypeCount,
      discountAmount: discountAmount.toFixed(2),
      payablePrice: payablePrice.toFixed(2),
      selectedCouponText: couponInfo.text
    });
  },

  getSelectedCouponInfo(totalPrice) {
    const selectedCouponId = this.data.selectedCouponId;
    const couponList = this.data.couponList || [];

    if (!selectedCouponId) {
      return {
        discountAmount: 0,
        text: '未使用优惠'
      };
    }

    const target = couponList.find(item => item.id === selectedCouponId);

    if (!target || !target.usable) {
      return {
        discountAmount: 0,
        text: '未使用优惠'
      };
    }

    return {
      discountAmount: Number(target.minus || 0),
      text: `${target.title} -￥${Number(target.minus || 0).toFixed(2)}`
    };
  },

  selectTab(e) {
    const tab = e.currentTarget.dataset.tab;

    this.setData({
      activeTab: tab
    });

    this.applyOrderFilter();
  },

  applyOrderFilter() {
    const { activeTab, ordersList } = this.data;
    let filteredOrders = [];

    if (activeTab === '全部') {
      filteredOrders = ordersList;
    } else if (activeTab === '进行中') {
      filteredOrders = ordersList.filter(order =>
        order.status === '待处理' ||
        order.status === '制作中' ||
        order.status === '待取餐'
      );
    } else if (activeTab === '已完成') {
      filteredOrders = ordersList.filter(order => order.status === '已完成');
    } else if (activeTab === '已取消') {
      filteredOrders = ordersList.filter(order => order.status === '已取消');
    } else {
      filteredOrders = ordersList;
    }

    this.setData({
      filteredOrders
    });
  },

  onRemarkInput(e) {
    const maxLength = Number(this.data.remarkMaxLength || 40);
    let value = String(e.detail.value || '');

    if (value.length > maxLength) {
      value = value.slice(0, maxLength);
    }

    this.setData({
      orderRemark: value,
      remarkCount: value.length
    });

    wx.setStorageSync('checkoutOrderRemark', value);
  },

  useQuickRemark(e) {
    const value = String(e.currentTarget.dataset.value || '');
    const maxLength = Number(this.data.remarkMaxLength || 40);
    let remark = String(this.data.orderRemark || '').trim();

    if (!remark) {
      remark = value;
    } else if (!remark.includes(value)) {
      remark = `${remark}，${value}`;
    }

    if (remark.length > maxLength) {
      remark = remark.slice(0, maxLength);
    }

    this.setData({
      orderRemark: remark,
      remarkCount: remark.length
    });

    wx.setStorageSync('checkoutOrderRemark', remark);

    wx.showToast({
      title: '已添加备注',
      icon: 'success'
    });
  },

  clearRemark() {
    this.setData({
      orderRemark: '',
      remarkCount: 0
    });

    wx.removeStorageSync('checkoutOrderRemark');
  },

  choosePickupMode(e) {
    const value = e.currentTarget.dataset.value || '立即自取';

    this.setData({
      activePickupMode: value
    });

    wx.setStorageSync('checkoutPickupMode', value);

    if (value === '预约取单' && !this.validateReserveDateTime(this.data.reserveDate, this.data.reserveTime)) {
      const suggested = this.getSuggestedReserveSelection();
      this.setData({
        reserveDate: suggested.date,
        reserveDateLabel: suggested.label,
        reserveTime: suggested.time
      });
      wx.setStorageSync('checkoutReserveDate', suggested.date);
      wx.setStorageSync('checkoutReserveDateLabel', suggested.label);
      wx.setStorageSync('checkoutReserveTime', suggested.time);
    }
  },

  chooseCoupon(e) {
    const id = e.currentTarget.dataset.id || '';
    const target = (this.data.couponList || []).find(item => item.id === id);

    if (!target || !target.usable) {
      wx.showToast({
        title: target ? target.reason || '当前不可用' : '当前不可用',
        icon: 'none'
      });
      return;
    }

    const nextId = this.data.selectedCouponId === id ? '' : id;

    this.setData({
      selectedCouponId: nextId
    });

    if (nextId) {
      wx.setStorageSync('checkoutCouponId', nextId);
    } else {
      wx.removeStorageSync('checkoutCouponId');
    }

    this.calculateAmount();
  },

  async submitOrder() {
    const checkoutCartList = this.data.checkoutCartList;
  
    if (checkoutCartList.length === 0) {
      wx.showToast({
        title: '没有待提交商品',
        icon: 'none'
      });
      return;
    }
  
    if (!this.data.canSubmitOrder) {
      wx.showToast({
        title: this.data.submitActionText,
        icon: 'none'
      });
      return;
    }
  
    if (this.data.activePickupMode === '预约取单' && !this.validateReserveDateTime(this.data.reserveDate, this.data.reserveTime)) {
      wx.showToast({
        title: '预约时间必须晚于当前时间',
        icon: 'none'
      });
      return;
    }
  
    const now = new Date();
    const orderId = Date.now();
    const remark = String(this.data.orderRemark || '').trim();
    const orderNo = this.createOrderNo(orderId);
    const pickupCode = this.createPickupCode(orderId);
  
    const pickupModeText = this.data.activePickupMode === '预约取单'
      ? `预约取单 ${this.data.reserveDateLabel} ${this.data.reserveTime}`
      : '立即自取';
  
    const order = {
      id: orderId,
      orderNo,
      pickupCode,
      createTime: this.formatTime(now),
      status: '待处理',
      totalPrice: Number(this.data.checkoutTotalPrice),
      discountAmount: Number(this.data.discountAmount),
      payablePrice: Number(this.data.payablePrice),
      couponId: this.data.selectedCouponId || '',
      couponText: this.data.selectedCouponText || '未使用优惠',
      remark,
      pickupMode: this.data.activePickupMode,
      pickupModeText,
      reserveDate: this.data.activePickupMode === '预约取单' ? this.data.reserveDate : '',
      reserveDateLabel: this.data.activePickupMode === '预约取单' ? this.data.reserveDateLabel : '',
      reserveTime: this.data.activePickupMode === '预约取单' ? this.data.reserveTime : '',
      items: checkoutCartList.map(item => ({
        id: item.id,
        name: item.name,
        desc: item.desc,
        price: Number(item.price || 0),
        quantity: Number(item.quantity || 0),
        size: item.size,
        sweet: item.sweet,
        ice: item.ice,
        toppings: item.toppings || [],
        toppingsText: item.toppingsText || '不加小料',
        toppingMode: item.toppingMode || '',
        toppingModeText: item.toppingModeText || '无',
        icon: item.icon,
        iconType: item.iconType,
        tag: item.tag,
        category: item.category || ''
      }))
    };
  
    try {
      await cloudOrder.createOrder(order);
  
      const checkoutCartIds = wx.getStorageSync('checkoutCartIds') || [];
      if (checkoutCartIds.length > 0) {
        let cartList = wx.getStorageSync('cartList') || [];
        cartList = cartList.filter(item => !checkoutCartIds.includes(item.cartId));
        await cloudUser.saveCartList(cartList);
      }
  
      wx.setStorageSync('checkoutCartList', []);
      wx.removeStorageSync('checkoutCartIds');
      wx.removeStorageSync('checkoutOrderRemark');
      wx.removeStorageSync('checkoutPickupMode');
      wx.removeStorageSync('checkoutReserveDate');
      wx.removeStorageSync('checkoutReserveDateLabel');
      wx.removeStorageSync('checkoutReserveTime');
      wx.removeStorageSync('checkoutCouponId');
  
      wx.showToast({
        title: '下单成功',
        icon: 'success'
      });
  
      const suggested = this.getSuggestedReserveSelection();
  
      this.setData({
        activeViewMode: '历史订单',
        activeTab: '进行中',
        orderRemark: '',
        remarkCount: 0,
        selectedCouponId: '',
        selectedCouponText: '未使用优惠',
        activePickupMode: '立即自取',
        reserveDate: suggested.date,
        reserveDateLabel: suggested.label,
        reserveTime: suggested.time
      });
  
      await this.getPageData();
      this.loadCouponData();
    } catch (err) {
      try {
        await Promise.all([
          cloudShop.syncShopStateToLocal(),
          cloudProduct.listProducts()
        ]);
        this.syncStoreStatus();
        await this.getPageData();
      } catch (syncErr) {
        console.error('下单失败后刷新状态失败', syncErr);
      }

      const errorMessage = (err && err.message) || '下单失败';
      if (errorMessage.includes('库存') || errorMessage.includes('售罄')) {
        wx.showModal({
          title: '下单失败',
          content: `${errorMessage}。已为你刷新最新库存，请重新确认后再提交。`,
          showCancel: false
        });
      } else {
        wx.showToast({
          title: errorMessage,
          icon: 'none'
        });
      }
    }
  },

  cancelCurrentCheckout() {
    const checkoutCartList = wx.getStorageSync('checkoutCartList') || [];

    if (!checkoutCartList.length) {
      wx.showToast({
        title: '当前没有待取消订单',
        icon: 'none'
      });
      return;
    }

    wx.showModal({
      title: '取消本次下单',
      content: '确定取消当前待提交订单吗？已选商品会退出本次结算。',
      success: res => {
        if (!res.confirm) return;

        wx.setStorageSync('checkoutCartList', []);
        wx.removeStorageSync('checkoutCartIds');
        wx.removeStorageSync('checkoutOrderRemark');
        wx.removeStorageSync('checkoutPickupMode');
        wx.removeStorageSync('checkoutReserveDate');
        wx.removeStorageSync('checkoutReserveDateLabel');
        wx.removeStorageSync('checkoutReserveTime');
        wx.removeStorageSync('checkoutCouponId');

        const suggested = this.getSuggestedReserveSelection();

        this.setData({
          activeViewMode: '历史订单',
          orderRemark: '',
          remarkCount: 0,
          selectedCouponId: '',
          selectedCouponText: '未使用优惠',
          activePickupMode: '立即自取',
          reserveDate: suggested.date,
          reserveDateLabel: suggested.label,
          reserveTime: suggested.time
        });

        this.getPageData();
        this.loadCouponData();

        wx.showToast({
          title: '已取消本次下单',
          icon: 'success'
        });
      }
    });
  },

  async cancelOrder(e) {
    const id = e.currentTarget.dataset.id;
  
    try {
      await cloudOrder.cancelMyOrder(id);
  
      wx.showToast({
        title: '订单已取消',
        icon: 'success'
      });
  
      await this.getPageData();
      this.loadCouponData();
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '取消失败',
        icon: 'none'
      });
    }
  },

  goHome() {
    wx.switchTab({
      url: '/pages/home/home'
    });
  },

  goCart() {
    wx.switchTab({
      url: '/pages/cart/cart'
    });
  },

  createOrderNo(id) {
    return 'SPF' + String(id);
  },

  createPickupCode(id) {
    const raw = String(id).slice(-4);
    return raw.padStart(4, '0');
  },

  formatTime(date) {
    const y = date.getFullYear();
    const m = this.addZero(date.getMonth() + 1);
    const d = this.addZero(date.getDate());
    const h = this.addZero(date.getHours());
    const mm = this.addZero(date.getMinutes());
    const s = this.addZero(date.getSeconds());

    return `${y}-${m}-${d} ${h}:${mm}:${s}`;
  },

  addZero(n) {
    return n < 10 ? '0' + n : n;
  }
});