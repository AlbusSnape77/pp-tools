const cloudShop = require('../../utils/cloud-shop');
const cloudProduct = require('../../utils/cloud-product');
const productState = require('../../utils/product-state');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    rawProductList: [],
    filteredProductList: [],
    searchKeyword: '',
    activeFilterCategory: '全部',
    categoryFilterList: ['全部', '招牌奶茶', '果茶', '咖啡'],
    productSummary: {
      total: 0,
      onSale: 0,
      soldOut: 0,
      paused: 0
    }
  },

  async onShow() {
    await this.loadProductData();
  },

  isImageSource(value) {
    return /^(https?:\/\/|cloud:\/\/|data:image)/i.test(String(value || '').trim());
  },

  buildProductCard(item) {
    const runtime = productState.buildProductRuntime(item);
    const status = runtime.effectiveStatus;
    const iconType = this.isImageSource(runtime.icon) || runtime.iconType === 'image' ? 'image' : 'emoji';

    return {
      ...runtime,
      iconType,
      priceText: Number(runtime.price || 0).toFixed(2),
      status,
      statusText: this.getSaleStatusText(status),
      statusClass: this.getSaleStatusClass(status),
      statusDesc: this.getSaleStatusDesc(status, runtime),
      stockLineText: runtime.effectiveStatus === 'soldout' ? '当前库存：0 杯' : `当前库存：${runtime.stock} 杯`,
      isOn: status === 'on',
      isSoldOut: status === 'soldout',
      isPaused: status === 'paused'
    };
  },

  async loadProductData() {
    try {
      const [productRes] = await Promise.all([
        cloudProduct.listProducts(),
        cloudShop.listProductStatus()
      ]);

      const baseList = Array.isArray(productRes.list) ? productRes.list : [];
      const productListWithDisplay = await cloudFile.attachDisplayUrlsForList(baseList, ['icon']);
      const rawProductList = productListWithDisplay.map(item => this.buildProductCard(item));

      const categoryFromData = rawProductList
        .map(item => String(item.category || '').trim())
        .filter(Boolean);

      const mergedCategories = Array.from(
        new Set(['招牌奶茶', '果茶', '咖啡', ...categoryFromData])
      );

      const total = rawProductList.length;
      const onSale = rawProductList.filter(item => item.status === 'on').length;
      const soldOut = rawProductList.filter(item => item.status === 'soldout').length;
      const paused = rawProductList.filter(item => item.status === 'paused').length;

      this.setData({
        rawProductList,
        productSummary: { total, onSale, soldOut, paused },
        categoryFilterList: ['全部', ...mergedCategories]
      });

      this.applyFilters();
    } catch (err) {
      wx.showToast({ title: (err && err.message) || '读取商品数据失败', icon: 'none' });
    }
  },

  applyFilters() {
    const keyword = String(this.data.searchKeyword || '').trim();
    const activeFilterCategory = this.data.activeFilterCategory;
    let list = this.data.rawProductList || [];

    if (activeFilterCategory !== '全部') {
      list = list.filter(item => item.category === activeFilterCategory);
    }

    if (keyword) {
      list = list.filter(item => {
        const text = `${item.name || ''} ${item.desc || ''} ${item.tag || ''} ${item.category || ''}`;
        return text.includes(keyword);
      });
    }

    this.setData({ filteredProductList: list });
  },

  onSearchInput(e) {
    this.setData({ searchKeyword: e.detail.value || '' });
    this.applyFilters();
  },

  clearSearch() {
    this.setData({ searchKeyword: '' });
    this.applyFilters();
  },

  chooseFilterCategory(e) {
    this.setData({ activeFilterCategory: e.currentTarget.dataset.value || '全部' });
    this.applyFilters();
  },

  getSaleStatusText(status) {
    if (status === 'soldout') return '已售罄';
    if (status === 'paused') return '暂停售卖';
    return '正常售卖';
  },

  getSaleStatusClass(status) {
    if (status === 'soldout') return 'sale-soldout';
    if (status === 'paused') return 'sale-paused';
    return 'sale-on';
  },

  getSaleStatusDesc(status, item) {
    if (status === 'soldout') return item.effectiveStatusSource === 'stock' ? '库存为 0，前台自动显示已售罄并禁止下单' : '管理员手动设置为已售罄，前台禁止下单';
    if (status === 'paused') return '前台显示暂停售卖，不可下单';
    return `前台正常显示，可继续售卖；当前余量 ${item.stock} 杯`;
  },

  goCreatePage() {
    wx.navigateTo({ url: '/pages/admin-product-editor/admin-product-editor?mode=create' });
  },

  goEditPage(e) {
    const id = Number(e.currentTarget.dataset.id);
    wx.navigateTo({ url: `/pages/admin-product-editor/admin-product-editor?mode=edit&id=${id}` });
  },

  async updateProductSaleStatus(e) {
    const id = Number(e.currentTarget.dataset.id);
    const status = e.currentTarget.dataset.status;

    try {
      await cloudShop.updateProductStatus(id, status);
      wx.showToast({ title: '商品状态已更新', icon: 'success' });
      await this.loadProductData();
    } catch (err) {
      wx.showToast({ title: (err && err.message) || '更新失败', icon: 'none' });
    }
  },

  async deleteProduct(e) {
    const id = Number(e.currentTarget.dataset.id);

    wx.showModal({
      title: '删除商品',
      content: '删除后首页将不再显示这款商品，确定继续吗？',
      success: async (res) => {
        if (!res.confirm) return;

        try {
          await cloudProduct.deleteProduct(id);
          wx.showToast({ title: '已删除', icon: 'success' });
          await this.loadProductData();
        } catch (err) {
          wx.showToast({ title: (err && err.message) || '删除失败', icon: 'none' });
        }
      }
    });
  }
});
