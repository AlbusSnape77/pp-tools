const cloudUser = require('../../utils/cloud-user');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    viewedList: []
  },

  async onShow() {
    await this.loadViewedList();
  },

  async loadViewedList() {
    try {
      await cloudUser.getUserData();
    } catch (err) {
      console.error('同步最近浏览失败', err);
    }

    const viewedList = wx.getStorageSync('recentViewedList') || [];
    const viewedListWithDisplay = await cloudFile.attachDisplayUrlsForList(viewedList, ['icon']);

    this.setData({
      viewedList: viewedListWithDisplay.map(item => ({
        ...item,
        priceText: Number(item.price || 0).toFixed(2)
      }))
    });
  },

  openProductDetail(e) {
    const product = e.currentTarget.dataset.product;

    if (!product || !product.id) {
      wx.showToast({
        title: '商品信息异常',
        icon: 'none'
      });
      return;
    }

    wx.setStorageSync('currentFood', product);

    wx.navigateTo({
      url: '/pages/detail/detail'
    });
  },

  async clearViewedList() {
    try {
      await cloudUser.clearRecentViewedList();

      this.setData({
        viewedList: []
      });

      wx.showToast({
        title: '已清空记录',
        icon: 'success'
      });
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '清空失败',
        icon: 'none'
      });
    }
  }
});