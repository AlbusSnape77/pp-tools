const cloudFeedback = require('../../utils/cloud-feedback');

Page({
  data: {
    feedbackList: [],
    filteredFeedbackList: [],
    activeStatus: '全部',
    keyword: '',
    statusTabs: ['全部', '待处理', '已处理'],
    summary: {
      totalCount: 0,
      todayCount: 0,
      pendingCount: 0,
      doneCount: 0
    }
  },

  async onShow() {
    await this.getFeedbackList();
  },

  normalizeFeedbackList(list) {
    return (list || []).map(item => {
      const status = item.status || '待处理';
      const normalizedStatus = status === '已处理' ? '已处理' : '待处理';
      const userDisplayName =
        item.userDisplayName ||
        item.accountNickname ||
        item.accountUsername ||
        (item.userOpenId || item.creatorOpenId ? `用户${String(item.userOpenId || item.creatorOpenId).slice(-6)}` : '未知用户');
      const userAccountText = item.accountUsername || '未绑定账号名';
      const userNicknameText = item.accountNickname || '未设置昵称';
      const userOpenIdText = item.userOpenId || item.creatorOpenId || '';

      return {
        ...item,
        id: Number(item.id || item._id || 0),
        type: item.type || '未分类反馈',
        status: normalizedStatus,
        contact: item.contact || '',
        userDisplayName,
        userAccountText,
        userNicknameText,
        userOpenIdText,
        statusClass: normalizedStatus === '已处理' ? 'status-done' : 'status-pending'
      };
    });
  },

  async getFeedbackList() {
    let feedbackList = [];

    try {
      feedbackList = await cloudFeedback.syncAllFeedbackToLocal();
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '读取反馈失败',
        icon: 'none'
      });
    }

    feedbackList = this.normalizeFeedbackList(feedbackList);

    this.setData({
      feedbackList
    });

    this.calculateSummary();
    this.filterFeedback();
  },

  calculateSummary() {
    const feedbackList = this.data.feedbackList;
    const today = new Date();

    let totalCount = feedbackList.length;
    let todayCount = 0;
    let pendingCount = 0;
    let doneCount = 0;

    feedbackList.forEach(item => {
      const feedbackDate = this.parseDate(item.createTime);

      if (this.isSameDay(feedbackDate, today)) {
        todayCount += 1;
      }

      if (item.status === '已处理') {
        doneCount += 1;
      } else {
        pendingCount += 1;
      }
    });

    this.setData({
      summary: {
        totalCount,
        todayCount,
        pendingCount,
        doneCount
      }
    });
  },

  selectStatus(e) {
    const status = e.currentTarget.dataset.status;

    this.setData({
      activeStatus: status
    });

    this.filterFeedback();
  },

  onSearchInput(e) {
    this.setData({
      keyword: e.detail.value || ''
    });

    this.filterFeedback();
  },

  clearSearch() {
    this.setData({
      keyword: ''
    });

    this.filterFeedback();
  },

  filterFeedback() {
    const { feedbackList, activeStatus, keyword } = this.data;
    const text = keyword.trim();

    let filteredFeedbackList = feedbackList;

    if (activeStatus !== '全部') {
      filteredFeedbackList = filteredFeedbackList.filter(item => item.status === activeStatus);
    }

    if (text) {
      filteredFeedbackList = filteredFeedbackList.filter(item => {
        const allText = `
          ${item.type || ''}
          ${item.content || ''}
          ${item.contact || ''}
          ${item.userDisplayName || ''}
          ${item.userAccountText || ''}
          ${item.userNicknameText || ''}
          ${item.userOpenIdText || ''}
        `.trim();
        return allText.includes(text);
      });
    }

    this.setData({
      filteredFeedbackList
    });
  },

  parseDate(str) {
    if (!str) return new Date();
    if (str instanceof Date) return str;
    return new Date(String(str).replace(/-/g, '/'));
  },

  isSameDay(date1, date2) {
    return (
      date1.getFullYear() === date2.getFullYear() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getDate() === date2.getDate()
    );
  },

  async markProcessed(e) {
    const id = Number(e.currentTarget.dataset.id);

    try {
      await cloudFeedback.markFeedbackProcessed(id);

      wx.showToast({
        title: '已标记处理',
        icon: 'success'
      });

      await this.getFeedbackList();
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '处理失败',
        icon: 'none'
      });
    }
  },

  goWorkbench() {
    wx.redirectTo({
      url: '/pages/admin/admin'
    });
  }
});