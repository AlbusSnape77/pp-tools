const cloudUser = require('../../utils/cloud-user');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    favoriteList: []
  },

  async onShow() {
    await this.loadFavoriteList();
  },

  async loadFavoriteList() {
    try {
      await cloudUser.getUserData();
    } catch (err) {
      console.error('同步收藏数据失败', err);
    }

    const favoriteList = wx.getStorageSync('favoriteList') || [];
    const favoriteListWithDisplay = await cloudFile.attachDisplayUrlsForList(favoriteList, ['icon']);

    this.setData({
      favoriteList: favoriteListWithDisplay.map(item => ({
        ...item,
        priceText: Number(item.price || 0).toFixed(2)
      }))
    });
  },

  openProductDetail(e) {
    const product = e.currentTarget.dataset.product;

    if (!product || !product.id) {
      wx.showToast({
        title: '商品信息异常',
        icon: 'none'
      });
      return;
    }

    wx.setStorageSync('currentFood', product);

    wx.navigateTo({
      url: '/pages/detail/detail'
    });
  },

  async removeFavorite(e) {
    const id = Number(e.currentTarget.dataset.id);
    let favoriteList = wx.getStorageSync('favoriteList') || [];

    favoriteList = favoriteList.filter(item => Number(item.id) !== id);

    try {
      await cloudUser.saveFavoriteList(favoriteList);
      await this.loadFavoriteList();

      wx.showToast({
        title: '已取消收藏',
        icon: 'success'
      });
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '取消收藏失败',
        icon: 'none'
      });
    }
  }
});