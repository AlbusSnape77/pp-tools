const cloudProduct = require('../../utils/cloud-product');
const productState = require('../../utils/product-state');
const mediaUploader = require('../../utils/media-uploader');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    mode: 'create',
    editingId: 0,
    pageTitle: '新增商品',
    categoryOptions: ['招牌奶茶', '果茶', '咖啡'],
    customCategory: '',
    form: {
      name: '',
      desc: '',
      price: '',
      stock: '30',
      category: '招牌奶茶',
      tag: '',
      icon: ''
    },
    formIconIsImage: false,
    formIconPreview: ''
  },

  async onLoad(options) {
    const mode = options.mode || 'create';
    const id = Number(options.id || 0);

    this.setData({
      mode,
      editingId: id,
      pageTitle: mode === 'edit' ? '编辑商品' : '新增商品'
    });

    if (mode === 'edit' && id) {
      await this.loadProductDetail(id);
    }
  },

  isImageSource(value) {
    return /^(https?:\/\/|cloud:\/\/|data:image)/i.test(String(value || '').trim());
  },

  async loadProductDetail(id) {
    try {
      const res = await cloudProduct.listProducts();
      const list = Array.isArray(res.list) ? res.list : [];
      const item = list.find(product => Number(product.id) === Number(id));

      if (!item) {
        wx.showToast({ title: '商品不存在', icon: 'none' });
        return;
      }

      const categoryFromData = list
        .map(product => String(product.category || '').trim())
        .filter(Boolean);

      const mergedCategories = Array.from(
        new Set(['招牌奶茶', '果茶', '咖啡', ...categoryFromData])
      );

      const isPresetCategory = mergedCategories.includes(item.category);

      const itemWithDisplay = await cloudFile.attachDisplayUrls(item, ['icon']);

      this.setData({
        categoryOptions: mergedCategories,
        customCategory: isPresetCategory ? '' : (item.category || ''),
        form: {
          name: item.name || '',
          desc: item.desc || '',
          price: String(item.price || ''),
          stock: String(productState.normalizeStock(item.stock)),
          category: isPresetCategory ? (item.category || mergedCategories[0] || '招牌奶茶') : (mergedCategories[0] || '招牌奶茶'),
          tag: item.tag || '',
          icon: itemWithDisplay.icon || item.icon || ''
        },
        formIconIsImage: item.iconType === 'image' || this.isImageSource(itemWithDisplay.icon || item.icon),
        formIconPreview: itemWithDisplay.iconDisplay || itemWithDisplay.icon || item.icon || ''
      });
    } catch (err) {
      wx.showToast({ title: (err && err.message) || '读取商品失败', icon: 'none' });
    }
  },

  onFormInput(e) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value || '';
    const patch = {
      [`form.${field}`]: value
    };

    if (field === 'icon') {
      patch.formIconIsImage = this.isImageSource(value);
    }

    this.setData(patch);
  },

  async chooseProductImage() {
    try {
      const upload = await mediaUploader.chooseAndUploadImage('products');
      this.setData({
        'form.icon': upload.fileID,
        formIconIsImage: true,
        formIconPreview: upload.tempFilePath || upload.fileID
      });
      wx.showToast({ title: '商品图片已上传', icon: 'success' });
    } catch (err) {
      if ((err && err.message) === '已取消选择图片') return;
      wx.showToast({ title: (err && err.message) || '上传失败', icon: 'none' });
    }
  },

  clearProductImage() {
    this.setData({
      'form.icon': '',
      formIconIsImage: false,
    formIconPreview: ''
    });
  },

  chooseCategory(e) {
    this.setData({
      'form.category': e.currentTarget.dataset.value || '招牌奶茶',
      customCategory: ''
    });
  },

  onCustomCategoryInput(e) {
    this.setData({
      customCategory: (e.detail.value || '').trim()
    });
  },

  resetForm() {
    this.setData({
      customCategory: '',
      form: {
        name: '',
        desc: '',
        price: '',
        stock: '30',
        category: this.data.categoryOptions[0] || '招牌奶茶',
        tag: '',
        icon: ''
      },
      formIconIsImage: false,
    formIconPreview: ''
    });
  },

  async saveProduct() {
    const { editingId, form, customCategory, mode } = this.data;

    const name = String(form.name || '').trim();
    const desc = String(form.desc || '').trim();
    const price = Number(form.price || 0);
    const stock = Math.floor(Number(form.stock || 0));
    const finalCategory = String(customCategory || form.category || '').trim();
    const tag = String(form.tag || '').trim();
    const icon = String(form.icon || '').trim() || '🧋';
    const iconType = this.isImageSource(icon) ? 'image' : 'emoji';

    if (!name) {
      wx.showToast({ title: '请输入商品名称', icon: 'none' });
      return;
    }

    if (!desc) {
      wx.showToast({ title: '请输入商品描述', icon: 'none' });
      return;
    }

    if (!(price > 0)) {
      wx.showToast({ title: '请输入正确价格', icon: 'none' });
      return;
    }

    if (!Number.isFinite(stock) || stock < 0) {
      wx.showToast({ title: '库存必须为大于等于 0 的整数', icon: 'none' });
      return;
    }

    if (!finalCategory) {
      wx.showToast({ title: '请选择或新增分类', icon: 'none' });
      return;
    }

    try {
      await cloudProduct.upsertProduct({
        id: editingId || undefined,
        name,
        desc,
        price,
        stock,
        category: finalCategory,
        tag,
        icon,
        iconType
      });

      wx.showToast({
        title: mode === 'edit' ? '商品已更新' : '商品已新增',
        icon: 'success'
      });

      setTimeout(() => {
        wx.navigateBack();
      }, 500);
    } catch (err) {
      wx.showToast({ title: (err && err.message) || '保存失败', icon: 'none' });
    }
  }
});
