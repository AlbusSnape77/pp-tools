const cloudUser = require('../../utils/cloud-user');
const cloudOrder = require('../../utils/cloud-order');
const cloudFeedback = require('../../utils/cloud-feedback');
const cloudShop = require('../../utils/cloud-shop');
const cloudAccount = require('../../utils/cloud-account');
const mediaUploader = require('../../utils/media-uploader');
const cloudFile = require('../../utils/cloud-file');
const runtime = require('../../config/runtime');
const demoStore = require('../../utils/demo/store');

Page({
  data: {
    accountName: '普通用户',
    userAvatar: '',
    avatarSaving: false,
    summary: {
      cartCount: 0,
      orderCount: 0,
      feedbackCount: 0,
      favoriteCount: 0,
      frequentCount: 0,
      viewedCount: 0
    },

    storeInfo: {
      name: '三平方奶茶店',
      phone: '400-123-4567',
      address: '大学城美食街 18 号一层 03 铺',
      hours: '10:00 - 22:00',
      latitude: 30.5728,
      longitude: 104.0668
    },

    heroTags: ['现做现出', '支持自定义', '招牌果茶'],
    storeStatus: 'open',
    storeStatusText: '营业中',
    storeStatusDesc: '欢迎来一杯今日推荐',
    currentTip: '今天也要喝点甜甜的',
    isDemoMode: runtime.isDemo()
  },

  async onShow() {
    const authInfo = wx.getStorageSync('authInfo') || {};
    const userAvatar = await cloudFile.resolveImageUrl(authInfo.avatarUrl || '');
    this.setData({
      accountName: authInfo.nickname || authInfo.username || '普通用户',
      userAvatar
    });

    await this.syncPageData();
  },

  async changeAvatarDirectly() {
    if (this.data.avatarSaving) return;

    const authInfo = wx.getStorageSync('authInfo') || {};
    if (authInfo.role !== 'user') {
      wx.showToast({ title: '请先登录用户账号', icon: 'none' });
      return;
    }

    this.setData({ avatarSaving: true });

    try {
      const upload = await mediaUploader.chooseAndUploadImage('avatars/user');
      await cloudAccount.updateAccount({
        role: 'user',
        userId: authInfo.userId || '',
        avatarUrl: upload.fileID
      });

      const latestAuthInfo = wx.getStorageSync('authInfo') || {};
      const userAvatar = upload.tempFilePath || await cloudFile.resolveImageUrl(latestAuthInfo.avatarUrl || upload.fileID);
      this.setData({
        userAvatar,
        accountName: latestAuthInfo.nickname || latestAuthInfo.username || this.data.accountName
      });

      wx.showToast({ title: '头像已更新', icon: 'success' });
    } catch (err) {
      if ((err && err.message) === '已取消选择图片') return;
      wx.showToast({
        title: (err && err.message) || '头像更新失败',
        icon: 'none'
      });
    } finally {
      this.setData({ avatarSaving: false });
    }
  },

  async syncPageData() {
    try {
      const [userData, orderRes, feedbackList, shopState] = await Promise.all([
        cloudUser.getUserData(),
        cloudOrder.listMyOrders(),
        cloudFeedback.syncMyFeedbackToLocal(),
        cloudShop.syncShopStateToLocal()
      ]);

      const storeConfig = (shopState && shopState.storeConfig) || wx.getStorageSync('storeStatusConfig') || {};
      const storeMedia = await cloudFile.attachDisplayUrls({
        logo: storeConfig.storeLogo || '',
        cover: storeConfig.storeCover || ''
      }, ['logo', 'cover']);

      this.setData({
        storeInfo: {
          ...this.data.storeInfo,
          logo: storeMedia.logo || '',
          logoDisplay: storeMedia.logoDisplay || '',
          cover: storeMedia.cover || '',
          coverDisplay: storeMedia.coverDisplay || ''
        }
      });

      const ordersList = Array.isArray(orderRes.ordersList) ? orderRes.ordersList : [];
      const cartList = Array.isArray(userData.cartList) ? userData.cartList : [];
      const favoriteList = Array.isArray(userData.favoriteList) ? userData.favoriteList : [];
      const recentViewedList = Array.isArray(userData.recentViewedList) ? userData.recentViewedList : [];
      const frequentList = this.getFrequentDrinkList(ordersList);

      let cartCount = 0;
      cartList.forEach(item => {
        cartCount += Number(item.quantity || 0);
      });

      this.setData({
        summary: {
          cartCount,
          orderCount: ordersList.length,
          feedbackCount: feedbackList.length,
          favoriteCount: favoriteList.length,
          frequentCount: frequentList.length,
          viewedCount: recentViewedList.length
        }
      });

      this.syncStoreStatus();
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '读取个人数据失败',
        icon: 'none'
      });
    }
  },

  syncStoreStatus() {
    const config = wx.getStorageSync('storeStatusConfig') || {};
    const status = config.status || 'open';

    if (status === 'pause') {
      this.setData({
        storeStatus: 'pause',
        storeStatusText: '暂停接单',
        storeStatusDesc: '门店当前暂停接单，请稍后再来',
        currentTip: '可以先收藏饮品，恢复后再下单'
      });
      return;
    }

    if (status === 'closed') {
      this.setData({
        storeStatus: 'closed',
        storeStatusText: '已打烊',
        storeStatusDesc: '门店当前已打烊',
        currentTip: '明天营业后再来喝一杯吧'
      });
      return;
    }

    this.setData({
      storeStatus: 'open',
      storeStatusText: '营业中',
      storeStatusDesc: '当前门店可正常下单',
      currentTip: '支持甜度、冰量和小料自定义'
    });
  },

  getFrequentDrinkList(ordersList) {
    const productMap = {};

    (ordersList || []).forEach(order => {
      const items = Array.isArray(order.items) ? order.items : [];

      items.forEach(item => {
        const id = Number(item.id);
        if (!id) return;

        if (!productMap[id]) {
          productMap[id] = {
            id: item.id,
            name: item.name,
            desc: item.desc,
            price: Number(item.price || 0),
            category: item.category || '',
            tag: item.tag || '常喝推荐',
            icon: item.icon,
            iconType: item.iconType,
            totalCount: 0
          };
        }

        productMap[id].totalCount += Number(item.quantity || 0);
      });
    });

    return Object.values(productMap)
      .sort((a, b) => b.totalCount - a.totalCount)
      .slice(0, 20);
  },

  openProductDetailByProduct(product) {
    if (!product || !product.id) {
      wx.showToast({
        title: '商品信息异常',
        icon: 'none'
      });
      return;
    }

    wx.setStorageSync('currentFood', product);

    wx.navigateTo({
      url: '/pages/detail/detail'
    });
  },

  goCart() {
    wx.switchTab({
      url: '/pages/cart/cart'
    });
  },

  goOrders() {
    wx.switchTab({
      url: '/pages/orders/orders'
    });
  },

  goFeedback() {
    wx.navigateTo({
      url: '/pages/feedback/feedback'
    });
  },

  goFavoritePage() {
    wx.navigateTo({
      url: '/pages/favorites/favorites'
    });
  },

  goFrequentPage() {
    wx.navigateTo({
      url: '/pages/frequent/frequent'
    });
  },

  goViewedPage() {
    wx.navigateTo({
      url: '/pages/viewed/viewed'
    });
  },

  goAccountSettings() {
    wx.navigateTo({
      url: '/pages/account-settings/account-settings'
    });
  },

  callStore() {
    wx.makePhoneCall({
      phoneNumber: this.data.storeInfo.phone
    });
  },

  copyAddress() {
    wx.setClipboardData({
      data: this.data.storeInfo.address,
      success: () => {
        wx.showToast({ title: '地址已复制', icon: 'success' });
      }
    });
  },

  openMapNavigation() {
    const { latitude, longitude, name, address } = this.data.storeInfo;

    wx.openLocation({
      latitude: Number(latitude),
      longitude: Number(longitude),
      name,
      address,
      scale: 18
    });
  },

  clearCart() {
    wx.showModal({
      title: '清空购物车',
      content: '确认清空当前购物车中的所有商品吗？',
      success: async res => {
        if (!res.confirm) return;

        try {
          await cloudUser.saveCartList([]);
          this.setData({
            'summary.cartCount': 0
          });
          wx.showToast({ title: '购物车已清空', icon: 'success' });
        } catch (err) {
          wx.showToast({ title: (err && err.message) || '清空失败', icon: 'none' });
        }
      }
    });
  },

  showTodayPick() {
    const picks = [
      '今日推荐：杨枝甘露，适合想来点清爽果香的时候',
      '今日推荐：芋泥啵啵奶茶，适合想喝绵密口感的时候',
      '今日推荐：多肉葡萄，酸甜轻盈，下午来一杯很合适',
      '今日推荐：黑糖珍珠奶茶，经典耐喝，几乎不会出错'
    ];
    const randomPick = picks[Math.floor(Math.random() * picks.length)];

    wx.showModal({
      title: '今日推荐',
      content: randomPick,
      showCancel: false,
      confirmText: '知道了'
    });
  },

  resetDemoData() {
    if (!runtime.isDemo()) return;
    wx.showModal({
      title: '重置演示数据',
      content: '商品、订单、账号修改和门店设置会恢复为初始演示状态，是否继续？',
      confirmText: '确认重置',
      success: res => {
        if (!res.confirm) return;
        demoStore.reset();
        const app = getApp();
        if (app && app.clearAuthInfo) app.clearAuthInfo();
        else wx.removeStorageSync('authInfo');
        wx.showToast({ title: '演示数据已重置', icon: 'success' });
        setTimeout(() => wx.reLaunch({ url: '/pages/login/login' }), 300);
      }
    });
  },

  logout() {
    const app = getApp();

    if (app && app.clearAuthInfo) {
      app.clearAuthInfo();
    } else {
      wx.removeStorageSync('authInfo');
    }

    wx.showToast({
      title: '已退出登录',
      icon: 'success'
    });

    setTimeout(() => {
      wx.reLaunch({
        url: '/pages/login/login'
      });
    }, 300);
  }
});
