const cloudUser = require('../../utils/cloud-user');
const cloudShop = require('../../utils/cloud-shop');
const cloudProduct = require('../../utils/cloud-product');
const productState = require('../../utils/product-state');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    foodInfo: {},
    themeClass: 'theme-default',

    sizeList: [
      { name: '小杯', extra: 0, desc: '轻饮刚刚好' },
      { name: '中杯', extra: 2, desc: '经典推荐' },
      { name: '大杯', extra: 4, desc: '畅饮更满足' }
    ],

    sweetList: ['正常糖', '少糖', '半糖', '无糖'],
    iceList: ['正常冰', '少冰', '去冰', '热饮'],

    toppingList: [
      { name: '珍珠', price: 3 },
      { name: '椰果', price: 3 },
      { name: '西米', price: 3 },
      { name: '芋圆', price: 4 },
      { name: '布丁', price: 4 },
      { name: '奶冻', price: 4 },
      { name: '红豆', price: 3 },
      { name: '仙草', price: 3 }
    ],

    toppingModeList: ['加入奶茶', '分开装'],

    activeSize: '中杯',
    activeSizeExtra: 2,
    activeSweet: '正常糖',
    activeIce: '正常冰',
    activeToppingMode: '加入奶茶',

    selectedToppings: [],
    selectedToppingsMap: {},

    count: 1,

    selectedSummaryText: '',
    basePrice: '0.00',
    sizePrice: '0.00',
    toppingPrice: '0.00',
    singlePrice: '0.00',
    totalPrice: '0.00',
    singlePriceNumber: 0,

    recommendPresetList: [],
    activePresetTitle: '',

    canOrder: true,
    orderActionText: '加入购物车',

    isFavorite: false
  },

  onLoad() {
    this._alive = true;
    this._inited = false;
    this.initPage();
  },

  onShow() {
    if (!this._inited) return;
    this.refreshLightState();
  },

  onUnload() {
    this._alive = false;
  },

  safeSetData(patch, callback) {
    if (!this._alive) return;
    this.setData(patch, callback);
  },

  async initPage() {
    try {
      let foodInfo = wx.getStorageSync('currentFood') || {};

      if (!foodInfo || !foodInfo.id) {
        this.safeSetData({
          foodInfo: {},
          selectedSummaryText: '暂无商品信息'
        });
        this._inited = true;
        return;
      }

      try {
        await Promise.all([
          cloudUser.getUserData(),
          cloudShop.syncShopStateToLocal()
        ]);
      } catch (err) {
        console.error('详情页初始化同步失败', err);
      }

      foodInfo = await this.loadLatestFoodInfo(foodInfo);

      const recommendPresetList = this.formatRecommendPresetList(
        this.getRecommendPresetList(foodInfo)
      );

      const initState = this.buildInitialState(foodInfo, recommendPresetList);

      this.safeSetData(initState);
      this._inited = true;

      this.saveRecentViewed(foodInfo);
    } catch (err) {
      console.error('详情页初始化失败', err);
      this._inited = true;
    }
  },

  async refreshLightState() {
    try {
      const currentFood = this.data.foodInfo || wx.getStorageSync('currentFood') || {};
      const foodInfo = await this.loadLatestFoodInfo(currentFood);

      const statusInfo = this.computeOrderStatus(foodInfo);
      const isFavorite = this.computeFavoriteStatus(foodInfo);

      this.safeSetData({
        foodInfo,
        themeClass: this.getThemeClass(foodInfo.category),
        canOrder: statusInfo.canOrder,
        orderActionText: statusInfo.orderActionText,
        isFavorite
      });
    } catch (err) {
      console.error('详情页轻刷新失败', err);
    }
  },

  async loadLatestFoodInfo(fallbackFood) {
    const currentFood = fallbackFood || wx.getStorageSync('currentFood') || {};
    const id = Number(currentFood.id || 0);

    if (!id) return cloudFile.attachDisplayUrls(productState.buildProductRuntime(currentFood), ['icon']);

    try {
      const res = await cloudProduct.getProductById(id);
      const product = productState.buildProductRuntime(res.product || currentFood);
      const productWithDisplay = await cloudFile.attachDisplayUrls(product, ['icon']);
      wx.setStorageSync('currentFood', productWithDisplay);
      return productWithDisplay;
    } catch (err) {
      console.error('读取最新商品详情失败', err);
      return cloudFile.attachDisplayUrls(productState.buildProductRuntime(currentFood), ['icon']);
    }
  },

  buildInitialState(foodInfo, recommendPresetList) {
    const preset = recommendPresetList.length ? recommendPresetList[0] : null;

    const activeSize = preset ? preset.size : '中杯';
    const activeSizeExtra = this.getSizeExtraByName(activeSize);
    const activeSweet = preset ? preset.sweet : '正常糖';
    const activeIce = preset ? preset.ice : '正常冰';
    const activeToppingMode = preset ? (preset.toppingMode || '加入奶茶') : '加入奶茶';
    const selectedToppings = preset ? this.buildSelectedToppings(preset.toppings) : [];
    const selectedToppingsMap = this.buildSelectedToppingsMap(selectedToppings);
    const count = 1;
    const activePresetTitle = preset ? preset.title : '';

    const priceData = this.buildPriceData({
      foodInfo,
      activeSizeExtra,
      selectedToppings,
      count
    });

    const selectedSummaryText = this.buildSelectedSummary({
      activeSize,
      activeSweet,
      activeIce,
      selectedToppings,
      activeToppingMode,
      count,
      activePresetTitle
    });

    const statusInfo = this.computeOrderStatus(foodInfo);
    const isFavorite = this.computeFavoriteStatus(foodInfo);

    return {
      foodInfo,
      themeClass: this.getThemeClass(foodInfo.category),
      recommendPresetList,

      activeSize,
      activeSizeExtra,
      activeSweet,
      activeIce,
      activeToppingMode,

      selectedToppings,
      selectedToppingsMap,

      count,
      activePresetTitle,

      selectedSummaryText,
      ...priceData,

      canOrder: statusInfo.canOrder,
      orderActionText: statusInfo.orderActionText,

      isFavorite
    };
  },

  computeFavoriteStatus(foodInfo) {
    try {
      const favoriteList = wx.getStorageSync('favoriteList') || [];
      return favoriteList.some(item => Number(item.id) === Number(foodInfo.id));
    } catch (err) {
      return false;
    }
  },

  syncFavoriteStatus() {
    const foodInfo = this.data.foodInfo || wx.getStorageSync('currentFood') || {};
    this.safeSetData({
      isFavorite: this.computeFavoriteStatus(foodInfo)
    });
  },

  async toggleFavorite() {
    const foodInfo = this.data.foodInfo || {};

    if (!foodInfo || !foodInfo.id) {
      wx.showToast({
        title: '商品信息异常',
        icon: 'none'
      });
      return;
    }

    let favoriteList = wx.getStorageSync('favoriteList') || [];
    const exists = favoriteList.some(item => Number(item.id) === Number(foodInfo.id));

    if (exists) {
      favoriteList = favoriteList.filter(item => Number(item.id) !== Number(foodInfo.id));

      try {
        await cloudUser.saveFavoriteList(favoriteList);

        this.safeSetData({
          isFavorite: false
        });

        wx.showToast({
          title: '已取消收藏',
          icon: 'success'
        });
      } catch (err) {
        wx.showToast({
          title: (err && err.message) || '取消收藏失败',
          icon: 'none'
        });
      }

      return;
    }

    favoriteList.unshift({
      id: foodInfo.id,
      name: foodInfo.name,
      desc: foodInfo.desc,
      price: Number(foodInfo.price || 0),
      category: foodInfo.category || '',
      tag: foodInfo.tag || '',
      icon: foodInfo.icon,
      iconType: foodInfo.iconType,
      favoriteTime: Date.now()
    });

    const uniqueMap = {};
    favoriteList = favoriteList.filter(item => {
      const key = String(item.id);
      if (uniqueMap[key]) return false;
      uniqueMap[key] = true;
      return true;
    });

    try {
      await cloudUser.saveFavoriteList(favoriteList);

      this.safeSetData({
        isFavorite: true
      });

      wx.showToast({
        title: '已加入收藏',
        icon: 'success'
      });
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '加入收藏失败',
        icon: 'none'
      });
    }
  },

  getProductStatusInfo(foodInfo) {
    const runtime = productState.buildProductRuntime(foodInfo || {});

    if (runtime.effectiveStatus === 'soldout') {
      return {
        canSale: false,
        text: '已售罄',
        stock: runtime.stock
      };
    }

    if (runtime.effectiveStatus === 'paused') {
      return {
        canSale: false,
        text: '暂停售卖',
        stock: runtime.stock
      };
    }

    return {
      canSale: true,
      text: '加入购物车',
      stock: runtime.stock
    };
  },

  computeOrderStatus(foodInfo) {
    const runtime = productState.buildProductRuntime(foodInfo || {});
    const unavailableReason = productState.getUnavailableReason(runtime, 1);

    if (unavailableReason) {
      return {
        canOrder: false,
        orderActionText: unavailableReason.includes('库存不足') || unavailableReason.includes('售罄')
          ? '已售罄'
          : unavailableReason
      };
    }

    return {
      canOrder: true,
      orderActionText: '加入购物车'
    };
  },

  syncOrderStatus() {
    const foodInfo = this.data.foodInfo || {};
    const statusInfo = this.computeOrderStatus(foodInfo);

    this.safeSetData({
      canOrder: statusInfo.canOrder,
      orderActionText: statusInfo.orderActionText
    });
  },

  async saveRecentViewed(foodInfo) {
    if (!foodInfo || !foodInfo.id) return;

    let recentViewedList = wx.getStorageSync('recentViewedList') || [];

    recentViewedList = recentViewedList.filter(item => Number(item.id) !== Number(foodInfo.id));

    recentViewedList.unshift({
      id: foodInfo.id,
      name: foodInfo.name,
      desc: foodInfo.desc,
      price: Number(foodInfo.price || 0),
      category: foodInfo.category || '',
      tag: foodInfo.tag || '',
      icon: foodInfo.icon,
      iconType: foodInfo.iconType,
      viewedAt: Date.now()
    });

    if (recentViewedList.length > 20) {
      recentViewedList = recentViewedList.slice(0, 20);
    }

    try {
      await cloudUser.saveRecentViewedList(recentViewedList);
    } catch (err) {
      console.error('保存最近浏览失败', err);
    }
  },

  getThemeClass(category) {
    if (category === '招牌奶茶') return 'theme-milk';
    if (category === '果茶') return 'theme-fruit';
    if (category === '咖啡') return 'theme-coffee';
    return 'theme-default';
  },

  getRecommendPresetList(foodInfo) {
    const category = foodInfo.category || '';

    if (category === '招牌奶茶') {
      return [
        {
          title: '经典招牌喝法',
          tag: '最稳推荐',
          desc: '适合第一次点这杯，风味平衡，口感更完整。',
          size: '中杯',
          sweet: '正常糖',
          ice: '少冰',
          toppings: ['珍珠'],
          toppingMode: '加入奶茶'
        },
        {
          title: '丝滑厚乳感',
          tag: '顺滑口感',
          desc: '适合喜欢绵密口感的人，喝起来更有满足感。',
          size: '大杯',
          sweet: '半糖',
          ice: '热饮',
          toppings: ['布丁', '奶冻'],
          toppingMode: '加入奶茶'
        },
        {
          title: '轻甜不腻版',
          tag: '日常耐喝',
          desc: '更适合想喝奶茶但不想太甜的时候。',
          size: '中杯',
          sweet: '少糖',
          ice: '少冰',
          toppings: [],
          toppingMode: '加入奶茶'
        }
      ];
    }

    if (category === '果茶') {
      return [
        {
          title: '清爽出片款',
          tag: '夏日推荐',
          desc: '果香更明显，整体更清爽，很适合白天来一杯。',
          size: '大杯',
          sweet: '少糖',
          ice: '少冰',
          toppings: ['椰果'],
          toppingMode: '加入奶茶'
        },
        {
          title: '真果轻盈版',
          tag: '低负担',
          desc: '尽量保留果茶本身风味，适合喜欢轻盈口感的人。',
          size: '中杯',
          sweet: '半糖',
          ice: '去冰',
          toppings: [],
          toppingMode: '加入奶茶'
        },
        {
          title: '层次感加料版',
          tag: '口感丰富',
          desc: '更有料、更饱满，适合想喝得更有层次的时候。',
          size: '大杯',
          sweet: '正常糖',
          ice: '正常冰',
          toppings: ['椰果', '西米'],
          toppingMode: '加入奶茶'
        }
      ];
    }

    if (category === '咖啡') {
      return [
        {
          title: '提神干净版',
          tag: '通勤必备',
          desc: '口感更利落，适合需要清醒一下的时候。',
          size: '中杯',
          sweet: '无糖',
          ice: '少冰',
          toppings: [],
          toppingMode: '加入奶茶'
        },
        {
          title: '顺滑耐喝版',
          tag: '大众推荐',
          desc: '整体更柔和，更适合大多数人的接受口味。',
          size: '大杯',
          sweet: '少糖',
          ice: '去冰',
          toppings: [],
          toppingMode: '加入奶茶'
        },
        {
          title: '暖饮香浓版',
          tag: '晚间友好',
          desc: '更适合想慢慢喝、口感更温和的时候。',
          size: '中杯',
          sweet: '半糖',
          ice: '热饮',
          toppings: [],
          toppingMode: '加入奶茶'
        }
      ];
    }

    return [
      {
        title: '店长推荐',
        tag: '默认推荐',
        desc: '第一次点的话，先试试这套更稳妥的组合。',
        size: '中杯',
        sweet: '正常糖',
        ice: '少冰',
        toppings: [],
        toppingMode: '加入奶茶'
      }
    ];
  },

  formatRecommendPresetList(list = []) {
    return (Array.isArray(list) ? list : []).map(item => {
      const toppings = Array.isArray(item.toppings) ? item.toppings : [];

      return {
        ...item,
        toppings,
        toppingsText: toppings.length ? toppings.join('、') : '不加小料'
      };
    });
  },

  getSizeExtraByName(sizeName) {
    const match = this.data.sizeList.find(item => item.name === sizeName);
    return match ? Number(match.extra || 0) : 0;
  },

  buildSelectedToppings(toppingNames) {
    const names = Array.isArray(toppingNames) ? toppingNames : [];

    return names
      .map(name => {
        const match = this.data.toppingList.find(item => item.name === name);
        return match ? { name: match.name, price: Number(match.price || 0) } : null;
      })
      .filter(Boolean);
  },

  buildSelectedToppingsMap(toppingList) {
    const map = {};
    toppingList.forEach(item => {
      map[item.name] = true;
    });
    return map;
  },

  buildPriceData({ foodInfo, activeSizeExtra, selectedToppings, count }) {
    const basePriceNumber = Number(foodInfo.price || 0);

    let toppingPriceNumber = 0;
    (selectedToppings || []).forEach(item => {
      toppingPriceNumber += Number(item.price || 0);
    });

    const singlePriceNumber = basePriceNumber + Number(activeSizeExtra || 0) + toppingPriceNumber;
    const totalPriceNumber = singlePriceNumber * Number(count || 1);

    return {
      basePrice: basePriceNumber.toFixed(2),
      sizePrice: Number(activeSizeExtra || 0).toFixed(2),
      toppingPrice: toppingPriceNumber.toFixed(2),
      singlePrice: singlePriceNumber.toFixed(2),
      totalPrice: totalPriceNumber.toFixed(2),
      singlePriceNumber: Number(singlePriceNumber.toFixed(2))
    };
  },

  buildSelectedSummary(state) {
    const {
      activeSize,
      activeSweet,
      activeIce,
      selectedToppings,
      activeToppingMode,
      count,
      activePresetTitle
    } = state;

    const toppingText = selectedToppings.length
      ? `${selectedToppings.map(item => item.name).join('、')} · ${activeToppingMode}`
      : '不加小料';

    const presetText = activePresetTitle ? ` / ${activePresetTitle}` : '';

    return `${activeSize} / ${activeSweet} / ${activeIce} / ${toppingText} / ${count}杯${presetText}`;
  },

  applyPresetData(preset, showToast = true) {
    if (!preset || !this.data.canOrder) return;

    const selectedToppings = this.buildSelectedToppings(preset.toppings);
    const selectedToppingsMap = this.buildSelectedToppingsMap(selectedToppings);

    const patch = {
      activePresetTitle: preset.title,
      activeSize: preset.size,
      activeSizeExtra: this.getSizeExtraByName(preset.size),
      activeSweet: preset.sweet,
      activeIce: preset.ice,
      activeToppingMode: preset.toppingMode || '加入奶茶',
      selectedToppings,
      selectedToppingsMap
    };

    const nextState = {
      ...this.data,
      ...patch
    };

    const priceData = this.buildPriceData({
      foodInfo: this.data.foodInfo,
      activeSizeExtra: patch.activeSizeExtra,
      selectedToppings,
      count: this.data.count
    });

    patch.selectedSummaryText = this.buildSelectedSummary(nextState);
    Object.assign(patch, priceData);

    this.safeSetData(patch);

    if (showToast) {
      wx.showToast({
        title: '已套用推荐搭配',
        icon: 'success'
      });
    }
  },

  applyRecommendPreset(e) {
    if (!this.data.canOrder) return;

    const index = Number(e.currentTarget.dataset.index || 0);
    const preset = this.data.recommendPresetList[index];
    this.applyPresetData(preset, true);
  },

  chooseSize(e) {
    if (!this.data.canOrder) return;

    const name = e.currentTarget.dataset.name;
    const extra = Number(e.currentTarget.dataset.extra || 0);

    this.recomputeAndSet({
      activeSize: name,
      activeSizeExtra: extra,
      activePresetTitle: ''
    });
  },

  chooseSweet(e) {
    if (!this.data.canOrder) return;

    const value = e.currentTarget.dataset.value;

    this.recomputeAndSet({
      activeSweet: value,
      activePresetTitle: ''
    });
  },

  chooseIce(e) {
    if (!this.data.canOrder) return;

    const value = e.currentTarget.dataset.value;

    this.recomputeAndSet({
      activeIce: value,
      activePresetTitle: ''
    });
  },

  chooseToppingMode(e) {
    if (!this.data.canOrder) return;

    const value = e.currentTarget.dataset.value;

    this.recomputeAndSet({
      activeToppingMode: value,
      activePresetTitle: ''
    });
  },

  toggleTopping(e) {
    if (!this.data.canOrder) return;

    const name = e.currentTarget.dataset.name;
    const price = Number(e.currentTarget.dataset.price || 0);

    let selectedToppings = this.data.selectedToppings.slice();
    let selectedToppingsMap = { ...this.data.selectedToppingsMap };

    if (selectedToppingsMap[name]) {
      selectedToppings = selectedToppings.filter(item => item.name !== name);
      delete selectedToppingsMap[name];
    } else {
      selectedToppings.push({
        name,
        price
      });
      selectedToppingsMap[name] = true;
    }

    this.recomputeAndSet({
      selectedToppings,
      selectedToppingsMap,
      activePresetTitle: ''
    });
  },

  changeCount(e) {
    if (!this.data.canOrder) return;

    const type = e.currentTarget.dataset.type;
    const maxStock = Math.max(1, Number((this.data.foodInfo && this.data.foodInfo.stock) || 0));
    let count = this.data.count;

    if (type === 'minus' && count > 1) count -= 1;
    if (type === 'plus') {
      if (count >= maxStock) {
        wx.showToast({
          title: `库存不足，仅剩 ${maxStock} 杯`,
          icon: 'none'
        });
        return;
      }
      count += 1;
    }

    this.recomputeAndSet({
      count
    });
  },

  recomputeAndSet(patch = {}) {
    const nextState = {
      ...this.data,
      ...patch
    };

    const priceData = this.buildPriceData({
      foodInfo: nextState.foodInfo,
      activeSizeExtra: nextState.activeSizeExtra,
      selectedToppings: nextState.selectedToppings,
      count: nextState.count
    });

    patch.selectedSummaryText = this.buildSelectedSummary(nextState);
    Object.assign(patch, priceData);

    this.safeSetData(patch);
  },

  buildCurrentOrderItem() {
    const foodInfo = this.data.foodInfo;
    const count = this.data.count;
    const activeSize = this.data.activeSize;
    const activeSizeExtra = Number(this.data.activeSizeExtra || 0);
    const activeSweet = this.data.activeSweet;
    const activeIce = this.data.activeIce;
    const selectedToppings = this.data.selectedToppings;
    const activeToppingMode = this.data.activeToppingMode;
    const singlePriceNumber = this.data.singlePriceNumber;

    const toppingsText =
      selectedToppings.length > 0
        ? selectedToppings.map(item => `${item.name}(+￥${item.price})`).join('、')
        : '不加小料';

    const toppingTotal = selectedToppings.reduce((sum, item) => sum + Number(item.price || 0), 0);

    return {
      cartId: Date.now() + Math.floor(Math.random() * 1000),
      id: foodInfo.id,
      name: foodInfo.name,
      desc: foodInfo.desc,
      price: singlePriceNumber,
      basePrice: Number(foodInfo.price || 0),
      sizePrice: activeSizeExtra,
      toppingPrice: Number(toppingTotal.toFixed(2)),
      icon: foodInfo.icon,
      iconType: foodInfo.iconType,
      tag: foodInfo.tag,
      category: foodInfo.category,
      quantity: count,
      size: activeSize,
      sweet: activeSweet,
      ice: activeIce,
      toppings: selectedToppings,
      toppingsText,
      toppingMode: selectedToppings.length > 0 ? activeToppingMode : '',
      toppingModeText: selectedToppings.length > 0 ? activeToppingMode : '无'
    };
  },

  async addToCart() {
    const statusInfo = this.computeOrderStatus(this.data.foodInfo);

    if (!statusInfo.canOrder) {
      wx.showToast({
        title: statusInfo.orderActionText,
        icon: 'none'
      });
      return;
    }

    const foodInfo = this.data.foodInfo;

    if (Number(foodInfo.stock || 0) < Number(this.data.count || 1)) {
      wx.showToast({
        title: `库存不足，仅剩 ${Number(foodInfo.stock || 0)} 杯`,
        icon: 'none'
      });
      return;
    }

    if (!foodInfo || !foodInfo.id) {
      wx.showToast({
        title: '商品信息异常',
        icon: 'none'
      });
      return;
    }

    let cartList = wx.getStorageSync('cartList') || [];
    cartList.unshift(this.buildCurrentOrderItem());

    try {
      await cloudUser.saveCartList(cartList);

      wx.showToast({
        title: '已加入购物车',
        icon: 'success'
      });
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '加入购物车失败',
        icon: 'none'
      });
    }
  },

  buyNow() {
    const statusInfo = this.computeOrderStatus(this.data.foodInfo);

    if (!statusInfo.canOrder) {
      wx.showToast({
        title: statusInfo.orderActionText,
        icon: 'none'
      });
      return;
    }

    const foodInfo = this.data.foodInfo;

    if (Number(foodInfo.stock || 0) < Number(this.data.count || 1)) {
      wx.showToast({
        title: `库存不足，仅剩 ${Number(foodInfo.stock || 0)} 杯`,
        icon: 'none'
      });
      return;
    }

    if (!foodInfo || !foodInfo.id) {
      wx.showToast({
        title: '商品信息异常',
        icon: 'none'
      });
      return;
    }

    wx.setStorageSync('checkoutCartList', [this.buildCurrentOrderItem()]);
    wx.removeStorageSync('checkoutOrderRemark');
    wx.removeStorageSync('checkoutPickupMode');
    wx.removeStorageSync('checkoutReserveDate');
    wx.removeStorageSync('checkoutReserveDateLabel');
    wx.removeStorageSync('checkoutReserveTime');
    wx.removeStorageSync('checkoutCouponId');

    wx.switchTab({
      url: '/pages/orders/orders'
    });
  }
});