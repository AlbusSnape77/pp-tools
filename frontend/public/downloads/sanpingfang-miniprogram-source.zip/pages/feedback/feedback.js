const cloudFeedback = require('../../utils/cloud-feedback');

Page({
  data: {
    typeList: ['口味建议', '出餐问题', '页面问题', '其他'],
    activeType: '口味建议',
    content: '',
    contact: '',
    feedbackList: [],
    contentCount: 0,
    summary: {
      totalCount: 0,
      pendingCount: 0,
      doneCount: 0
    }
  },

  async onShow() {
    await this.getFeedbackList();
  },

  chooseType(e) {
    const value = e.currentTarget.dataset.value;

    this.setData({
      activeType: value
    });
  },

  onContentInput(e) {
    const value = e.detail.value || '';

    this.setData({
      content: value,
      contentCount: value.length
    });
  },

  onContactInput(e) {
    this.setData({
      contact: e.detail.value
    });
  },

  async getFeedbackList() {
    let feedbackList = [];

    try {
      feedbackList = await cloudFeedback.syncMyFeedbackToLocal();
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '读取反馈失败',
        icon: 'none'
      });
    }

    feedbackList = this.normalizeFeedbackList(feedbackList);

    this.setData({
      feedbackList
    });

    this.calculateSummary();
  },

  normalizeFeedbackList(list) {
    return list.map(item => {
      const rawStatus = item.status || '待处理';
      const normalizedStatus = rawStatus === '已处理' ? '已处理' : '待处理';

      return {
        ...item,
        type: item.type || '未分类反馈',
        status: normalizedStatus,
        contact: item.contact || '',
        statusClass: normalizedStatus === '已处理' ? 'status-done' : 'status-pending'
      };
    });
  },

  calculateSummary() {
    const feedbackList = this.data.feedbackList;

    let totalCount = feedbackList.length;
    let pendingCount = 0;
    let doneCount = 0;

    feedbackList.forEach(item => {
      if (item.status === '已处理') {
        doneCount += 1;
      } else {
        pendingCount += 1;
      }
    });

    this.setData({
      summary: {
        totalCount,
        pendingCount,
        doneCount
      }
    });
  },

  async submitFeedback() {
    const activeType = this.data.activeType;
    const content = this.data.content.trim();
    const contact = this.data.contact.trim();

    if (!content) {
      wx.showToast({
        title: '请输入反馈内容',
        icon: 'none'
      });
      return;
    }

    const feedbackItem = {
      id: Date.now(),
      type: activeType,
      content,
      contact
    };

    try {
      await cloudFeedback.createFeedback(feedbackItem);

      this.setData({
        activeType: '口味建议',
        content: '',
        contact: '',
        contentCount: 0
      });

      wx.showToast({
        title: '提交成功',
        icon: 'success'
      });

      await this.getFeedbackList();
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '提交失败',
        icon: 'none'
      });
    }
  }
});