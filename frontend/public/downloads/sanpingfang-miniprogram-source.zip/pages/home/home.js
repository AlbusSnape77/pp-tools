const cloudAuth = require('../../utils/cloud-auth');
const cloudUser = require('../../utils/cloud-user');
const cloudShop = require('../../utils/cloud-shop');
const cloudProduct = require('../../utils/cloud-product');
const productState = require('../../utils/product-state');
const cloudFile = require('../../utils/cloud-file');

const HOME_REFRESH_INTERVAL = 30 * 1000;
const HOME_REFRESH_KEY = 'homePageLastSyncAt';

Page({
  data: {
    showLogin: true,
    loginRole: 'user',
    usernameInput: '',
    passwordInput: '',
    loginErrorText: '',
    loginRoleOptions: [
      { value: 'user', label: '用户登录' },
      { value: 'admin', label: '管理员登录' }
    ],
    loginTips: {
      userAccount: 'user',
      userPassword: '123456',
      adminAccount: 'admin',
      adminPassword: 'admin123'
    },
    activeCategory: '全部',
    categoryList: [
      { name: '全部', icon: '✨', desc: '全部饮品' },
      { name: '招牌奶茶', icon: '🧋', desc: '经典奶香' },
      { name: '果茶', icon: '🍉', desc: '清爽果香' },
      { name: '咖啡', icon: '☕', desc: '提神特调' }
    ],
    serviceTags: ['现做现出', '支持自定义', '人气热卖'],
    statsList: [
      { value: '30+', label: '精选饮品' },
      { value: '现做', label: '新鲜出杯' },
      { value: '自定义', label: '甜度冰量' }
    ],

    storeStatus: 'open',
    storeStatusText: '营业中',
    storeStatusDesc: '当前可正常下单',
    storeStatusClass: 'sale-status-on',
    canOrder: true,

    allProducts: [],

    featuredProduct: null,
    showProducts: [],
    productCount: 0,

    searchKeyword: '',
    quickSearchList: ['西瓜椰椰', '芋泥', '咖啡', '珍珠', '椰香'],
    resultTip: '支持按名称、描述和标签搜索',
    emptyTitle: '当前分类下暂无商品',
    emptyDesc: '试试切换到其他分类看看吧',

    favoriteList: [],
    favoriteIdMap: {},
    storeLogo: '',
    storeLogoDisplay: '',
    storeCover: '',
    storeCoverDisplay: '',
    loginLoading: false
  },

  onLoad() {
    this.renderLocalSnapshot();
  },

  async onShow() {
    await this.handlePageEntry();
  },

  async handlePageEntry(forceRefresh = false) {
    if (this._entryPromise) {
      return this._entryPromise;
    }

    this._entryPromise = this.runPageEntry(forceRefresh)
      .finally(() => {
        this._entryPromise = null;
      });

    return this._entryPromise;
  },

  async runPageEntry(forceRefresh = false) {
    const authInfo = this.getAuthInfo();

    if (!authInfo || !authInfo.role) {
      this.setData({
        showLogin: false
      });

      wx.reLaunch({
        url: '/pages/login/login'
      });
      return;
    }

    if (authInfo.role === 'admin') {
      this.setData({
        showLogin: false
      });

      wx.redirectTo({
        url: '/pages/admin/admin'
      });
      return;
    }

    this.setData({
      showLogin: false,
      loginErrorText: '',
      passwordInput: ''
    });

    this.renderLocalSnapshot();

    const lastSyncAt = Number(wx.getStorageSync(HOME_REFRESH_KEY) || 0);
    const shouldUseCacheOnly = !forceRefresh
      && this.data.allProducts.length > 0
      && Date.now() - lastSyncAt < HOME_REFRESH_INTERVAL;

    if (shouldUseCacheOnly) {
      return;
    }

    try {
      await Promise.all([
        cloudUser.getUserData(),
        cloudShop.syncShopStateToLocal(),
        this.loadProductListFromCloud()
      ]);
      wx.setStorageSync(HOME_REFRESH_KEY, Date.now());
    } catch (err) {
      console.error('首页同步云端数据失败', err);
    }

    await this.syncStoreVisual();
    this.syncFavoriteState();
    this.syncStoreStatus();
    this.updateProducts();
  },

  renderLocalSnapshot() {
    this.syncFavoriteState();
    this.syncStoreStatus();
    this.loadProductListFromLocal();
    this.syncStoreVisual();
    this.updateProducts();
  },

  async syncStoreVisual() {
    const config = wx.getStorageSync('storeStatusConfig') || {};
    const storeMedia = await cloudFile.attachDisplayUrls({
      storeLogo: config.storeLogo || '',
      storeCover: config.storeCover || ''
    }, ['storeLogo', 'storeCover'], {
      preferTempUrl: true
    });

    this.setData({
      storeLogo: storeMedia.storeLogo || '',
      storeLogoDisplay: storeMedia.storeLogoDisplay || '',
      storeCover: storeMedia.storeCover || '',
      storeCoverDisplay: storeMedia.storeCoverDisplay || ''
    });
  },

  async loadProductListFromLocal() {
    const localList = wx.getStorageSync('productListLatest') || [];
    if (!Array.isArray(localList) || !localList.length) {
      return;
    }

    const allProducts = await cloudFile.attachDisplayUrlsForList(localList, ['icon'], {
      preferTempUrl: true
    });

    this.applyProductList(allProducts);
  },

  async loadProductListFromCloud() {
    const res = await cloudProduct.listProducts();
    const rawProducts = Array.isArray(res.list) ? res.list : [];
    const allProducts = await cloudFile.attachDisplayUrlsForList(rawProducts, ['icon'], {
      preferTempUrl: true
    });

    this.applyProductList(allProducts);
  },

  applyProductList(allProducts = []) {
    const categoryMetaMap = {
      '招牌奶茶': { icon: '🧋', desc: '经典奶香' },
      '果茶': { icon: '🍉', desc: '清爽果香' },
      '咖啡': { icon: '☕', desc: '提神特调' }
    };

    const categoryNameList = Array.from(
      new Set(
        allProducts
          .map(item => String(item.category || '').trim())
          .filter(Boolean)
      )
    );

    const categoryList = [
      { name: '全部', icon: '✨', desc: '全部饮品' },
      ...categoryNameList.map(name => ({
        name,
        icon: (categoryMetaMap[name] && categoryMetaMap[name].icon) || '🥤',
        desc: (categoryMetaMap[name] && categoryMetaMap[name].desc) || '店内饮品'
      }))
    ];

    const nextData = {
      allProducts,
      categoryList,
      statsList: [
        { value: `${allProducts.length}+`, label: '精选饮品' },
        { value: '现做', label: '新鲜出杯' },
        { value: '自定义', label: '甜度冰量' }
      ]
    };

    if (!categoryList.some(item => item.name === this.data.activeCategory)) {
      nextData.activeCategory = '全部';
    }

    this.setData(nextData);
  },

  getAuthInfo() {
    const app = getApp();
    if (app && app.getAuthInfo) {
      return app.getAuthInfo();
    }

    return wx.getStorageSync('authInfo') || null;
  },
  

  chooseLoginRole(e) {
    const role = e.currentTarget.dataset.role || 'user';
    this.setData({
      loginRole: role,
      loginErrorText: ''
    });
  },

  onUsernameInput(e) {
    this.setData({
      usernameInput: String(e.detail.value || '').trim(),
      loginErrorText: ''
    });
  },

  onPasswordInput(e) {
    this.setData({
      passwordInput: String(e.detail.value || '').trim(),
      loginErrorText: ''
    });
  },

  async submitLogin() {
    if (this.data.loginLoading) return;

    const username = String(this.data.usernameInput || '').trim();
    const password = String(this.data.passwordInput || '').trim();
    const loginRole = this.data.loginRole;

    if (!username || !password) {
      this.setData({
        loginErrorText: '请输入账号和密码'
      });
      return;
    }

    this.setData({
      loginLoading: true,
      loginErrorText: ''
    });

    try {
      const res = loginRole === 'admin'
        ? await cloudAuth.adminEntry(username, password)
        : await cloudAuth.userLogin(username, password);

      const authInfo = (res && res.authInfo) || {};
      const app = getApp();

      if (app && app.setAuthInfo) {
        app.setAuthInfo(authInfo);
      } else {
        wx.setStorageSync('authInfo', authInfo);
      }

      this.setData({
        passwordInput: '',
        showLogin: false
      });

      if (authInfo.role === 'admin') {
        wx.redirectTo({
          url: '/pages/admin/admin'
        });
        return;
      }

      this.renderLocalSnapshot();
      this.handlePageEntry(true);

      wx.showToast({
        title: '登录成功',
        icon: 'success'
      });
    } catch (err) {
      this.setData({
        loginErrorText: (err && err.message) || (loginRole === 'user' ? '普通用户账号或密码错误' : '管理员账号或密码错误')
      });
    } finally {
      this.setData({
        loginLoading: false
      });
    }
  },

  getFavoriteList() {
    return wx.getStorageSync('favoriteList') || [];
  },

  getProductStatusMap() {
    return wx.getStorageSync('productStatusMap') || {};
  },

  syncStoreStatus() {
    const config = wx.getStorageSync('storeStatusConfig') || {};
    const status = config.status || 'open';

    if (status === 'pause') {
      this.setData({
        storeStatus: 'pause',
        storeStatusText: '暂停接单',
        storeStatusDesc: '当前暂不可下单',
        storeStatusClass: 'sale-status-soldout',
        canOrder: false
      });
      return;
    }

    if (status === 'closed') {
      this.setData({
        storeStatus: 'closed',
        storeStatusText: '已打烊',
        storeStatusDesc: '当前暂不可下单',
        storeStatusClass: 'sale-status-paused',
        canOrder: false
      });
      return;
    }

    this.setData({
      storeStatus: 'open',
      storeStatusText: '营业中',
      storeStatusDesc: '当前可正常下单',
      storeStatusClass: 'sale-status-on',
      canOrder: true
    });
  },

  getSaleStatusInfo(productInput) {
    const baseProduct = typeof productInput === 'object' ? productInput : { id: productInput };
    const runtime = productState.buildProductRuntime(baseProduct);
    const status = runtime.effectiveStatus;

    if (status === 'soldout') {
      return {
        saleStatus: 'soldout',
        saleStatusText: '已售罄',
        saleStatusClass: 'sale-status-soldout',
        saleTagText: '已售罄',
        isAvailable: false,
        actionText: '已售罄',
        stock: runtime.stock,
        stockText: runtime.stockText
      };
    }

    if (status === 'paused') {
      return {
        saleStatus: 'paused',
        saleStatusText: '暂停售卖',
        saleStatusClass: 'sale-status-paused',
        saleTagText: '暂停中',
        isAvailable: false,
        actionText: '暂停中',
        stock: runtime.stock,
        stockText: runtime.stockText
      };
    }

    return {
      saleStatus: 'on',
      saleStatusText: runtime.stockText,
      saleStatusClass: 'sale-status-on',
      saleTagText: runtime.stockShortText,
      isAvailable: true,
      actionText: '选规格',
      stock: runtime.stock,
      stockText: runtime.stockText
    };
  },

  syncFavoriteState() {
    const favoriteList = this.getFavoriteList();
    const favoriteIdMap = {};

    favoriteList.forEach(item => {
      favoriteIdMap[item.id] = true;
    });

    this.setData({
      favoriteList,
      favoriteIdMap
    });
  },

  chooseCategory(e) {
    const category = e.currentTarget.dataset.category;

    this.setData({
      activeCategory: category
    });

    this.updateProducts();
  },

  onSearchInput(e) {
    const value = (e.detail.value || '').trim();

    this.setData({
      searchKeyword: value
    });

    this.updateProducts();
  },

  useQuickSearch(e) {
    const keyword = e.currentTarget.dataset.keyword || '';

    this.setData({
      searchKeyword: keyword
    });

    this.updateProducts();
  },

  clearSearch() {
    if (!this.data.searchKeyword) return;

    this.setData({
      searchKeyword: ''
    });

    this.updateProducts();
  },

  normalizeText(text) {
    return String(text || '').toLowerCase().replace(/\s+/g, '');
  },

  getSearchTarget(item) {
    return this.normalizeText([
      item.name,
      item.desc,
      item.tag,
      item.category
    ].join('|'));
  },

  updateProducts() {
    const { activeCategory, allProducts, searchKeyword, favoriteIdMap, canOrder, storeStatusText, storeStatusClass } = this.data;
    const normalizedKeyword = this.normalizeText(searchKeyword);

    let filteredProducts = activeCategory === '全部'
      ? allProducts.slice()
      : allProducts.filter(item => item.category === activeCategory);

    if (normalizedKeyword) {
      filteredProducts = filteredProducts.filter(item => {
        const searchTarget = this.getSearchTarget(item);
        return searchTarget.includes(normalizedKeyword);
      });
    }

    const showProducts = filteredProducts.map((item, index) => {
      const saleInfo = this.getSaleStatusInfo(item);

      const finalAvailable = canOrder && saleInfo.isAvailable;
      const finalSaleText = canOrder ? saleInfo.saleTagText : storeStatusText;
      const finalSaleClass = canOrder ? saleInfo.saleStatusClass : storeStatusClass;
      const finalActionText = canOrder ? saleInfo.actionText : storeStatusText;

      return {
        ...item,
        ...saleInfo,
        isAvailable: finalAvailable,
        saleTagText: finalSaleText,
        saleStatusClass: finalSaleClass,
        actionText: finalActionText,
        salesText: `${86 + item.id * 7}人已点`,
        themeClass: this.getThemeClass(item.category),
        descShort: item.desc.length > 22 ? `${item.desc.slice(0, 22)}...` : item.desc,
        cardOrder: index + 1,
        isFavorite: !!favoriteIdMap[item.id]
      };
    });

    const featuredProduct = this.getFeaturedProduct(filteredProducts);

    let resultTip = '支持按名称、描述和标签搜索';
    let emptyTitle = '当前分类下暂无商品';
    let emptyDesc = '试试切换到其他分类看看吧';

    if (searchKeyword) {
      resultTip = `搜索“${searchKeyword}”共找到 ${filteredProducts.length} 款`;
      emptyTitle = '没有找到相关饮品';
      emptyDesc = '换个关键词试试，比如椰椰、芋泥、咖啡、珍珠';
    } else {
      resultTip = `${activeCategory}分类下共有 ${filteredProducts.length} 款饮品`;
    }

    this.setData({
      showProducts,
      featuredProduct,
      productCount: filteredProducts.length,
      resultTip,
      emptyTitle,
      emptyDesc
    });
  },

  getFeaturedProduct(list) {
    if (!list || !list.length) return null;

    let target = null;

    if (this.data.searchKeyword) {
      target = list[0];
    } else if (this.data.activeCategory === '全部') {
      target = list.find(item => item.id === 11) || list[0];
    } else if (this.data.activeCategory === '招牌奶茶') {
      target = list.find(item => item.id === 1) || list[0];
    } else if (this.data.activeCategory === '果茶') {
      target = list.find(item => item.id === 11) || list[0];
    } else if (this.data.activeCategory === '咖啡') {
      target = list.find(item => item.id === 23) || list[0];
    } else {
      target = list[0];
    }

    const saleInfo = this.getSaleStatusInfo(target);
    const finalAvailable = this.data.canOrder && saleInfo.isAvailable;
    const finalSaleText = this.data.canOrder ? saleInfo.saleStatusText : this.data.storeStatusText;
    const finalSaleClass = this.data.canOrder ? saleInfo.saleStatusClass : this.data.storeStatusClass;
    const finalActionText = this.data.canOrder ? (finalAvailable ? '立即定制' : saleInfo.actionText) : this.data.storeStatusText;

    return {
      ...target,
      ...saleInfo,
      isAvailable: finalAvailable,
      saleStatusText: finalSaleText,
      saleStatusClass: finalSaleClass,
      actionText: finalActionText,
      themeClass: this.getThemeClass(target.category),
      featuredLabel: this.getFeaturedLabel(target.category),
      featuredSubTitle: this.getFeaturedSubTitle(target),
      isFavorite: !!this.data.favoriteIdMap[target.id]
    };
  },

  getThemeClass(category) {
    if (category === '招牌奶茶') return 'theme-milk';
    if (category === '果茶') return 'theme-fruit';
    if (category === '咖啡') return 'theme-coffee';
    return 'theme-default';
  },

  getFeaturedLabel(category) {
    if (category === '招牌奶茶') return '经典奶香推荐';
    if (category === '果茶') return '今日清爽招牌';
    if (category === '咖啡') return '现磨咖啡推荐';
    return '本店精选';
  },

  getFeaturedSubTitle(item) {
    if (!item) return '';
    return `${item.name} · ${item.tag}`;
  },

  buildFavoriteItem(item) {
    return {
      id: item.id,
      name: item.name,
      desc: item.desc,
      price: Number(item.price || 0),
      category: item.category,
      tag: item.tag,
      icon: item.icon,
      iconType: item.iconType,
      collectedAt: Date.now()
    };
  },

  async toggleFavorite(e) {
    const item = e.currentTarget.dataset.item;
    if (!item || !item.id) return;
  
    let favoriteList = this.getFavoriteList();
    const index = favoriteList.findIndex(target => Number(target.id) === Number(item.id));
  
    if (index > -1) {
      favoriteList.splice(index, 1);
  
      try {
        await cloudUser.saveFavoriteList(favoriteList);
  
        wx.showToast({
          title: '已取消收藏',
          icon: 'success'
        });
      } catch (err) {
        wx.showToast({
          title: (err && err.message) || '取消收藏失败',
          icon: 'none'
        });
        return;
      }
    } else {
      favoriteList.unshift(this.buildFavoriteItem(item));
  
      const uniqueMap = {};
      favoriteList = favoriteList.filter(target => {
        const key = String(target.id);
        if (uniqueMap[key]) return false;
        uniqueMap[key] = true;
        return true;
      });
  
      try {
        await cloudUser.saveFavoriteList(favoriteList);
  
        wx.showToast({
          title: '已加入收藏',
          icon: 'success'
        });
      } catch (err) {
        wx.showToast({
          title: (err && err.message) || '加入收藏失败',
          icon: 'none'
        });
        return;
      }
    }
  
    this.syncFavoriteState();
    this.updateProducts();
  },

  goDetail(e) {
    const item = e.currentTarget.dataset.item;
    if (!item || !item.id) return;

    wx.setStorageSync('currentFood', item);

    wx.navigateTo({
      url: '/pages/detail/detail'
    });
  },

  goFeaturedDetail() {
    const { featuredProduct } = this.data;
    if (!featuredProduct) return;

    wx.setStorageSync('currentFood', featuredProduct);

    wx.navigateTo({
      url: '/pages/detail/detail'
    });
  }
});