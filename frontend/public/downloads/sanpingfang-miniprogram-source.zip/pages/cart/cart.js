const cloudUser = require('../../utils/cloud-user');
const cloudShop = require('../../utils/cloud-shop');
const cloudProduct = require('../../utils/cloud-product');
const productState = require('../../utils/product-state');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    cartList: [],
    selectedCartIds: [],
    selectedTotalPrice: '0.00',
    selectedTotalCount: 0,
    selectedTypeCount: 0,
    allChecked: false
  },

  async onShow() {
    await this.syncCartFromCloud();
  },

  async syncCartFromCloud() {
    try {
      await Promise.all([
        cloudUser.getUserData(),
        cloudShop.syncShopStateToLocal(),
        cloudProduct.listProducts()
      ]);
    } catch (err) {
      console.error('同步购物车失败', err);
    }

    await this.getCartList();
  },

  getItemUnavailableReason(item) {
    return productState.getUnavailableReason({ id: item.id }, Number(item.quantity || 0));
  },

  async getCartList() {
    const rawCartList = wx.getStorageSync('cartList') || [];
    const currentCheckMap = {};

    (this.data.cartList || []).forEach(item => {
      currentCheckMap[item.cartId] = !!item.checked;
    });

    const cartListRaw = rawCartList.map(item => {
      const price = Number(item.price || 0);
      const quantity = Number(item.quantity || 0);
      const subtotal = price * quantity;
      const runtime = productState.buildProductRuntime({ id: item.id });
      const unavailableReason = this.getItemUnavailableReason(item);

      const specList = [
        item.size ? `杯型：${item.size}` : '',
        item.sweet ? `甜度：${item.sweet}` : '',
        item.ice ? `冰量：${item.ice}` : ''
      ].filter(Boolean);

      const toppingText = item.toppingsText || '不加小料';
      const toppingModeText = item.toppingModeText || '无';

      let checked = true;
      if (Object.prototype.hasOwnProperty.call(currentCheckMap, item.cartId)) {
        checked = currentCheckMap[item.cartId];
      }

      if (unavailableReason) {
        checked = false;
      }

      return {
        ...item,
        priceText: price.toFixed(2),
        itemSubtotal: subtotal.toFixed(2),
        specSummary: specList.join(' / '),
        toppingSummary: `小料：${toppingText}`,
        toppingModeSummary: `处理方式：${toppingModeText}`,
        tagText: item.tag || item.category || '本店精选',
        unavailableReason,
        isAvailable: !unavailableReason,
        checked,
        stock: runtime.stock,
        stockText: runtime.stockText
      };
    });

    const cartList = await cloudFile.attachDisplayUrlsForList(cartListRaw, ['icon']);

    this.setData({ cartList });
    this.calculateSelectedSummary();
  },

  calculateSelectedSummary() {
    const cartList = this.data.cartList || [];
    const availableList = cartList.filter(item => item.isAvailable);
    const checkedList = cartList.filter(item => item.isAvailable && item.checked);

    let selectedTotalPrice = 0;
    let selectedTotalCount = 0;

    checkedList.forEach(item => {
      selectedTotalPrice += Number(item.price || 0) * Number(item.quantity || 0);
      selectedTotalCount += Number(item.quantity || 0);
    });

    const allChecked = availableList.length > 0 && checkedList.length === availableList.length;
    const selectedCartIds = checkedList.map(item => item.cartId);

    this.setData({
      selectedCartIds,
      selectedTotalPrice: selectedTotalPrice.toFixed(2),
      selectedTotalCount,
      selectedTypeCount: checkedList.length,
      allChecked
    });
  },

  toggleSelectItem(e) {
    const cartId = e.currentTarget.dataset.id;

    const cartList = (this.data.cartList || []).map(item => {
      if (item.cartId === cartId && item.isAvailable) {
        return { ...item, checked: !item.checked };
      }
      return item;
    });

    this.setData({ cartList });
    this.calculateSelectedSummary();
  },

  toggleSelectAll() {
    const nextChecked = !this.data.allChecked;

    const cartList = (this.data.cartList || []).map(item => {
      if (!item.isAvailable) return item;
      return { ...item, checked: nextChecked };
    });

    this.setData({ cartList });
    this.calculateSelectedSummary();
  },

  async changeCount(e) {
    const cartId = e.currentTarget.dataset.id;
    const type = e.currentTarget.dataset.type;

    let cartList = wx.getStorageSync('cartList') || [];

    const target = cartList.find(item => item.cartId === cartId) || {};
    const runtime = productState.buildProductRuntime({ id: target.id });
    const maxStock = Math.max(0, Number(runtime.stock || 0));

    cartList = cartList.map(item => {
      if (item.cartId === cartId) {
        let quantity = Number(item.quantity || 1);

        if (type === 'minus' && quantity > 1) {
          quantity -= 1;
        }

        if (type === 'plus') {
          if (maxStock <= 0) {
            wx.showToast({ title: '商品已售罄', icon: 'none' });
            return item;
          }
          if (quantity >= maxStock) {
            wx.showToast({ title: `库存不足，仅剩 ${maxStock} 杯`, icon: 'none' });
            return item;
          }
          quantity += 1;
        }

        return { ...item, quantity };
      }

      return item;
    });

    try {
      await cloudUser.saveCartList(cartList);
      this.getCartList();
    } catch (err) {
      wx.showToast({ title: (err && err.message) || '更新购物车失败', icon: 'none' });
    }
  },

  async removeItem(e) {
    const cartId = e.currentTarget.dataset.id;
    let cartList = wx.getStorageSync('cartList') || [];

    cartList = cartList.filter(item => item.cartId !== cartId);

    try {
      await cloudUser.saveCartList(cartList);
      wx.showToast({ title: '已删除', icon: 'success' });
      this.getCartList();
    } catch (err) {
      wx.showToast({ title: (err && err.message) || '删除失败', icon: 'none' });
    }
  },

  clearCart() {
    const cartList = this.data.cartList || [];

    if (!cartList.length) {
      wx.showToast({ title: '购物车已为空', icon: 'none' });
      return;
    }

    wx.showModal({
      title: '清空购物车',
      content: '确定清空当前购物车中的所有饮品吗？',
      success: async (res) => {
        if (!res.confirm) return;

        try {
          await cloudUser.saveCartList([]);

          this.setData({
            cartList: [],
            selectedCartIds: [],
            selectedTotalPrice: '0.00',
            selectedTotalCount: 0,
            selectedTypeCount: 0,
            allChecked: false
          });

          wx.showToast({ title: '已清空', icon: 'success' });
        } catch (err) {
          wx.showToast({ title: (err && err.message) || '清空失败', icon: 'none' });
        }
      }
    });
  },

  goHome() {
    wx.switchTab({ url: '/pages/home/home' });
  },

  goSubmitOrder() {
    const cartList = this.data.cartList || [];
    const checkedList = cartList.filter(item => item.isAvailable && item.checked);

    if (!checkedList.length) {
      wx.showToast({ title: '请先勾选要下单的商品', icon: 'none' });
      return;
    }

    wx.setStorageSync('checkoutCartList', checkedList);
    wx.setStorageSync('checkoutCartIds', checkedList.map(item => item.cartId));
    wx.removeStorageSync('checkoutOrderRemark');
    wx.removeStorageSync('checkoutPickupMode');
    wx.removeStorageSync('checkoutReserveDate');
    wx.removeStorageSync('checkoutReserveDateLabel');
    wx.removeStorageSync('checkoutReserveTime');
    wx.removeStorageSync('checkoutCouponId');

    wx.switchTab({ url: '/pages/orders/orders' });
  }
});
