const cloudAccount = require('../../utils/cloud-account');
const mediaUploader = require('../../utils/media-uploader');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    role: 'user',
    title: '账号设置',
    currentUsername: '',
    newUsername: '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    avatarUrl: '',
    avatarUrlDisplay: '',
    loading: false,
    avatarSaving: false
  },

  async onShow() {
    const authInfo = wx.getStorageSync('authInfo') || {};
    const role = authInfo.role || 'user';
    const avatarUrl = authInfo.avatarUrl || '';
    const avatarUrlDisplay = await cloudFile.resolveImageUrl(avatarUrl);

    this.setData({
      role,
      title: role === 'admin' ? '管理员账号设置' : '用户账号设置',
      currentUsername: authInfo.username || '',
      newUsername: authInfo.username || '',
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
      avatarUrl: avatarUrlDisplay || avatarUrl,
      avatarUrlDisplay
    });
  },

  onInput(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({
      [field]: e.detail.value || ''
    });
  },

  getAccountPayload(extra = {}) {
    const authInfo = wx.getStorageSync('authInfo') || {};
    return {
      role: authInfo.role || this.data.role || 'user',
      userId: authInfo.userId || '',
      adminId: authInfo.adminId || '',
      ...extra
    };
  },

  async saveAvatar(avatarUrl, previewUrl = '') {
    await cloudAccount.updateAccount(this.getAccountPayload({
      avatarUrl
    }));

    const latestAuthInfo = wx.getStorageSync('authInfo') || {};
    const nextAvatarUrl = latestAuthInfo.avatarUrl || avatarUrl || '';
    const avatarUrlDisplay = previewUrl || await cloudFile.resolveImageUrl(nextAvatarUrl);
    this.setData({
      avatarUrl: avatarUrlDisplay || nextAvatarUrl,
      avatarUrlDisplay
    });
  },

  async chooseAvatarImage() {
    if (this.data.avatarSaving) return;

    this.setData({
      avatarSaving: true
    });

    try {
      const folder = this.data.role === 'admin' ? 'avatars/admin' : 'avatars/user';
      const upload = await mediaUploader.chooseAndUploadImage(folder);
      await this.saveAvatar(upload.fileID, upload.tempFilePath || '');
      wx.showToast({
        title: '头像已更新',
        icon: 'success'
      });
    } catch (err) {
      if ((err && err.message) === '已取消选择图片') return;
      wx.showToast({
        title: (err && err.message) || '上传失败',
        icon: 'none'
      });
    } finally {
      this.setData({
        avatarSaving: false
      });
    }
  },

  async clearAvatarImage() {
    if (this.data.avatarSaving) return;

    this.setData({
      avatarSaving: true
    });

    try {
      await this.saveAvatar('', '');
      wx.showToast({
        title: '已恢复默认头像',
        icon: 'success'
      });
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '操作失败',
        icon: 'none'
      });
    } finally {
      this.setData({
        avatarSaving: false
      });
    }
  },

  async submitUpdate() {
    if (this.data.loading) return;

    const authInfo = wx.getStorageSync('authInfo') || {};
    const role = authInfo.role || 'user';
    const newUsername = String(this.data.newUsername || '').trim();
    const currentPassword = String(this.data.currentPassword || '');
    const newPassword = String(this.data.newPassword || '');
    const confirmPassword = String(this.data.confirmPassword || '');
    const hasUsernameChange = !!newUsername && newUsername !== String(authInfo.username || '');
    const hasPasswordChange = !!newPassword;

    if (!hasUsernameChange && !hasPasswordChange) {
      wx.showToast({
        title: '请先修改账号名或密码',
        icon: 'none'
      });
      return;
    }

    if (!currentPassword) {
      wx.showToast({
        title: '请输入当前密码',
        icon: 'none'
      });
      return;
    }

    if (newPassword && newPassword !== confirmPassword) {
      wx.showToast({
        title: '两次输入的新密码不一致',
        icon: 'none'
      });
      return;
    }

    this.setData({
      loading: true
    });

    try {
      await cloudAccount.updateAccount(this.getAccountPayload({
        role,
        currentPassword,
        newUsername,
        newPassword
      }));

      wx.showToast({
        title: '账号信息已更新',
        icon: 'success'
      });

      const latestAuthInfo = wx.getStorageSync('authInfo') || {};

      const nextAvatarUrl = latestAuthInfo.avatarUrl || this.data.avatarUrl;
      this.setData({
        currentUsername: latestAuthInfo.username || newUsername || this.data.currentUsername,
        newUsername: latestAuthInfo.username || newUsername || this.data.newUsername,
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
        avatarUrl: nextAvatarUrl
      });

      const avatarUrlDisplay = await cloudFile.resolveImageUrl(nextAvatarUrl);
      this.setData({
        avatarUrl: avatarUrlDisplay || nextAvatarUrl,
        avatarUrlDisplay
      });
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '更新失败',
        icon: 'none'
      });
    } finally {
      this.setData({
        loading: false
      });
    }
  }
});
