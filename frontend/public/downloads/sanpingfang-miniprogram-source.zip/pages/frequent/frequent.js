const cloudOrder = require('../../utils/cloud-order');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    frequentList: []
  },

  async onShow() {
    await this.loadFrequentList();
  },

  async loadFrequentList() {
    let ordersList = [];

    try {
      const res = await cloudOrder.listMyOrders();
      ordersList = Array.isArray(res.ordersList) ? res.ordersList : [];
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '读取常喝数据失败',
        icon: 'none'
      });
    }

    const productMap = {};

    ordersList.forEach(order => {
      const items = Array.isArray(order.items) ? order.items : [];

      items.forEach(item => {
        const id = Number(item.id);
        if (!id) return;

        if (!productMap[id]) {
          productMap[id] = {
            id: item.id,
            name: item.name,
            desc: item.desc,
            price: Number(item.price || 0),
            category: item.category || '',
            tag: item.tag || '常喝推荐',
            icon: item.icon,
            iconType: item.iconType,
            totalCount: 0
          };
        }

        productMap[id].totalCount += Number(item.quantity || 0);
      });
    });

    const frequentListRaw = Object.values(productMap)
      .sort((a, b) => b.totalCount - a.totalCount)
      .slice(0, 20)
      .map(item => ({
        ...item,
        priceText: Number(item.price || 0).toFixed(2),
        countText: `已点 ${item.totalCount} 杯`
      }));

    const frequentList = await cloudFile.attachDisplayUrlsForList(frequentListRaw, ['icon']);

    this.setData({
      frequentList
    });
  },

  openProductDetail(e) {
    const product = e.currentTarget.dataset.product;

    if (!product || !product.id) {
      wx.showToast({
        title: '商品信息异常',
        icon: 'none'
      });
      return;
    }

    wx.setStorageSync('currentFood', product);

    wx.navigateTo({
      url: '/pages/detail/detail'
    });
  }
});