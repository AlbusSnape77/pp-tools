const cloudOrder = require('../../utils/cloud-order');
const cloudFeedback = require('../../utils/cloud-feedback');
const cloudShop = require('../../utils/cloud-shop');
const cloudAccount = require('../../utils/cloud-account');
const mediaUploader = require('../../utils/media-uploader');
const cloudFile = require('../../utils/cloud-file');

Page({
  data: {
    adminName: 'admin',
    adminAvatar: '',
    avatarSaving: false,
    summary: {
      totalOrders: 0,
      todayOrders: 0,
      todayRevenue: '0.00',
      pendingCount: 0,
      makingCount: 0,
      readyCount: 0,
      completedCount: 0,
      cancelledCount: 0,
      feedbackCount: 0,
      backlogCount: 0,
      completionRate: '0.0'
    },
    latestOrder: null,
    latestFeedback: null,
    operationHint: '当前门店数据正常',
    storeStatus: 'open',
    storeStatusText: '营业中'
  },

  async onShow() {
    if (!(await this.checkAdminAccess())) return;
    await this.syncDashboardData();
  },

  async checkAdminAccess() {
    const authInfo = wx.getStorageSync('authInfo') || null;

    if (!authInfo || authInfo.role !== 'admin') {
      wx.reLaunch({
        url: '/pages/login/login'
      });
      return false;
    }

    const adminAvatar = await cloudFile.resolveImageUrl(authInfo.avatarUrl || '');

    this.setData({
      adminName: authInfo.username || 'admin',
      adminAvatar
    });

    return true;
  },

  async changeAvatarDirectly() {
    if (this.data.avatarSaving) return;

    const authInfo = wx.getStorageSync('authInfo') || {};
    if (authInfo.role !== 'admin') {
      wx.showToast({ title: '请先登录管理员账号', icon: 'none' });
      return;
    }

    this.setData({ avatarSaving: true });

    try {
      const upload = await mediaUploader.chooseAndUploadImage('avatars/admin');
      await cloudAccount.updateAccount({
        role: 'admin',
        adminId: authInfo.adminId || '',
        avatarUrl: upload.fileID
      });

      const latestAuthInfo = wx.getStorageSync('authInfo') || {};
      const adminAvatar = upload.tempFilePath || await cloudFile.resolveImageUrl(latestAuthInfo.avatarUrl || upload.fileID);
      this.setData({
        adminAvatar,
        adminName: latestAuthInfo.username || this.data.adminName
      });

      wx.showToast({ title: '头像已更新', icon: 'success' });
    } catch (err) {
      if ((err && err.message) === '已取消选择图片') return;
      wx.showToast({
        title: (err && err.message) || '头像更新失败',
        icon: 'none'
      });
    } finally {
      this.setData({ avatarSaving: false });
    }
  },

  async syncDashboardData() {
    try {
      const [orderRes, feedbackList, shopState] = await Promise.all([
        cloudOrder.listAllOrders(),
        cloudFeedback.syncAllFeedbackToLocal(),
        cloudShop.syncShopStateToLocal()
      ]);

      const ordersList = this.normalizeOrdersList(orderRes.ordersList || []);
      const normalizedFeedbackList = this.normalizeFeedbackList(feedbackList || []);

      this.applyStoreStatus(shopState.storeConfig || {});
      this.getSummaryData(ordersList, normalizedFeedbackList);
    } catch (err) {
      wx.showToast({
        title: (err && err.message) || '读取工作台数据失败',
        icon: 'none'
      });
    }
  },

  applyStoreStatus(config = {}) {
    const status = config.status || 'open';

    if (status === 'pause') {
      this.setData({
        storeStatus: 'pause',
        storeStatusText: '暂停接单'
      });
      return;
    }

    if (status === 'closed') {
      this.setData({
        storeStatus: 'closed',
        storeStatusText: '已打烊'
      });
      return;
    }

    this.setData({
      storeStatus: 'open',
      storeStatusText: '营业中'
    });
  },

  normalizeFeedbackList(list) {
    return list.map(item => {
      const status = item.status === '已处理' ? '已处理' : '待处理';

      return {
        ...item,
        type: item.type || '未分类反馈',
        status,
        contact: item.contact || '',
        statusClass: status === '已处理' ? 'status-done' : 'status-pending'
      };
    });
  },

  normalizeOrdersList(list) {
    return list.map(order => {
      const items = Array.isArray(order.items) ? order.items : [];
      const itemCount = items.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
      const itemSummary = items.length
        ? items.slice(0, 2).map(item => `${item.name} x${item.quantity || 0}`).join('、')
        : '暂无商品信息';

      return {
        ...order,
        itemCount,
        itemSummary,
        totalPriceText: Number(order.totalPrice || 0).toFixed(2),
        payablePriceText: Number(order.payablePrice || order.totalPrice || 0).toFixed(2),
        statusClass: this.getOrderStatusClass(order.status)
      };
    });
  },

  getOrderStatusClass(status) {
    if (status === '待处理') return 'status-pending';
    if (status === '制作中') return 'status-making';
    if (status === '待取餐') return 'status-ready';
    if (status === '已完成') return 'status-finished';
    return 'status-cancelled';
  },

  getSummaryData(ordersList, feedbackList) {
    const today = new Date();

    let totalOrders = ordersList.length;
    let todayOrders = 0;
    let todayRevenue = 0;
    let pendingCount = 0;
    let makingCount = 0;
    let readyCount = 0;
    let completedCount = 0;
    let cancelledCount = 0;

    ordersList.forEach(order => {
      const orderDate = this.parseDate(order.createTime);

      if (this.isSameDay(orderDate, today)) {
        todayOrders += 1;
        if (order.status === '已完成') {
          todayRevenue += Number(order.payablePrice || order.totalPrice || 0);
        }
      }

      if (order.status === '待处理') pendingCount += 1;
      if (order.status === '制作中') makingCount += 1;
      if (order.status === '待取餐') readyCount += 1;
      if (order.status === '已完成') completedCount += 1;
      if (order.status === '已取消') cancelledCount += 1;
    });

    const backlogCount = pendingCount + makingCount + readyCount;
    const completionRate = totalOrders > 0 ? ((completedCount / totalOrders) * 100).toFixed(1) : '0.0';

    const latestOrder = ordersList.length > 0 ? ordersList[0] : null;
    const latestFeedback = feedbackList.length > 0 ? feedbackList[0] : null;

    let operationHint = '当前门店数据正常';
    if (readyCount > 0) {
      operationHint = `当前有 ${readyCount} 单待取餐，可优先核销取餐码`;
    } else if (backlogCount >= 3) {
      operationHint = `当前有 ${backlogCount} 单待跟进，建议优先处理进行中的订单`;
    } else if (feedbackList.some(item => item.status !== '已处理')) {
      operationHint = '存在待处理反馈，建议及时查看用户意见';
    }

    this.setData({
      summary: {
        totalOrders,
        todayOrders,
        todayRevenue: todayRevenue.toFixed(2),
        pendingCount,
        makingCount,
        readyCount,
        completedCount,
        cancelledCount,
        feedbackCount: feedbackList.length,
        backlogCount,
        completionRate
      },
      latestOrder,
      latestFeedback,
      operationHint
    });
  },

  parseDate(str) {
    if (!str) return new Date();
    if (str instanceof Date) return str;
    return new Date(String(str).replace(/-/g, '/'));
  },

  isSameDay(date1, date2) {
    return (
      date1.getFullYear() === date2.getFullYear() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getDate() === date2.getDate()
    );
  },

  goOrdersPage() {
    wx.navigateTo({
      url: '/pages/admin-orders/admin-orders'
    });
  },

  goAnalyticsPage() {
    wx.navigateTo({
      url: '/pages/admin-analytics/admin-analytics'
    });
  },

  goFeedbackPage() {
    wx.navigateTo({
      url: '/pages/admin-feedback/admin-feedback'
    });
  },

  goProductsPage() {
    wx.navigateTo({
      url: '/pages/admin-products/admin-products'
    });
  },

  goStorePage() {
    wx.navigateTo({
      url: '/pages/admin-store/admin-store'
    });
  },

  goAccountSettings() {
    wx.navigateTo({
      url: '/pages/account-settings/account-settings'
    });
  },

  logout() {
    const app = getApp();

    if (app && app.clearAuthInfo) {
      app.clearAuthInfo();
    } else {
      wx.removeStorageSync('authInfo');
    }

    wx.showToast({
      title: '已退出登录',
      icon: 'success'
    });

    setTimeout(() => {
      wx.reLaunch({
        url: '/pages/login/login'
      });
    }, 300);
  }
});
