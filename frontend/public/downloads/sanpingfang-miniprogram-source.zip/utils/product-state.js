const DEFAULT_STOCK = 30;

function normalizeStock(stock) {
  const value = Number(stock);
  if (!Number.isFinite(value) || value < 0) {
    return DEFAULT_STOCK;
  }
  return Math.floor(value);
}

function getProductMap() {
  return wx.getStorageSync('productMapLatest') || {};
}

function getProductStatusMap() {
  return wx.getStorageSync('productStatusMap') || {};
}

function getStoreConfig() {
  return wx.getStorageSync('storeStatusConfig') || {};
}

function getLatestProductById(id, fallback = {}) {
  const map = getProductMap();
  return map[id] || fallback || {};
}

function getEffectiveSaleStatus(product, productStatusMap = getProductStatusMap()) {
  const target = product || {};
  const rawStatus = productStatusMap[target.id] || {};
  const manualStatus = rawStatus.status || 'on';
  const stock = normalizeStock(target.stock);

  if (manualStatus === 'paused') {
    return {
      status: 'paused',
      source: 'manual'
    };
  }

  if (manualStatus === 'soldout') {
    return {
      status: 'soldout',
      source: 'manual'
    };
  }

  if (stock <= 0) {
    return {
      status: 'soldout',
      source: 'stock'
    };
  }

  return {
    status: 'on',
    source: 'stock'
  };
}

function buildProductRuntime(product = {}) {
  const latest = getLatestProductById(product.id, {});
  const merged = {
    ...product,
    ...latest,
    id: Number((product && product.id) || (latest && latest.id) || 0)
  };

  const stock = normalizeStock(merged.stock);
  const effective = getEffectiveSaleStatus({ ...merged, stock });
  const isOutOfStock = stock <= 0;
  const isLowStock = stock > 0 && stock <= 5;

  let stockText = `余量 ${stock} 杯`;
  let stockShortText = `余量${stock}`;

  if (effective.status === 'paused') {
    stockText = '暂停售卖';
    stockShortText = '暂停';
  } else if (effective.status === 'soldout') {
    stockText = '已售罄';
    stockShortText = '已售罄';
  }

  return {
    ...merged,
    stock,
    stockText,
    stockShortText,
    isOutOfStock,
    isLowStock,
    effectiveStatus: effective.status,
    effectiveStatusSource: effective.source
  };
}

function getUnavailableReason(productLike, quantity = 1, storeConfig = getStoreConfig()) {
  const target = buildProductRuntime(productLike || {});
  const storeStatus = (storeConfig && storeConfig.status) || 'open';
  const demand = Math.max(1, Number(quantity || 1));

  if (storeStatus === 'pause') {
    return '门店暂停接单';
  }

  if (storeStatus === 'closed') {
    return '门店已打烊';
  }

  if (target.effectiveStatus === 'paused') {
    return '商品已暂停售卖';
  }

  if (target.stock <= 0 || target.effectiveStatus === 'soldout') {
    return '商品已售罄';
  }

  if (target.stock < demand) {
    return `库存不足，仅剩 ${target.stock} 杯`;
  }

  return '';
}

module.exports = {
  DEFAULT_STOCK,
  normalizeStock,
  getLatestProductById,
  getEffectiveSaleStatus,
  buildProductRuntime,
  getUnavailableReason
};
