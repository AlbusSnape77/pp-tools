function getFileExt(filePath = '') {
  const matched = String(filePath || '').match(/\.([a-zA-Z0-9]+)(?:\?|$)/);
  return matched ? matched[1].toLowerCase() : 'png';
}

function normalizeImageFile(rawFile = {}) {
  if (!rawFile) return null;

  const tempFilePath = rawFile.tempFilePath || rawFile.path || '';
  if (!tempFilePath) return null;

  return {
    tempFilePath,
    size: Number(rawFile.size || 0)
  };
}

function chooseImageByChooseMedia() {
  return new Promise((resolve, reject) => {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album'],
      success(res) {
        const file = normalizeImageFile((res.tempFiles && res.tempFiles[0]) || null);
        if (!file) {
          reject(new Error('未选择图片'));
          return;
        }
        resolve(file);
      },
      fail(err) {
        if (err && (err.errMsg || '').includes('cancel')) {
          reject(new Error('已取消选择图片'));
          return;
        }
        reject(err || new Error('选择图片失败'));
      }
    });
  });
}

function chooseImageByChooseImage() {
  return new Promise((resolve, reject) => {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album'],
      success(res) {
        const tempFilePath = (res.tempFilePaths && res.tempFilePaths[0]) || '';
        if (!tempFilePath) {
          reject(new Error('未选择图片'));
          return;
        }
        resolve({
          tempFilePath,
          size: 0
        });
      },
      fail(err) {
        if (err && (err.errMsg || '').includes('cancel')) {
          reject(new Error('已取消选择图片'));
          return;
        }
        reject(err || new Error('选择图片失败'));
      }
    });
  });
}

async function chooseSingleImageFromAlbum() {
  try {
    return await chooseImageByChooseMedia();
  } catch (err) {
    const message = String((err && err.message) || err && err.errMsg || '');
    if (message === '已取消选择图片') {
      throw err;
    }

    return chooseImageByChooseImage();
  }
}

function uploadImage(localPath, folder = 'common') {
  if (runtime.isDemo()) return Promise.resolve(localPath);
  const ext = getFileExt(localPath);
  const cloudPath = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2, 10)}.${ext}`;

  return wx.cloud.uploadFile({
    cloudPath,
    filePath: localPath
  }).then(res => {
    const fileID = res.fileID || '';
    if (!fileID) {
      throw new Error('上传图片失败');
    }
    return fileID;
  }).catch(err => {
    const message = String((err && err.errMsg) || (err && err.message) || '');
    if (message.includes('cloud')) {
      throw new Error('云存储上传失败，请确认已开通云开发并上传云函数');
    }
    throw err;
  });
}

async function chooseAndUploadImage(folder = 'common') {
  const file = await chooseSingleImageFromAlbum();
  wx.showLoading({
    title: '上传中',
    mask: true
  });

  try {
    const fileID = await uploadImage(file.tempFilePath, folder);
    return {
      fileID,
      tempFilePath: file.tempFilePath,
      size: Number(file.size || 0)
    };
  } finally {
    wx.hideLoading();
  }
}

module.exports = {
  chooseSingleImageFromAlbum,
  uploadImage,
  chooseAndUploadImage
};
const runtime = require('../config/runtime');
