const listeners = {};

function on(event, callback) {
  if (!listeners[event]) {
    listeners[event] = [];
  }
  listeners[event].push(callback);
}

function off(event, callback) {
  if (!listeners[event]) return;
  if (!callback) {
    listeners[event] = [];
    return;
  }
  listeners[event] = listeners[event].filter(fn => fn !== callback);
}

function emit(event, data) {
  if (!listeners[event]) return;
  listeners[event].forEach(fn => {
    try {
      fn(data);
    } catch (e) {
      console.error('EventBus error:', event, e);
    }
  });
}

function once(event, callback) {
  const wrapper = (data) => {
    off(event, wrapper);
    callback(data);
  };
  on(event, wrapper);
}

module.exports = { on, off, emit, once };
