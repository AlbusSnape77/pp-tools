const runtime = require('../config/runtime');

const LEGACY_FILE_ID_MAP_KEY = 'cloudFileLegacyIdMapV2';
const DEFAULT_ENV_ID = '';
const TEMP_URL_CACHE_KEY = 'cloudFileTempUrlCacheV4';
const DEFAULT_TEMP_URL_TTL = 20 * 60 * 1000;
const TEMP_URL_SAFE_BUFFER = 60 * 1000;
const MAX_TEMP_URL_CACHE_SIZE = 200;
const TEMP_URL_BATCH_SIZE = 40;
const MAX_DOWNLOAD_CONCURRENCY = 4;
const sessionLocalFileMap = {};

function trimValue(value) {
  return String(value || '').trim();
}

function isCloudFileId(value) {
  return /^cloud:\/\//i.test(trimValue(value));
}

function isLocalFilePath(value) {
  return /^(wxfile:\/\/|file:\/\/|data:image\/)/i.test(trimValue(value));
}

function isHttpUrl(value) {
  return /^https?:\/\//i.test(trimValue(value));
}

function uniq(list = []) {
  return Array.from(new Set((list || []).filter(Boolean)));
}

function getDisplayFieldName(field) {
  return `${field}Display`;
}

function chunkList(list = [], size = TEMP_URL_BATCH_SIZE) {
  const source = Array.isArray(list) ? list : [];
  const chunkSize = Math.max(1, Number(size) || TEMP_URL_BATCH_SIZE);
  const result = [];

  for (let index = 0; index < source.length; index += chunkSize) {
    result.push(source.slice(index, index + chunkSize));
  }

  return result;
}

function getNow() {
  return Date.now();
}

function getLegacyFileIdMap() {
  return wx.getStorageSync(LEGACY_FILE_ID_MAP_KEY) || {};
}

function saveLegacyFileIdMap(map) {
  wx.setStorageSync(LEGACY_FILE_ID_MAP_KEY, map || {});
}

function getTempUrlCacheMap() {
  return wx.getStorageSync(TEMP_URL_CACHE_KEY) || {};
}

function saveTempUrlCacheMap(map) {
  const source = map || {};
  const keys = Object.keys(source);

  if (keys.length <= MAX_TEMP_URL_CACHE_SIZE) {
    wx.setStorageSync(TEMP_URL_CACHE_KEY, source);
    return;
  }

  const sortedKeys = keys.sort((left, right) => {
    const leftAt = Number((source[left] && source[left].updatedAt) || 0);
    const rightAt = Number((source[right] && source[right].updatedAt) || 0);
    return rightAt - leftAt;
  });

  const nextMap = {};
  sortedKeys.slice(0, MAX_TEMP_URL_CACHE_SIZE).forEach(key => {
    nextMap[key] = source[key];
  });

  wx.setStorageSync(TEMP_URL_CACHE_KEY, nextMap);
}

function getCachedTempUrl(fileID) {
  const key = trimValue(fileID);
  if (!key) return '';

  const map = getTempUrlCacheMap();
  const record = map[key] || null;
  if (!record) return '';

  const url = trimValue(record.url);
  const expireAt = Number(record.expireAt || 0);
  if (!url) return '';

  if (expireAt > getNow() + TEMP_URL_SAFE_BUFFER) {
    return url;
  }

  delete map[key];
  saveTempUrlCacheMap(map);
  return '';
}

function saveTempUrl(fileID, url, expireAt) {
  const key = trimValue(fileID);
  const nextUrl = trimValue(url);
  if (!key || !nextUrl) return nextUrl;

  const map = getTempUrlCacheMap();
  map[key] = {
    url: nextUrl,
    expireAt: Number(expireAt || 0) || (getNow() + DEFAULT_TEMP_URL_TTL),
    updatedAt: getNow()
  };
  saveTempUrlCacheMap(map);
  return nextUrl;
}

function parseHttpUrl(value) {
  const raw = trimValue(value);
  const matched = raw.match(/^(https?:\/\/)([^\/?#]+)([^?#]*)/i);
  if (!matched) return null;

  return {
    protocol: matched[1].toLowerCase(),
    hostname: String(matched[2] || '').toLowerCase(),
    pathname: decodeURIComponent(matched[3] || '')
  };
}

function getCanonicalLegacyUrl(value) {
  const parsed = parseHttpUrl(value);
  if (!parsed) return '';
  return `${parsed.protocol}${parsed.hostname}${parsed.pathname || ''}`;
}

function getCachedLegacyFileId(value) {
  const key = getCanonicalLegacyUrl(value);
  if (!key) return '';

  const map = getLegacyFileIdMap();
  return trimValue(map[key]);
}

function saveLegacyFileId(value, fileID) {
  const key = getCanonicalLegacyUrl(value);
  const nextFileID = trimValue(fileID);
  if (!key || !nextFileID || !isCloudFileId(nextFileID)) return nextFileID;

  const map = getLegacyFileIdMap();
  map[key] = nextFileID;
  saveLegacyFileIdMap(map);
  return nextFileID;
}

function extractLegacyCloudInfo(value) {
  const raw = trimValue(value);
  if (!raw || isCloudFileId(raw) || !isHttpUrl(raw)) return null;

  const parsed = parseHttpUrl(raw);
  if (!parsed || !parsed.hostname.endsWith('.tcb.qcloud.la')) {
    return null;
  }

  const bucket = parsed.hostname.split('.')[0] || '';
  const path = String(parsed.pathname || '').replace(/^\/+/, '');
  if (!bucket || !path) {
    return null;
  }

  const envFromBucket = bucket.replace(/-\d+$/, '');
  const aliasFromEnv = envFromBucket.replace(/^[^-]+-/, '');

  return {
    bucket,
    path,
    envCandidates: uniq([DEFAULT_ENV_ID, envFromBucket, aliasFromEnv])
  };
}

function buildLegacyFileIdCandidates(value) {
  const info = extractLegacyCloudInfo(value);
  if (!info) return [];

  const candidates = [];
  info.envCandidates.forEach(env => {
    candidates.push(`cloud://${env}.${info.bucket}/${info.path}`);
    candidates.push(`cloud://${env}/${info.path}`);
  });

  candidates.push(`cloud://${info.bucket}.${info.bucket}/${info.path}`);
  candidates.push(`cloud://${info.bucket}/${info.path}`);

  return uniq(candidates);
}

async function normalizeMediaRefMap(valueList = []) {
  const uniqueValues = uniq((valueList || []).map(trimValue).filter(Boolean));
  const resultMap = {};
  const candidateMap = {};
  const probeList = [];

  uniqueValues.forEach(raw => {
    if (isCloudFileId(raw) || isLocalFilePath(raw)) {
      resultMap[raw] = raw;
      return;
    }

    const cachedFileID = getCachedLegacyFileId(raw);
    if (cachedFileID) {
      resultMap[raw] = cachedFileID;
      return;
    }

    const candidates = buildLegacyFileIdCandidates(raw);
    if (!candidates.length) {
      resultMap[raw] = raw;
      return;
    }

    candidateMap[raw] = candidates;
    probeList.push(...candidates);
  });

  const uniqueProbeList = uniq(probeList);
  if (uniqueProbeList.length) {
    try {
      const chunkedList = chunkList(uniqueProbeList);
      const successSet = new Set();

      for (let i = 0; i < chunkedList.length; i += 1) {
        const res = await wx.cloud.getTempFileURL({
          fileList: chunkedList[i]
        });
        const fileList = (res && res.fileList) || [];
        fileList
          .filter(item => item && item.tempFileURL)
          .forEach(item => {
            successSet.add(trimValue(item.fileID));
          });
      }

      Object.keys(candidateMap).forEach(raw => {
        const matched = candidateMap[raw].find(candidate => successSet.has(candidate)) || raw;
        resultMap[raw] = matched;
        if (matched !== raw && isCloudFileId(matched)) {
          saveLegacyFileId(raw, matched);
        }
      });
    } catch (err) {
      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = raw;
      });
    }
  }

  return resultMap;
}

function buildTempUrlExpireAt(item = {}) {
  const maxAge = Number(item.maxAge || item.max_age || 0);
  if (maxAge > 0) {
    return getNow() + Math.max(60, maxAge - 60) * 1000;
  }

  return getNow() + DEFAULT_TEMP_URL_TTL;
}

async function getTempUrlMap(fileIdList = []) {
  const uniqueFileIdList = uniq((fileIdList || []).map(trimValue).filter(isCloudFileId));
  const resultMap = {};
  const pendingList = [];

  uniqueFileIdList.forEach(fileID => {
    const cached = getCachedTempUrl(fileID);
    if (cached) {
      resultMap[fileID] = cached;
      return;
    }

    pendingList.push(fileID);
  });

  const chunkedList = chunkList(pendingList);

  for (let i = 0; i < chunkedList.length; i += 1) {
    try {
      const res = await wx.cloud.getTempFileURL({
        fileList: chunkedList[i]
      });
      const fileList = (res && res.fileList) || [];

      fileList.forEach(item => {
        const fileID = trimValue(item && item.fileID);
        const tempFileURL = trimValue(item && item.tempFileURL);
        if (!fileID || !tempFileURL) return;

        resultMap[fileID] = tempFileURL;
        saveTempUrl(fileID, tempFileURL, buildTempUrlExpireAt(item));
      });
    } catch (err) {
      console.error('获取云文件临时链接失败', err);
    }
  }

  return resultMap;
}

function getCachedLocalFile(fileID) {
  return trimValue(sessionLocalFileMap[trimValue(fileID)]);
}

function saveLocalFile(fileID, tempFilePath) {
  const key = trimValue(fileID);
  const nextPath = trimValue(tempFilePath);
  if (!key || !nextPath) return nextPath;
  sessionLocalFileMap[key] = nextPath;
  return nextPath;
}

function runAsyncTasksWithLimit(taskList = [], limit = MAX_DOWNLOAD_CONCURRENCY) {
  const source = Array.isArray(taskList) ? taskList : [];
  const taskLimit = Math.max(1, Number(limit) || MAX_DOWNLOAD_CONCURRENCY);
  let currentIndex = 0;

  function createWorker() {
    return new Promise(resolve => {
      async function next() {
        if (currentIndex >= source.length) {
          resolve();
          return;
        }

        const taskIndex = currentIndex;
        currentIndex += 1;

        try {
          await source[taskIndex]();
        } catch (err) {
          console.error('执行云文件任务失败', err);
        }

        next();
      }

      next();
    });
  }

  const workerCount = Math.min(taskLimit, source.length);
  const workerList = [];
  for (let i = 0; i < workerCount; i += 1) {
    workerList.push(createWorker());
  }

  return Promise.all(workerList);
}

async function downloadCloudFileToLocal(fileID) {
  const normalizedFileID = trimValue(fileID);
  if (!normalizedFileID) return '';

  const cachedPath = getCachedLocalFile(normalizedFileID);
  if (cachedPath) {
    return cachedPath;
  }

  try {
    const res = await wx.cloud.downloadFile({
      fileID: normalizedFileID
    });
    const tempFilePath = trimValue(res && res.tempFilePath);
    if (tempFilePath) {
      return saveLocalFile(normalizedFileID, tempFilePath);
    }
  } catch (err) {
    console.error('下载云图片到本地失败', normalizedFileID, err);
  }

  return '';
}

async function getDisplayPathMap(fileIdList = []) {
  const uniqueFileIdList = uniq((fileIdList || []).map(trimValue).filter(isCloudFileId));
  const resultMap = {};
  const pendingList = [];

  uniqueFileIdList.forEach(fileID => {
    const cachedPath = getCachedLocalFile(fileID);
    if (cachedPath) {
      resultMap[fileID] = cachedPath;
      return;
    }

    pendingList.push(fileID);
  });

  const taskList = pendingList.map(fileID => async () => {
    const localPath = await downloadCloudFileToLocal(fileID);
    if (localPath) {
      resultMap[fileID] = localPath;
    }
  });

  await runAsyncTasksWithLimit(taskList, MAX_DOWNLOAD_CONCURRENCY);

  const fallbackTempUrlMap = await getTempUrlMap(
    pendingList.filter(fileID => !resultMap[fileID])
  );

  Object.keys(fallbackTempUrlMap).forEach(fileID => {
    resultMap[fileID] = fallbackTempUrlMap[fileID];
  });

  return resultMap;
}

async function buildResolvedMediaMap(valueList = [], options = {}) {
  const uniqueValues = uniq((valueList || []).map(trimValue).filter(Boolean));
  if (runtime.isDemo()) {
    const demoMap = {};
    uniqueValues.forEach(raw => {
      const display = isCloudFileId(raw) ? '' : raw;
      demoMap[raw] = { raw, normalized: display, display };
    });
    return demoMap;
  }
  const normalizedMap = await normalizeMediaRefMap(uniqueValues);
  const normalizedFileIDs = uniq(
    uniqueValues
      .map(raw => trimValue(normalizedMap[raw] || raw))
      .filter(isCloudFileId)
  );
  const displayPathMap = options.preferTempUrl
    ? await getTempUrlMap(normalizedFileIDs)
    : await getDisplayPathMap(normalizedFileIDs);
  const resultMap = {};

  uniqueValues.forEach(raw => {
    const normalized = trimValue(normalizedMap[raw] || raw);
    resultMap[raw] = {
      raw,
      normalized,
      display: displayPathMap[normalized] || normalized || raw
    };
  });

  return resultMap;
}

async function resolveImageUrl(value, options = {}) {
  const raw = trimValue(value);
  if (!raw) return '';
  if (runtime.isDemo() && isCloudFileId(raw)) return '';

  const resolvedMap = await buildResolvedMediaMap([raw], options);
  const resolved = resolvedMap[raw] || {};
  return resolved.display || resolved.normalized || raw;
}

async function attachDisplayUrls(target = {}, fields = [], options = {}) {
  const source = target || {};
  const next = {
    ...source
  };
  const rawValues = [];

  (fields || []).forEach(field => {
    rawValues.push(trimValue(source[field]));
  });

  const resolvedMap = await buildResolvedMediaMap(rawValues, options);

  (fields || []).forEach(field => {
    const raw = trimValue(source[field]);
    const resolved = resolvedMap[raw] || { normalized: raw, display: raw };
    const displayField = getDisplayFieldName(field);
    next[field] = resolved.normalized || raw;
    next[displayField] = resolved.display || resolved.normalized || raw;
  });

  return next;
}

async function attachDisplayUrlsForList(list = [], fields = [], options = {}) {
  const sourceList = Array.isArray(list) ? list : [];
  const rawValues = [];

  sourceList.forEach(item => {
    (fields || []).forEach(field => {
      rawValues.push(trimValue(item && item[field]));
    });
  });

  const resolvedMap = await buildResolvedMediaMap(rawValues, options);

  return sourceList.map(item => {
    const next = {
      ...(item || {})
    };

    (fields || []).forEach(field => {
      const raw = trimValue(item && item[field]);
      const resolved = resolvedMap[raw] || { normalized: raw, display: raw };
      const displayField = getDisplayFieldName(field);
      next[field] = resolved.normalized || raw;
      next[displayField] = resolved.display || resolved.normalized || raw;
    });

    return next;
  });
}

module.exports = {
  isCloudFileId,
  resolveImageUrl,
  attachDisplayUrls,
  attachDisplayUrlsForList,
  getDisplayFieldName
};
