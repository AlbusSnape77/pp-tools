const dataRuntime = require('./data-runtime');

function callCloud(name, data = {}) {
  return dataRuntime.callFunction(name, data);
}

function getCurrentUserId() {
  const authInfo = wx.getStorageSync('authInfo') || {};

  if (authInfo.role !== 'user' || !authInfo.userId) {
    throw new Error('请先登录用户账号');
  }

  return authInfo.userId;
}

function saveFeedbackToLocal(list = []) {
  wx.setStorageSync('feedbackList', Array.isArray(list) ? list : []);
  return list;
}

module.exports = {
  listMyFeedback() {
    return callCloud('feedbackList', {
      scope: 'mine',
      userId: getCurrentUserId()
    });
  },

  listAllFeedback() {
    return callCloud('feedbackList', { scope: 'all' });
  },

  async syncMyFeedbackToLocal() {
    const res = await this.listMyFeedback();
    saveFeedbackToLocal(res.list || []);
    return res.list || [];
  },

  async syncAllFeedbackToLocal() {
    const res = await this.listAllFeedback();
    saveFeedbackToLocal(res.list || []);
    return res.list || [];
  },

  createFeedback(feedback) {
    return callCloud('feedbackCreate', {
      userId: getCurrentUserId(),
      feedback
    });
  },

  markFeedbackProcessed(feedbackId) {
    return callCloud('feedbackUpdateStatus', {
      action: 'markProcessed',
      feedbackId
    });
  }
};
