const runtime = require('../config/runtime');
const demo = require('./demo/index');

async function callFunction(name, data = {}) {
  let result;
  if (runtime.isDemo()) {
    result = await demo.invoke(name, data);
  } else {
    runtime.validate();
    const response = await wx.cloud.callFunction({ name, data });
    result = response.result || {};
  }
  if (result && result.success === false) throw new Error(result.message || '操作失败');
  return result || {};
}

module.exports = { callFunction };
