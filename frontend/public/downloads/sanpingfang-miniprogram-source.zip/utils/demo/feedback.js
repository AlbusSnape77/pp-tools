const store = require('./store');

async function list({ scope, userId } = {}) {
  const database = store.read();
  const items = scope === 'mine' ? database.feedback.filter(item => item.userId === userId) : database.feedback;
  return { success: true, list: items };
}

async function create({ userId, feedback } = {}) {
  const database = store.read();
  const user = database.users.find(item => item.id === userId && item.enabled !== false);
  if (!user) throw new Error('用户身份失效，请重新登录');
  const content = String(feedback && feedback.content || '').trim();
  if (!content) throw new Error('反馈内容不能为空');
  const timestamp = Date.now();
  const item = {
    ...(feedback || {}),
    id: ++database.counters.feedback,
    userId,
    accountUsername: user.username,
    accountNickname: user.nickname,
    content,
    type: String(feedback && feedback.type || '其他'),
    status: '待处理',
    createTime: new Date(timestamp).toLocaleString('zh-CN'),
    createTimestamp: timestamp,
    updateTime: timestamp
  };
  database.feedback.unshift(item);
  store.write(database);
  return { success: true, feedback: item };
}

async function updateStatus({ action, feedbackId } = {}) {
  if (action !== 'markProcessed') throw new Error('不支持的反馈操作');
  const database = store.read();
  const item = database.feedback.find(candidate => candidate.id === Number(feedbackId));
  if (!item) throw new Error('反馈不存在');
  item.status = '已处理';
  item.updateTime = Date.now();
  store.write(database);
  return { success: true };
}

module.exports = { list, create, updateStatus };
