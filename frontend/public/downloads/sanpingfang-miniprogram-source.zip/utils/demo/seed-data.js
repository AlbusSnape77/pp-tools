const DEFAULT_PRODUCTS = [
  { id: 1, name: '珍珠奶茶', desc: '经典奶香口味，搭配珍珠更有嚼劲', price: 16, category: '招牌奶茶', tag: '经典热卖', iconType: 'emoji', icon: '🧋' },
  { id: 2, name: '芋泥波波奶茶', desc: '芋泥绵密细腻，奶香浓郁', price: 18, category: '招牌奶茶', tag: '人气推荐', iconType: 'emoji', icon: '🥤' },
  { id: 3, name: '黑糖珍珠鲜奶', desc: '黑糖香浓，珍珠Q弹，奶香顺滑', price: 19, category: '招牌奶茶', tag: '黑糖系列', iconType: 'emoji', icon: '🟤' },
  { id: 4, name: '奥利奥奶茶', desc: '浓郁奶茶搭配奥利奥碎', price: 18, category: '招牌奶茶', tag: '甜口推荐', iconType: 'emoji', icon: '🍪' },
  { id: 5, name: '布丁奶茶', desc: '滑嫩布丁搭配奶茶，柔和香甜', price: 17, category: '招牌奶茶', tag: '顺滑口感', iconType: 'emoji', icon: '🍮' },
  { id: 6, name: '红豆奶茶', desc: '红豆软糯香甜，口感饱满', price: 17, category: '招牌奶茶', tag: '饱满口感', iconType: 'emoji', icon: '🫘' },
  { id: 7, name: '四季奶青', desc: '茶香清爽，奶味柔和', price: 16, category: '招牌奶茶', tag: '清爽茶底', iconType: 'emoji', icon: '🍵' },
  { id: 8, name: '茉莉奶绿', desc: '茉莉花香清新，入口轻盈', price: 16, category: '招牌奶茶', tag: '花香茶底', iconType: 'emoji', icon: '🌿' },
  { id: 9, name: '西瓜椰椰', desc: '西瓜清甜搭配椰香，清爽解暑', price: 20, category: '果茶', tag: '本店招牌', iconType: 'emoji', icon: '🍉' },
  { id: 10, name: '满杯橙橙', desc: '鲜橙果肉搭配清香茶底', price: 19, category: '果茶', tag: '鲜果系列', iconType: 'emoji', icon: '🍊' },
  { id: 11, name: '葡萄冰茶', desc: '葡萄果香清甜，冰爽轻盈', price: 20, category: '果茶', tag: '清爽推荐', iconType: 'emoji', icon: '🍇' },
  { id: 12, name: '百香双响炮', desc: '百香果与双料小料层次丰富', price: 21, category: '果茶', tag: '丰富口感', iconType: 'emoji', icon: '🥭' },
  { id: 13, name: '生椰拿铁', desc: '咖啡醇香搭配清甜椰乳', price: 22, category: '咖啡', tag: '人气咖啡', iconType: 'emoji', icon: '☕' },
  { id: 14, name: '焦糖拿铁', desc: '焦糖甜香与浓缩咖啡融合', price: 22, category: '咖啡', tag: '醇香推荐', iconType: 'emoji', icon: '🤎' },
  { id: 15, name: '抹茶咖啡', desc: '抹茶清香与咖啡碰撞', price: 23, category: '咖啡', tag: '创意特调', iconType: 'emoji', icon: '🍵' }
].map((item, index) => ({
  ...item,
  stock: 30,
  enabled: true,
  sortOrder: index + 1,
  sizes: ['中杯', '大杯'],
  sweets: ['无糖', '三分糖', '五分糖', '七分糖', '全糖'],
  ices: ['去冰', '少冰', '正常冰'],
  toppings: ['珍珠', '椰果', '布丁']
}));

function createSeedData() {
  return {
    version: 1,
    users: [{ id: 'demo-user-1', username: 'user', password: '123456', nickname: '演示用户', avatarUrl: '', role: 'user', enabled: true }],
    admins: [{ id: 'demo-admin-1', username: 'admin', password: 'admin123', nickname: '演示管理员', avatarUrl: '', role: 'admin', enabled: true }],
    products: JSON.parse(JSON.stringify(DEFAULT_PRODUCTS)),
    orders: [],
    feedback: [],
    userData: { 'demo-user-1': { cartList: [], favoriteList: [], recentViewedList: [] } },
    productStatus: {},
    shop: { storeId: 'default', status: 'open', storeLogo: '', storeCover: '', updatedAt: 0, updatedBy: 'demo' },
    counters: { product: 100, order: 1000, feedback: 100 }
  };
}

module.exports = { DEFAULT_PRODUCTS, createSeedData };
