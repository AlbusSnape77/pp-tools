const store = require('./store');

function normalize(data = {}) {
  return {
    cartList: Array.isArray(data.cartList) ? data.cartList : [],
    favoriteList: Array.isArray(data.favoriteList) ? data.favoriteList : [],
    recentViewedList: Array.isArray(data.recentViewedList) ? data.recentViewedList : []
  };
}

function ensureUser(database, userId) {
  if (!database.users.some(item => item.id === userId && item.enabled !== false)) throw new Error('用户账号不存在或已停用');
}

async function getUserData({ userId } = {}) {
  const database = store.read();
  ensureUser(database, userId);
  return normalize(database.userData[userId]);
}

async function updateUserData({ userId, data } = {}) {
  const database = store.read();
  ensureUser(database, userId);
  const current = normalize(database.userData[userId]);
  database.userData[userId] = normalize({ ...current, ...(data || {}) });
  store.write(database);
  return normalize(database.userData[userId]);
}

module.exports = { getUserData, updateUserData, normalize };
