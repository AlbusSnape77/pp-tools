const { createSeedData } = require('./seed-data');

const DATABASE_KEY = 'spfDemoDatabaseV1';

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function read() {
  const saved = wx.getStorageSync(DATABASE_KEY);
  if (saved && saved.version === 1) return clone(saved);
  return reset();
}

function write(data) {
  const next = clone(data);
  wx.setStorageSync(DATABASE_KEY, next);
  return clone(next);
}

function update(mutator) {
  const current = read();
  const result = mutator(current) || current;
  return write(result);
}

function reset() {
  return write(createSeedData());
}

module.exports = { DATABASE_KEY, read, write, update, reset };
