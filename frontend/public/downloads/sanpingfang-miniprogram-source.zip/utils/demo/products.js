const store = require('./store');

function productId(value) {
  return Number(value || 0);
}

function validateProduct(product = {}) {
  if (!String(product.name || '').trim()) throw new Error('商品名称不能为空');
  if (!String(product.category || '').trim()) throw new Error('商品分类不能为空');
  if (!String(product.desc || '').trim()) throw new Error('商品描述不能为空');
  if (!(Number(product.price) > 0)) throw new Error('商品价格必须大于 0');
  if (Number(product.stock) < 0) throw new Error('商品库存不能小于 0');
}

async function listProducts() {
  const list = store.read().products.filter(item => item.enabled !== false).sort((a, b) => a.sortOrder - b.sortOrder);
  return { success: true, list };
}

async function getProduct({ id } = {}) {
  const product = store.read().products.find(item => item.id === productId(id) && item.enabled !== false);
  if (!product) throw new Error('商品不存在');
  return { success: true, product };
}

async function upsertProduct({ product } = {}) {
  const input = { ...(product || {}) };
  validateProduct(input);
  const database = store.read();
  const id = productId(input.id) || ++database.counters.product;
  const index = database.products.findIndex(item => item.id === id);
  const current = index >= 0 ? database.products[index] : {};
  const next = {
    ...current,
    ...input,
    id,
    name: String(input.name).trim(),
    category: String(input.category).trim(),
    desc: String(input.desc).trim(),
    price: Number(input.price),
    stock: Math.floor(Number(input.stock)),
    enabled: input.enabled !== false,
    sortOrder: Number(input.sortOrder || current.sortOrder || database.products.length + 1),
    iconType: input.iconType || current.iconType || 'emoji',
    icon: input.icon || current.icon || '🧋'
  };
  if (index >= 0) database.products[index] = next;
  else database.products.push(next);
  store.write(database);
  return { success: true, product: next };
}

async function deleteProduct({ id } = {}) {
  const database = store.read();
  const targetId = productId(id);
  const before = database.products.length;
  database.products = database.products.filter(item => item.id !== targetId);
  delete database.productStatus[targetId];
  if (database.products.length === before) throw new Error('商品不存在');
  store.write(database);
  return { success: true };
}

async function listStatus() {
  return { success: true, list: Object.values(store.read().productStatus) };
}

async function updateStatus({ productId: rawId, status } = {}) {
  if (!['on', 'paused', 'soldout'].includes(status)) throw new Error('商品状态不合法');
  const database = store.read();
  const id = productId(rawId);
  if (!database.products.some(item => item.id === id)) throw new Error('商品不存在');
  const item = { productId: id, status, updatedAt: Date.now(), updatedBy: 'demo-admin-1' };
  database.productStatus[id] = item;
  store.write(database);
  return { success: true, item };
}

module.exports = { listProducts, getProduct, upsertProduct, deleteProduct, listStatus, updateStatus };
