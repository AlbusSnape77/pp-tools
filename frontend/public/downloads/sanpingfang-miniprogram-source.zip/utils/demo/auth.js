const store = require('./store');

function authInfo(record) {
  const base = {
    username: record.username,
    nickname: record.nickname || record.username,
    avatarUrl: record.avatarUrl || '',
    role: record.role,
    loginTime: Date.now()
  };
  if (record.role === 'admin') return { ...base, openid: 'demo-openid', adminId: record.id };
  return { ...base, userId: record.id };
}

function findAccount(list, username) {
  const key = String(username || '').trim();
  return list.find(item => item.username === key && item.enabled !== false);
}

async function userLogin(data = {}) {
  const user = findAccount(store.read().users, data.username);
  if (!user || user.password !== String(data.password || '')) throw new Error('用户账号或密码错误');
  return { success: true, authInfo: authInfo(user) };
}

async function adminEntry(data = {}) {
  const admin = findAccount(store.read().admins, data.username);
  if (!admin || admin.password !== String(data.password || '')) throw new Error('管理员账号或密码错误');
  return { success: true, authInfo: authInfo(admin) };
}

async function userRegister(data = {}) {
  const username = String(data.username || '').trim();
  const password = String(data.password || '');
  const nickname = String(data.nickname || '').trim();
  if (!nickname) throw new Error('请输入昵称');
  if (username.length < 3) throw new Error('用户账号至少 3 位');
  if (password.length < 6) throw new Error('用户密码至少 6 位');
  const database = store.read();
  if (database.users.some(item => item.username === username)) throw new Error('该用户账号已存在');
  const user = { id: `demo-user-${Date.now()}`, username, password, nickname, avatarUrl: '', role: 'user', enabled: true };
  database.users.push(user);
  database.userData[user.id] = { cartList: [], favoriteList: [], recentViewedList: [] };
  store.write(database);
  return { success: true, authInfo: authInfo(user) };
}

async function handle(data = {}) {
  if (data.action === 'userRegister') return userRegister(data);
  if (data.action === 'userLogin') return userLogin(data);
  if (data.action === 'adminEntry') return adminEntry(data);
  throw new Error('不支持的登录操作');
}

module.exports = { userRegister, userLogin, adminEntry, handle, authInfo };
