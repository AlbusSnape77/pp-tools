const auth = require('./auth');
const products = require('./products');
const orders = require('./orders');
const users = require('./users');
const shop = require('./shop');
const feedback = require('./feedback');
const account = require('./account');

const handlers = {
  userAuth: data => auth.handle(data),
  productList: () => products.listProducts(),
  productGet: data => products.getProduct(data),
  productUpsert: data => products.upsertProduct(data),
  productDelete: data => products.deleteProduct(data),
  orderList: data => orders.listOrders(data),
  orderCreate: data => orders.createOrder(data),
  orderUpdateStatus: data => orders.updateStatus(data),
  userDataGet: data => users.getUserData(data).then(result => ({ success: true, data: result })),
  userDataUpdate: data => users.updateUserData(data).then(result => ({ success: true, data: result })),
  shopConfigGet: () => shop.getConfig(),
  shopConfigUpdate: data => shop.updateConfig(data),
  productStatusList: () => products.listStatus(),
  productStatusUpdate: data => products.updateStatus(data),
  feedbackList: data => feedback.list(data),
  feedbackCreate: data => feedback.create(data),
  feedbackUpdateStatus: data => feedback.updateStatus(data),
  accountUpdate: data => account.update(data),
  openid: () => Promise.resolve({ success: true, openid: 'demo-openid' })
};

async function invoke(name, data = {}) {
  const handler = handlers[name];
  if (!handler) throw new Error(`不支持的演示操作：${name}`);
  return handler(data);
}

module.exports = { invoke };
