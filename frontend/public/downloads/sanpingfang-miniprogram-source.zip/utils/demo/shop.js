const store = require('./store');

async function getConfig() {
  return { success: true, config: store.read().shop };
}

async function updateConfig({ config } = {}) {
  const database = store.read();
  const input = config || {};
  const status = input.status || database.shop.status;
  if (!['open', 'pause', 'closed'].includes(status)) throw new Error('门店状态不合法');
  database.shop = { ...database.shop, ...input, status, updatedAt: Date.now(), updatedBy: 'demo-admin-1' };
  store.write(database);
  return { success: true, config: database.shop };
}

module.exports = { getConfig, updateConfig };
