const store = require('./store');
const { authInfo } = require('./auth');

async function update(payload = {}) {
  const database = store.read();
  const savedAuth = wx.getStorageSync('authInfo') || {};
  const role = payload.role || savedAuth.role;
  const id = role === 'admin' ? (payload.adminId || savedAuth.adminId) : (payload.userId || savedAuth.userId);
  const list = role === 'admin' ? database.admins : database.users;
  const record = list.find(item => item.id === id && item.enabled !== false);
  if (!record) throw new Error('账号不存在或已停用');
  const nextUsername = String(payload.newUsername || '').trim();
  const nextPassword = String(payload.newPassword || '');
  const needsPassword = (nextUsername && nextUsername !== record.username) || nextPassword;
  if (needsPassword && record.password !== String(payload.currentPassword || '')) throw new Error('当前密码错误');
  if (nextUsername) {
    if (nextUsername.length < 3) throw new Error('新账号名至少 3 位');
    if (list.some(item => item.id !== id && item.username === nextUsername)) throw new Error('该账号名已存在');
    record.username = nextUsername;
  }
  if (nextPassword) {
    if (nextPassword.length < 6) throw new Error('新密码至少 6 位');
    record.password = nextPassword;
  }
  if (Object.hasOwn(payload, 'nickname')) record.nickname = String(payload.nickname || '').trim() || record.username;
  if (Object.hasOwn(payload, 'avatarUrl')) record.avatarUrl = String(payload.avatarUrl || '');
  store.write(database);
  const nextAuth = authInfo(record);
  wx.setStorageSync('authInfo', nextAuth);
  return { success: true, authInfo: nextAuth };
}

module.exports = { update };
