const store = require('./store');

function formatTime(value) {
  const date = new Date(value);
  const pad = number => String(number).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function normalizeItems(items) {
  return (Array.isArray(items) ? items : []).map(item => ({
    ...item,
    id: Number(item.id || 0),
    quantity: Math.max(0, Number(item.quantity || 0)),
    price: Number(item.price || 0),
    toppings: Array.isArray(item.toppings) ? item.toppings : []
  })).filter(item => item.id && item.quantity > 0);
}

function assertUser(database, userId) {
  if (!database.users.some(item => item.id === userId && item.enabled !== false)) throw new Error('用户身份失效，请重新登录');
}

async function createOrder({ userId, order } = {}) {
  const database = store.read();
  assertUser(database, userId);
  if (database.shop.status === 'pause') throw new Error('门店暂停接单');
  if (database.shop.status === 'closed') throw new Error('门店已打烊');
  const items = normalizeItems(order && order.items);
  if (!items.length) throw new Error('订单商品不能为空');
  const stockSnapshot = [];
  items.forEach(item => {
    const product = database.products.find(candidate => candidate.id === item.id && candidate.enabled !== false);
    if (!product) throw new Error('部分商品不存在或已下架');
    const status = database.productStatus[item.id] && database.productStatus[item.id].status;
    if (status === 'paused') throw new Error(`${product.name}暂停售卖`);
    if (status === 'soldout' || product.stock < item.quantity) throw new Error(`${product.name}库存不足`);
    stockSnapshot.push({ productId: product.id, beforeStock: product.stock, deductQuantity: item.quantity, afterStock: product.stock - item.quantity });
  });
  stockSnapshot.forEach(snapshot => {
    const product = database.products.find(item => item.id === snapshot.productId);
    product.stock = snapshot.afterStock;
  });
  const timestamp = Date.now();
  const id = ++database.counters.order;
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const next = {
    ...(order || {}),
    id,
    userId,
    orderNo: String((order && order.orderNo) || `SPF${id}`),
    pickupCode: String((order && order.pickupCode) || id).slice(-4).padStart(4, '0'),
    createTime: (order && order.createTime) || formatTime(timestamp),
    createTimestamp: timestamp,
    updateTime: timestamp,
    status: (order && order.status) || '待处理',
    verifyStatus: '未核销',
    totalPrice: Number((order && order.totalPrice) || total),
    payablePrice: Number((order && order.payablePrice) || (order && order.totalPrice) || total),
    items,
    stockSnapshot,
    stockRestored: false
  };
  database.orders.unshift(next);
  store.write(database);
  return { success: true, order: next };
}

async function listOrders({ scope, userId } = {}) {
  const database = store.read();
  const list = scope === 'mine' ? database.orders.filter(item => item.userId === userId) : database.orders;
  return { success: true, list };
}

async function updateStatus(data = {}) {
  const database = store.read();
  const order = database.orders.find(item => item.id === Number(data.orderId));
  if (!order) throw new Error('订单不存在');
  if (data.action === 'cancelMine') {
    if (order.userId !== data.userId) throw new Error('不能取消其他用户的订单');
    if (order.status === '已取消' || order.stockRestored) throw new Error('订单不能重复取消');
    if (order.status === '已完成') throw new Error('已完成订单不能取消');
    order.stockSnapshot.forEach(snapshot => {
      const product = database.products.find(item => item.id === snapshot.productId);
      if (product) product.stock += snapshot.deductQuantity;
    });
    order.stockRestored = true;
    order.status = '已取消';
  } else if (data.action === 'adminVerifyByCode') {
    const target = database.orders.find(item => item.pickupCode === String(data.pickupCode || '').trim());
    if (!target) throw new Error('取餐码不存在');
    target.status = '已完成';
    target.verifyStatus = '已核销';
    target.updateTime = Date.now();
    store.write(database);
    return { success: true, order: target };
  } else if (data.action === 'adminUpdateById') {
    order.status = String(data.status || '').trim();
    if (order.status === '已完成') order.verifyStatus = '已核销';
  } else {
    throw new Error('不支持的订单操作');
  }
  order.updateTime = Date.now();
  store.write(database);
  return { success: true, order };
}

module.exports = { createOrder, listOrders, updateStatus };
