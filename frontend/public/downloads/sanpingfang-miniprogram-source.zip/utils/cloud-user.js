const dataRuntime = require('./data-runtime');

function callCloud(name, data = {}) {
  return dataRuntime.callFunction(name, data);
}

function getCurrentUserId() {
  const authInfo = wx.getStorageSync('authInfo') || {};

  if (authInfo.role !== 'user' || !authInfo.userId) {
    throw new Error('请先登录用户账号');
  }

  return authInfo.userId;
}

function saveUserDataToLocal(data = {}) {
  const app = getApp && getApp();

  if (app && app.globalData) {
    app.globalData.userDataSyncLock = true;
  }

  try {
    wx.setStorageSync('cartList', Array.isArray(data.cartList) ? data.cartList : []);
    wx.setStorageSync('favoriteList', Array.isArray(data.favoriteList) ? data.favoriteList : []);
    wx.setStorageSync('recentViewedList', Array.isArray(data.recentViewedList) ? data.recentViewedList : []);
  } finally {
    if (app && app.globalData) {
      app.globalData.userDataSyncLock = false;
    }
  }

  return data;
}

module.exports = {
  getUserData() {
    return callCloud('userDataGet', {
      userId: getCurrentUserId()
    }).then(res => {
      const data = res.data || {};
      saveUserDataToLocal(data);
      return data;
    });
  },

  updateUserData(data) {
    return callCloud('userDataUpdate', {
      userId: getCurrentUserId(),
      data
    }).then(res => {
      const nextData = res.data || {};
      saveUserDataToLocal(nextData);
      return nextData;
    });
  },

  syncAllToLocal() {
    return this.getUserData();
  },

  saveCartList(cartList) {
    return this.updateUserData({
      cartList: Array.isArray(cartList) ? cartList : []
    });
  },

  saveFavoriteList(favoriteList) {
    return this.updateUserData({
      favoriteList: Array.isArray(favoriteList) ? favoriteList : []
    });
  },

  saveRecentViewedList(recentViewedList) {
    return this.updateUserData({
      recentViewedList: Array.isArray(recentViewedList) ? recentViewedList : []
    });
  },

  clearRecentViewedList() {
    return this.updateUserData({
      recentViewedList: []
    });
  }
};
