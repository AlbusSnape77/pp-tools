const dataRuntime = require('./data-runtime');

function callCloud(name, data = {}) {
  return dataRuntime.callFunction(name, data);
}

function buildProductStatusMap(list = []) {
  const map = {};
  (Array.isArray(list) ? list : []).forEach(item => {
    map[item.productId] = {
      status: item.status || 'on',
      updatedAt: Number(item.updatedAt || 0),
      updatedBy: item.updatedBy || ''
    };
  });
  return map;
}

function saveStoreConfigToLocal(config = {}) {
  const nextConfig = {
    storeId: config.storeId || 'default',
    status: config.status || 'open',
    storeLogo: config.storeLogo || '',
    storeCover: config.storeCover || '',
    updatedAt: Number(config.updatedAt || 0),
    updatedBy: config.updatedBy || ''
  };

  wx.setStorageSync('storeStatusConfig', nextConfig);
  return nextConfig;
}

function saveProductStatusListToLocal(list = []) {
  const map = buildProductStatusMap(list);
  wx.setStorageSync('productStatusMap', map);
  return map;
}

module.exports = {
  async getStoreConfig() {
    const res = await callCloud('shopConfigGet');
    const config = saveStoreConfigToLocal(res.config || { status: 'open' });
    return {
      ...res,
      config
    };
  },

  async updateStoreConfig(config) {
    const res = await callCloud('shopConfigUpdate', { config });
    const nextConfig = saveStoreConfigToLocal(res.config || config || { status: 'open' });
    return {
      ...res,
      config: nextConfig
    };
  },

  async listProductStatus() {
    const res = await callCloud('productStatusList');
    saveProductStatusListToLocal(res.list || []);
    return res;
  },

  async updateProductStatus(productId, status) {
    const res = await callCloud('productStatusUpdate', {
      productId,
      status
    });

    await this.listProductStatus();
    return res;
  },

  async syncShopStateToLocal() {
    const [storeRes, productRes] = await Promise.all([
      this.getStoreConfig(),
      this.listProductStatus()
    ]);

    return {
      storeConfig: storeRes.config || { status: 'open' },
      productStatusMap: wx.getStorageSync('productStatusMap') || {}
    };
  }
};
