const dataRuntime = require('./data-runtime');

function callCloud(name, data = {}) {
  return dataRuntime.callFunction(name, data);
}

module.exports = {
  userRegister(username, password, nickname) {
    return callCloud('userAuth', {
      action: 'userRegister',
      username: String(username || '').trim(),
      password: String(password || ''),
      nickname: String(nickname || '').trim()
    });
  },

  userLogin(username, password) {
    return callCloud('userAuth', {
      action: 'userLogin',
      username: String(username || '').trim(),
      password: String(password || '')
    });
  },

  adminEntry(username, password) {
    return callCloud('userAuth', {
      action: 'adminEntry',
      username: String(username || '').trim(),
      password: String(password || '')
    });
  }
};
