const STORAGE_KEYS = {
  AUTH_INFO: 'authInfo',
  CART_LIST: 'cartList',
  FAVORITE_LIST: 'favoriteList',
  RECENT_VIEWED_LIST: 'recentViewedList',
  FEEDBACK_LIST: 'feedbackList',
  PRODUCT_LIST: 'productListLatest',
  PRODUCT_MAP: 'productMapLatest',
  PRODUCT_STATUS_MAP: 'productStatusMap',
  STORE_CONFIG: 'storeStatusConfig',
  CHECKOUT_CART_LIST: 'checkoutCartList',
  CHECKOUT_CART_IDS: 'checkoutCartIds',
  CHECKOUT_ORDER_REMARK: 'checkoutOrderRemark',
  CHECKOUT_PICKUP_MODE: 'checkoutPickupMode',
  CHECKOUT_RESERVE_DATE: 'checkoutReserveDate',
  CHECKOUT_RESERVE_DATE_LABEL: 'checkoutReserveDateLabel',
  CHECKOUT_RESERVE_TIME: 'checkoutReserveTime',
  CHECKOUT_COUPON_ID: 'checkoutCouponId'
};

function get(key, defaultValue = null) {
  try {
    const value = wx.getStorageSync(key);
    if (value === '' || value === undefined || value === null) {
      return defaultValue;
    }
    return value;
  } catch (e) {
    return defaultValue;
  }
}

function set(key, value) {
  try {
    wx.setStorageSync(key, value);
    return true;
  } catch (e) {
    console.error('Storage set failed:', key, e);
    return false;
  }
}

function remove(key) {
  try {
    wx.removeStorageSync(key);
    return true;
  } catch (e) {
    return false;
  }
}

function clearUserCache() {
  const userKeys = [
    STORAGE_KEYS.CART_LIST,
    STORAGE_KEYS.FAVORITE_LIST,
    STORAGE_KEYS.RECENT_VIEWED_LIST,
    STORAGE_KEYS.FEEDBACK_LIST,
    STORAGE_KEYS.CHECKOUT_CART_LIST,
    STORAGE_KEYS.CHECKOUT_CART_IDS,
    STORAGE_KEYS.CHECKOUT_ORDER_REMARK,
    STORAGE_KEYS.CHECKOUT_PICKUP_MODE,
    STORAGE_KEYS.CHECKOUT_RESERVE_DATE,
    STORAGE_KEYS.CHECKOUT_RESERVE_DATE_LABEL,
    STORAGE_KEYS.CHECKOUT_RESERVE_TIME,
    STORAGE_KEYS.CHECKOUT_COUPON_ID
  ];
  userKeys.forEach(remove);
}

module.exports = {
  KEYS: STORAGE_KEYS,
  get,
  set,
  remove,
  clearUserCache
};
