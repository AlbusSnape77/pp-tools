const dataRuntime = require('./data-runtime');

function callCloud(name, data = {}) {
  return dataRuntime.callFunction(name, data);
}

function getCurrentUserId() {
  const authInfo = wx.getStorageSync('authInfo') || {};

  if (authInfo.role !== 'user' || !authInfo.userId) {
    throw new Error('请先登录用户账号');
  }

  return authInfo.userId;
}

function normalizeOrderList(result = {}) {
  const ordersList = Array.isArray(result.ordersList)
    ? result.ordersList
    : (Array.isArray(result.list) ? result.list : []);
  return { ...result, list: ordersList, ordersList };
}

module.exports = {
  async listMyOrders() {
    const result = await callCloud('orderList', {
      scope: 'mine',
      userId: getCurrentUserId()
    });
    return normalizeOrderList(result);
  },

  async listAllOrders() {
    const result = await callCloud('orderList', {
      scope: 'all'
    });
    return normalizeOrderList(result);
  },

  createOrder(order) {
    return callCloud('orderCreate', {
      userId: getCurrentUserId(),
      order
    });
  },

  cancelMyOrder(orderId) {
    return callCloud('orderUpdateStatus', {
      action: 'cancelMine',
      orderId,
      userId: getCurrentUserId()
    });
  },

  adminUpdateStatus(orderId, status) {
    return callCloud('orderUpdateStatus', {
      action: 'adminUpdateById',
      orderId,
      status
    });
  },

  adminVerifyByCode(pickupCode) {
    return callCloud('orderUpdateStatus', {
      action: 'adminVerifyByCode',
      pickupCode
    });
  }
};
