const storage = require('./storage');

function getAuthInfo() {
  const app = getApp();
  if (app && app.globalData && app.globalData.authInfo) {
    return app.globalData.authInfo;
  }
  return storage.get(storage.KEYS.AUTH_INFO, null);
}

function requireAuth(page) {
  const authInfo = getAuthInfo();
  if (!authInfo || !authInfo.userId) {
    wx.redirectTo({ url: '/pages/login/login' });
    return false;
  }
  return true;
}

function showLoading(title = '加载中') {
  wx.showLoading({ title, mask: true });
}

function hideLoading() {
  wx.hideLoading();
}

function showToast(title, icon = 'none', duration = 2000) {
  wx.showToast({ title, icon, duration });
}

function showError(msg) {
  showToast(msg || '操作失败', 'none');
}

function showSuccess(msg) {
  showToast(msg || '操作成功', 'success');
}

function createPage(options = {}) {
  const { onLoad: userOnLoad, onShow: userOnShow, ...rest } = options;

  return Page({
    data: {
      pageLoading: true,
      pageError: false,
      pageErrorMsg: '',
      isEmpty: false,
      ...options.data
    },

    onLoad(query) {
      if (options.needAuth && !requireAuth(this)) return;
      if (userOnLoad) userOnLoad.call(this, query);
    },

    onShow() {
      if (userOnShow) userOnShow.call(this);
    },

    setLoading(loading) {
      this.setData({ pageLoading: loading, pageError: false });
    },

    setError(msg) {
      this.setData({ pageLoading: false, pageError: true, pageErrorMsg: msg || '加载失败' });
    },

    setEmpty(isEmpty) {
      this.setData({ pageLoading: false, isEmpty });
    },

    handleError(err, fallbackMsg) {
      const msg = (err && err.message) || fallbackMsg || '操作失败';
      showError(msg);
      return msg;
    },

    ...rest
  });
}

module.exports = {
  getAuthInfo,
  requireAuth,
  showLoading,
  hideLoading,
  showToast,
  showError,
  showSuccess,
  createPage
};
