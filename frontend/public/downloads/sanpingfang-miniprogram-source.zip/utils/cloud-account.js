const dataRuntime = require('./data-runtime');

function callCloud(name, data = {}) {
  return dataRuntime.callFunction(name, data);
}

module.exports = {
  async updateAccount(payload) {
    const res = await callCloud('accountUpdate', payload);

    if (res.authInfo) {
      wx.setStorageSync('authInfo', res.authInfo);
    }

    return res;
  }
};
