const dataRuntime = require('./data-runtime');

function callCloud(name, data = {}) {
  return dataRuntime.callFunction(name, data);
}

function saveProductListToLocal(list = []) {
  const productList = Array.isArray(list) ? list : [];
  const productMap = {};

  productList.forEach(item => {
    if (!item || !item.id) return;
    productMap[item.id] = item;
  });

  wx.setStorageSync('productListLatest', productList);
  wx.setStorageSync('productMapLatest', productMap);
  return {
    productList,
    productMap
  };
}

function saveProductItemToLocal(product = {}) {
  if (!product || !product.id) return product;

  const productMap = wx.getStorageSync('productMapLatest') || {};
  productMap[product.id] = product;
  wx.setStorageSync('productMapLatest', productMap);

  const productList = wx.getStorageSync('productListLatest') || [];
  const index = productList.findIndex(item => Number(item.id) === Number(product.id));
  if (index > -1) {
    productList[index] = product;
  } else {
    productList.push(product);
  }
  wx.setStorageSync('productListLatest', productList);
  return product;
}

module.exports = {
  listProducts() {
    return callCloud('productList').then(result => {
      saveProductListToLocal(result.list || []);
      return result;
    });
  },

  getProductById(id) {
    return callCloud('productGet', { id }).then(result => {
      saveProductItemToLocal(result.product || {});
      return result;
    });
  },

  upsertProduct(product) {
    return callCloud('productUpsert', { product }).then(result => {
      saveProductItemToLocal(result.product || {});
      return result;
    });
  },

  deleteProduct(id) {
    return callCloud('productDelete', { id });
  }
};
