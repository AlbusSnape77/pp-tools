const runtime = require('./config/runtime');
const storage = require('./utils/storage');

function initializeRuntime() {
  runtime.validate();
  if (runtime.isDemo()) return;
  if (!wx.cloud) throw new Error('当前基础库不支持云开发');
  wx.cloud.init({ env: runtime.cloudEnvId, traceUser: true });
}

App({
  onLaunch() {
    initializeRuntime();

    this.globalData.authInfo = storage.get(storage.KEYS.AUTH_INFO, null);
  },

  globalData: {
    userDataSyncLock: false,
    authInfo: null
  },

  getAuthInfo() {
    if (this.globalData && this.globalData.authInfo) {
      return this.globalData.authInfo;
    }
    const authInfo = storage.get(storage.KEYS.AUTH_INFO, null);
    if (this.globalData) {
      this.globalData.authInfo = authInfo;
    }
    return authInfo;
  },

  setAuthInfo(authInfo) {
    storage.clearUserCache();
    if (this.globalData) {
      this.globalData.authInfo = authInfo || null;
    }
    storage.set(storage.KEYS.AUTH_INFO, authInfo);
  },

  clearAuthInfo() {
    if (this.globalData) {
      this.globalData.authInfo = null;
    }
    storage.remove(storage.KEYS.AUTH_INFO);
    storage.clearUserCache();
  },

  routeAfterLogin(role) {
    const url = role === 'admin' ? '/pages/admin/admin' : '/pages/home/home';
    wx.reLaunch({ url });
  }
});
