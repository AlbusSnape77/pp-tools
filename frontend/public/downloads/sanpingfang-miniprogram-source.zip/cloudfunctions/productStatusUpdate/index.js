const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;
const PRODUCT_COLLECTION = 'product_status';
const ADMINS_COLLECTION = 'admins';

function now() {
  return Date.now();
}

async function isAdmin(openid) {
  const byOpenid = await db.collection(ADMINS_COLLECTION).where({
    openid,
    enabled: _.neq(false)
  }).limit(1).get();

  if (byOpenid.data && byOpenid.data.length) {
    return true;
  }

  const byLastLoginOpenid = await db.collection(ADMINS_COLLECTION).where({
    lastLoginOpenid: openid,
    enabled: _.neq(false)
  }).limit(1).get();

  return !!(byLastLoginOpenid.data && byLastLoginOpenid.data.length);
}

async function getProductDoc(productId) {
  const res = await db.collection(PRODUCT_COLLECTION).where({
    productId
  }).limit(1).get();

  return (res.data && res.data[0]) || null;
}

exports.main = async (event) => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const productId = Number(event.productId);
    const status = String(event.status || '').trim();

    if (!openid) {
      return {
        success: false,
        message: '获取 openid 失败'
      };
    }

    const admin = await isAdmin(openid);

    if (!admin) {
      return {
        success: false,
        message: '无管理员权限'
      };
    }

    if (!productId) {
      return {
        success: false,
        message: '商品ID不能为空'
      };
    }

    if (!['on', 'soldout', 'paused'].includes(status)) {
      return {
        success: false,
        message: '商品状态不合法'
      };
    }

    const currentTime = now();
    const existed = await getProductDoc(productId);
    const data = {
      productId,
      status,
      updatedAt: currentTime,
      updatedBy: openid
    };

    if (existed) {
      await db.collection(PRODUCT_COLLECTION).doc(existed._id).update({
        data
      });
    } else {
      await db.collection(PRODUCT_COLLECTION).add({
        data
      });
    }

    return {
      success: true,
      item: data
    };
  } catch (err) {
    return {
      success: false,
      message: err && err.message ? err.message : '更新商品状态失败'
    };
  }
};