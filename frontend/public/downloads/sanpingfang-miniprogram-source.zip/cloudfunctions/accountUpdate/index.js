const cloud = require('wx-server-sdk');

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const USERS_COLLECTION = 'users';
const ADMINS_COLLECTION = 'admins';
const DEFAULT_ENV_ID = '';

function now() {
  return Date.now();
}

async function findByUsername(collectionName, username) {
  const res = await db.collection(collectionName).where({ username }).limit(1).get();
  return (res.data && res.data[0]) || null;
}

async function getDocById(collectionName, id) {
  if (!id) return null;

  try {
    const res = await db.collection(collectionName).doc(id).get();
    return res.data || null;
  } catch (err) {
    return null;
  }
}

async function getUserByOpenid(openid) {
  if (!openid) return null;

  const lastLoginRes = await db.collection(USERS_COLLECTION).where({ lastLoginOpenid: openid }).limit(1).get();
  if (lastLoginRes.data && lastLoginRes.data[0]) return lastLoginRes.data[0];

  const registerRes = await db.collection(USERS_COLLECTION).where({ registerOpenid: openid }).limit(1).get();
  return (registerRes.data && registerRes.data[0]) || null;
}

async function getAdminByOpenid(openid) {
  if (!openid) return null;

  const lastLoginRes = await db.collection(ADMINS_COLLECTION).where({ lastLoginOpenid: openid }).limit(1).get();
  if (lastLoginRes.data && lastLoginRes.data[0]) return lastLoginRes.data[0];

  const openidRes = await db.collection(ADMINS_COLLECTION).where({ openid }).limit(1).get();
  return (openidRes.data && openidRes.data[0]) || null;
}

function trimValue(value) {
  return String(value || '').trim();
}

function normalizeAvatarUrl(value) {
  return trimValue(value);
}

function uniq(list = []) {
  return Array.from(new Set((list || []).filter(Boolean)));
}

function isCloudFileId(value) {
  return /^cloud:\/\//i.test(trimValue(value));
}

function extractLegacyCloudInfo(value) {
  const raw = trimValue(value);
  if (!raw || isCloudFileId(raw)) return null;

  try {
    const url = new URL(raw);
    const hostname = String(url.hostname || '').toLowerCase();
    if (!hostname.endsWith('.tcb.qcloud.la')) return null;

    const bucket = hostname.split('.')[0] || '';
    const path = decodeURIComponent(url.pathname || '').replace(/^\/+/, '');
    if (!bucket || !path) return null;

    const envFromBucket = bucket.replace(/-\d+$/, '');
    const aliasFromEnv = envFromBucket.replace(/^[^-]+-/, '');

    return {
      bucket,
      path,
      envCandidates: uniq([DEFAULT_ENV_ID, envFromBucket, aliasFromEnv])
    };
  } catch (err) {
    return null;
  }
}

function buildLegacyFileIdCandidates(value) {
  const info = extractLegacyCloudInfo(value);
  if (!info) return [];

  const candidates = [];
  info.envCandidates.forEach(env => {
    candidates.push(`cloud://${env}.${info.bucket}/${info.path}`);
    candidates.push(`cloud://${env}/${info.path}`);
  });

  candidates.push(`cloud://${info.bucket}.${info.bucket}/${info.path}`);
  candidates.push(`cloud://${info.bucket}/${info.path}`);

  return uniq(candidates);
}

async function normalizeMediaRefMap(valueList = []) {
  const uniqueValues = uniq((valueList || []).map(trimValue).filter(Boolean));
  const resultMap = {};
  const candidateMap = {};
  const probeList = [];

  uniqueValues.forEach(raw => {
    if (isCloudFileId(raw)) {
      resultMap[raw] = raw;
      return;
    }

    const candidates = buildLegacyFileIdCandidates(raw);
    if (!candidates.length) {
      resultMap[raw] = raw;
      return;
    }

    candidateMap[raw] = candidates;
    probeList.push(...candidates);
  });

  if (probeList.length) {
    try {
      const res = await cloud.getTempFileURL({ fileList: uniq(probeList) });
      const successSet = new Set(
        ((res && res.fileList) || [])
          .filter(item => item && item.tempFileURL)
          .map(item => trimValue(item.fileID))
          .filter(Boolean)
      );

      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = candidateMap[raw].find(candidate => successSet.has(candidate)) || raw;
      });
    } catch (err) {
      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = raw;
      });
    }
  }

  return resultMap;
}

async function normalizeSingleMediaRef(value) {
  const raw = trimValue(value);
  if (!raw) return '';

  const map = await normalizeMediaRefMap([raw]);
  return map[raw] || raw;
}

exports.main = async event => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const role = String(event.role || '').trim();
    const currentPassword = String(event.currentPassword || '');
    const newUsername = String(event.newUsername || '').trim();
    const newPassword = String(event.newPassword || '');
    const avatarUrl = await normalizeSingleMediaRef(normalizeAvatarUrl(event.avatarUrl || ''));
    const hasAvatarField = Object.prototype.hasOwnProperty.call(event || {}, 'avatarUrl');

    if (!openid) return { success: false, message: '获取 openid 失败' };

    if (role === 'user') {
      const userId = String(event.userId || '').trim();
      const user = await getDocById(USERS_COLLECTION, userId) || await getUserByOpenid(openid);

      if (!user || user.enabled === false) return { success: false, message: '用户账号不存在或已停用' };
      if (String(user.lastLoginOpenid || user.registerOpenid || '') !== openid) return { success: false, message: '当前登录状态无效，请重新登录' };

      const currentAvatarUrl = await normalizeSingleMediaRef(user.avatarUrl || '');
      const updateData = { updateTime: now() };
      const needPasswordCheck = !!(newUsername && newUsername !== user.username) || !!newPassword;

      if (needPasswordCheck) {
        if (!currentPassword) return { success: false, message: '请输入当前密码' };
        if (String(user.password || '') !== currentPassword) return { success: false, message: '当前密码错误' };
      }

      if (newUsername && newUsername !== user.username) {
        if (newUsername.length < 3) return { success: false, message: '新账号名至少 3 位' };
        const existed = await findByUsername(USERS_COLLECTION, newUsername);
        if (existed && existed._id !== user._id) return { success: false, message: '该用户账号名已存在' };
        updateData.username = newUsername;
      }

      if (newPassword) {
        if (newPassword.length < 6) return { success: false, message: '新密码至少 6 位' };
        updateData.password = newPassword;
      }

      if (hasAvatarField) {
        updateData.avatarUrl = avatarUrl;
      } else if (currentAvatarUrl !== trimValue(user.avatarUrl)) {
        updateData.avatarUrl = currentAvatarUrl;
      }

      if (Object.keys(updateData).length === 1) return { success: false, message: '至少修改一项内容' };

      await db.collection(USERS_COLLECTION).doc(user._id).update({ data: updateData });
      const nextUsername = updateData.username || user.username;
      const nextAvatarUrl = hasAvatarField ? avatarUrl : currentAvatarUrl;

      return {
        success: true,
        authInfo: {
          userId: user._id,
          username: nextUsername,
          nickname: user.nickname || nextUsername,
          avatarUrl: nextAvatarUrl,
          role: 'user',
          loginTime: now()
        }
      };
    }

    if (role === 'admin') {
      const adminId = String(event.adminId || '').trim();
      const admin = await getDocById(ADMINS_COLLECTION, adminId) || await getAdminByOpenid(openid);

      if (!admin || admin.enabled === false) return { success: false, message: '管理员账号不存在或已停用' };
      if (String(admin.lastLoginOpenid || admin.openid || '') !== openid) return { success: false, message: '当前登录状态无效，请重新登录' };

      const currentAvatarUrl = await normalizeSingleMediaRef(admin.avatarUrl || '');
      const updateData = { updateTime: now() };
      const needPasswordCheck = !!(newUsername && newUsername !== admin.username) || !!newPassword;

      if (needPasswordCheck) {
        if (!currentPassword) return { success: false, message: '请输入当前密码' };
        if (String(admin.password || '') !== currentPassword) return { success: false, message: '当前密码错误' };
      }

      if (newUsername && newUsername !== admin.username) {
        if (newUsername.length < 3) return { success: false, message: '新账号名至少 3 位' };
        const existed = await findByUsername(ADMINS_COLLECTION, newUsername);
        if (existed && existed._id !== admin._id) return { success: false, message: '该管理员账号名已存在' };
        updateData.username = newUsername;
      }

      if (newPassword) {
        if (newPassword.length < 6) return { success: false, message: '新密码至少 6 位' };
        updateData.password = newPassword;
      }

      if (hasAvatarField) {
        updateData.avatarUrl = avatarUrl;
      } else if (currentAvatarUrl !== trimValue(admin.avatarUrl)) {
        updateData.avatarUrl = currentAvatarUrl;
      }

      if (Object.keys(updateData).length === 1) return { success: false, message: '至少修改一项内容' };

      await db.collection(ADMINS_COLLECTION).doc(admin._id).update({ data: updateData });
      const nextUsername = updateData.username || admin.username;
      const nextAvatarUrl = hasAvatarField ? avatarUrl : currentAvatarUrl;

      return {
        success: true,
        authInfo: {
          openid,
          adminId: admin._id,
          username: nextUsername,
          nickname: admin.nickname || '系统管理员',
          avatarUrl: nextAvatarUrl,
          role: 'admin',
          loginTime: now()
        }
      };
    }

    return { success: false, message: '角色类型不支持' };
  } catch (err) {
    return { success: false, message: err && err.message ? err.message : '更新账号失败' };
  }
};
