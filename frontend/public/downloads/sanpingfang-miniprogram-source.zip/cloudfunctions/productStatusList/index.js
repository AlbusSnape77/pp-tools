const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const COLLECTION_NAME = 'product_status';

exports.main = async () => {
  try {
    const res = await db.collection(COLLECTION_NAME).orderBy('productId', 'asc').get();

    return {
      success: true,
      list: Array.isArray(res.data) ? res.data : []
    };
  } catch (err) {
    return {
      success: false,
      message: err && err.message ? err.message : '读取商品状态失败'
    };
  }
};