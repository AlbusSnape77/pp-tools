const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const _ = db.command;
const ORDERS_COLLECTION = 'orders';
const USERS_COLLECTION = 'users';
const PRODUCTS_COLLECTION = 'products';
const PRODUCT_STATUS_COLLECTION = 'product_status';
const SHOP_COLLECTION = 'shop_config';
const DEFAULT_STOCK = 30;

function normalizeArray(value) {
  return Array.isArray(value) ? value : [];
}

function now() {
  return Date.now();
}

function formatTime(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  const h = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  const s = String(date.getSeconds()).padStart(2, '0');
  return `${y}-${m}-${d} ${h}:${mm}:${s}`;
}

function createOrderNo(orderId) {
  return 'SPF' + String(orderId);
}

function createPickupCode(orderId) {
  return String(orderId).slice(-4).padStart(4, '0');
}

function normalizeStock(stock) {
  const value = Number(stock);
  if (!Number.isFinite(value) || value < 0) {
    return DEFAULT_STOCK;
  }
  return Math.floor(value);
}

async function getUserById(userId) {
  if (!userId) return null;
  try {
    const res = await db.collection(USERS_COLLECTION).doc(userId).get();
    return res.data || null;
  } catch (err) {
    return null;
  }
}

function normalizeOrderItems(items = []) {
  return normalizeArray(items)
    .map(item => ({
      id: Number(item.id || 0),
      name: String(item.name || ''),
      desc: String(item.desc || ''),
      price: Number(item.price || 0),
      quantity: Math.max(0, Number(item.quantity || 0)),
      size: item.size || '',
      sweet: item.sweet || '',
      ice: item.ice || '',
      toppings: normalizeArray(item.toppings),
      toppingsText: String(item.toppingsText || '不加小料'),
      toppingMode: String(item.toppingMode || ''),
      toppingModeText: String(item.toppingModeText || '无'),
      icon: item.icon || '',
      iconType: item.iconType || '',
      tag: item.tag || '',
      category: item.category || ''
    }))
    .filter(item => item.id && item.quantity > 0);
}

function buildDemandMap(items = []) {
  const map = {};
  items.forEach(item => {
    const id = Number(item.id || 0);
    if (!id) return;
    map[id] = (map[id] || 0) + Math.max(0, Number(item.quantity || 0));
  });
  return map;
}

async function getSingleDoc(transaction, collectionName, where) {
  const res = await transaction.collection(collectionName).where(where).limit(1).get();
  return (res.data && res.data[0]) || null;
}

async function deductStockSafely(transaction, productDoc, demand, currentTime) {
  const productId = Number(productDoc.id || 0);
  const productName = productDoc.name || '商品';
  const safeDemand = Math.max(1, Number(demand || 0));
  const updateRes = await transaction.collection(PRODUCTS_COLLECTION).where({
    _id: productDoc._id,
    stock: _.gte(safeDemand)
  }).update({
    data: {
      stock: _.inc(-safeDemand),
      updateTime: currentTime
    }
  });

  const updated = Number((updateRes && updateRes.stats && updateRes.stats.updated) || 0);
  if (updated === 1) {
    const latestDoc = await getSingleDoc(transaction, PRODUCTS_COLLECTION, { _id: productDoc._id });
    return normalizeStock(latestDoc && latestDoc.stock);
  }

  const latestDoc = await getSingleDoc(transaction, PRODUCTS_COLLECTION, { _id: productDoc._id });
  const latestStock = normalizeStock(latestDoc && latestDoc.stock);
  if (latestStock <= 0) {
    throw new Error(`${productName}已售罄，请刷新后重试`);
  }
  throw new Error(`${productName}库存变动，仅剩 ${latestStock} 杯，请刷新后重试`);
}

exports.main = async (event) => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const userId = String(event.userId || '').trim();
    const incomingOrder = event.order || {};

    if (!openid) return { success: false, message: '获取 openid 失败' };

    const user = await getUserById(userId);
    if (!user || user.enabled === false) return { success: false, message: '用户身份失效，请重新登录' };

    const items = normalizeOrderItems(incomingOrder.items);
    if (!items.length) return { success: false, message: '订单商品不能为空' };

    const currentTime = now();
    const dateObj = new Date(currentTime);
    const orderId = Number(incomingOrder.id || currentTime);
    const orderNo = String(incomingOrder.orderNo || createOrderNo(orderId));
    const pickupCode = String(incomingOrder.pickupCode || createPickupCode(orderId));
    const demandMap = buildDemandMap(items);

    const order = await db.runTransaction(async transaction => {
      const storeDoc = await getSingleDoc(transaction, SHOP_COLLECTION, { storeId: 'default' });
      const storeStatus = String((storeDoc && storeDoc.status) || 'open');

      if (storeStatus === 'pause') {
        throw new Error('门店暂停接单');
      }

      if (storeStatus === 'closed') {
        throw new Error('门店已打烊');
      }

      const stockSnapshot = [];

      for (const productIdText of Object.keys(demandMap)) {
        const productId = Number(productIdText);
        const demand = Number(demandMap[productId] || 0);

        const productDoc = await getSingleDoc(transaction, PRODUCTS_COLLECTION, { id: productId });
        if (!productDoc || productDoc.enabled === false) {
          throw new Error('部分商品不存在或已下架');
        }

        const statusDoc = await getSingleDoc(transaction, PRODUCT_STATUS_COLLECTION, { productId });
        const manualStatus = String((statusDoc && statusDoc.status) || 'on');
        if (manualStatus === 'paused') {
          throw new Error(`${productDoc.name || '商品'}暂停售卖`);
        }
        if (manualStatus === 'soldout') {
          throw new Error(`${productDoc.name || '商品'}已售罄`);
        }

        const currentStock = normalizeStock(productDoc.stock);
        if (currentStock <= 0) {
          throw new Error(`${productDoc.name || '商品'}已售罄`);
        }
        if (currentStock < demand) {
          throw new Error(`${productDoc.name || '商品'}库存不足，仅剩 ${currentStock} 杯`);
        }

        const afterStock = await deductStockSafely(transaction, productDoc, demand, currentTime);

        stockSnapshot.push({
          productId,
          name: productDoc.name || '',
          beforeStock: currentStock,
          deductQuantity: demand,
          afterStock
        });
      }

      const orderStatus = String(incomingOrder.status || '待处理');
      const verified = orderStatus === '已完成';

      const orderData = {
        id: orderId,
        userId,
        openid,
        accountUsername: user.username || '',
        accountNickname: user.nickname || user.username || '',
        accountAvatar: user.avatarUrl || '',
        orderNo,
        pickupCode,
        createTime: incomingOrder.createTime || formatTime(dateObj),
        createTimestamp: currentTime,
        updateTime: currentTime,
        status: orderStatus,
        verifyStatus: verified ? '已核销' : '未核销',
        verifyTime: verified ? formatTime(dateObj) : '',
        verifyTimestamp: verified ? currentTime : 0,
        totalPrice: Number(incomingOrder.totalPrice || 0),
        discountAmount: Number(incomingOrder.discountAmount || 0),
        payablePrice: Number(incomingOrder.payablePrice || incomingOrder.totalPrice || 0),
        couponId: String(incomingOrder.couponId || ''),
        couponText: String(incomingOrder.couponText || '未使用优惠'),
        remark: String(incomingOrder.remark || ''),
        pickupMode: String(incomingOrder.pickupMode || '立即自取'),
        pickupModeText: String(incomingOrder.pickupModeText || '立即自取'),
        reserveDate: String(incomingOrder.reserveDate || ''),
        reserveDateLabel: String(incomingOrder.reserveDateLabel || ''),
        reserveTime: String(incomingOrder.reserveTime || ''),
        stockDeducted: true,
        stockRestored: false,
        stockSnapshot,
        items
      };

      await transaction.collection(ORDERS_COLLECTION).add({ data: orderData });
      return orderData;
    });

    return {
      success: true,
      order
    };
  } catch (err) {
    return {
      success: false,
      message: err && err.message ? err.message : '创建订单失败'
    };
  }
};
