const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const USERS_COLLECTION = 'users';
const ADMINS_COLLECTION = 'admins';
const DEFAULT_ENV_ID = '';

function now() { return Date.now(); }
async function getUserByUsername(username) { const res = await db.collection(USERS_COLLECTION).where({ username }).limit(1).get(); return (res.data && res.data[0]) || null; }
async function getAdminByUsername(username) { const res = await db.collection(ADMINS_COLLECTION).where({ username }).limit(1).get(); return (res.data && res.data[0]) || null; }
function trimValue(value) { return String(value || '').trim(); }
function uniq(list = []) { return Array.from(new Set((list || []).filter(Boolean))); }
function isCloudFileId(value) { return /^cloud:\/\//i.test(trimValue(value)); }
function extractLegacyCloudInfo(value) {
  const raw = trimValue(value);
  if (!raw || isCloudFileId(raw)) return null;
  try {
    const url = new URL(raw);
    const hostname = String(url.hostname || '').toLowerCase();
    if (!hostname.endsWith('.tcb.qcloud.la')) return null;
    const bucket = hostname.split('.')[0] || '';
    const path = decodeURIComponent(url.pathname || '').replace(/^\/+/, '');
    if (!bucket || !path) return null;
    const envFromBucket = bucket.replace(/-\d+$/, '');
    const aliasFromEnv = envFromBucket.replace(/^[^-]+-/, '');
    return { bucket, path, envCandidates: uniq([DEFAULT_ENV_ID, envFromBucket, aliasFromEnv]) };
  } catch (err) {
    return null;
  }
}
function buildLegacyFileIdCandidates(value) {
  const info = extractLegacyCloudInfo(value);
  if (!info) return [];
  const candidates = [];
  info.envCandidates.forEach(env => {
    candidates.push(`cloud://${env}.${info.bucket}/${info.path}`);
    candidates.push(`cloud://${env}/${info.path}`);
  });
  candidates.push(`cloud://${info.bucket}.${info.bucket}/${info.path}`);
  candidates.push(`cloud://${info.bucket}/${info.path}`);
  return uniq(candidates);
}
async function normalizeMediaRefMap(valueList = []) {
  const uniqueValues = uniq((valueList || []).map(trimValue).filter(Boolean));
  const resultMap = {};
  const candidateMap = {};
  const probeList = [];
  uniqueValues.forEach(raw => {
    if (isCloudFileId(raw)) {
      resultMap[raw] = raw;
      return;
    }
    const candidates = buildLegacyFileIdCandidates(raw);
    if (!candidates.length) {
      resultMap[raw] = raw;
      return;
    }
    candidateMap[raw] = candidates;
    probeList.push(...candidates);
  });
  if (probeList.length) {
    try {
      const res = await cloud.getTempFileURL({ fileList: uniq(probeList) });
      const successSet = new Set(((res && res.fileList) || []).filter(item => item && item.tempFileURL).map(item => trimValue(item.fileID)).filter(Boolean));
      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = candidateMap[raw].find(candidate => successSet.has(candidate)) || raw;
      });
    } catch (err) {
      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = raw;
      });
    }
  }
  return resultMap;
}
async function normalizeSingleMediaRef(value) {
  const raw = trimValue(value);
  if (!raw) return '';
  const map = await normalizeMediaRefMap([raw]);
  return map[raw] || raw;
}
exports.main = async (event) => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const action = String(event.action || '').trim();
    const currentTime = now();
    if (!openid) return { success: false, message: '获取 openid 失败' };
    if (action === 'userRegister') {
      const username = String(event.username || '').trim();
      const password = String(event.password || '');
      const nickname = String(event.nickname || '').trim();
      if (!nickname) return { success: false, message: '请输入昵称' };
      if (username.length < 3) return { success: false, message: '用户账号至少 3 位' };
      if (password.length < 6) return { success: false, message: '用户密码至少 6 位' };
      const existed = await getUserByUsername(username);
      if (existed) return { success: false, message: '该用户账号已存在' };
      const addRes = await db.collection(USERS_COLLECTION).add({ data: { username, password, nickname, avatarUrl: '', role: 'user', enabled: true, createTime: currentTime, updateTime: currentTime, lastLoginTime: currentTime, registerOpenid: openid, lastLoginOpenid: openid } });
      return { success: true, authInfo: { userId: addRes._id, username, nickname, avatarUrl: '', role: 'user', loginTime: currentTime } };
    }
    if (action === 'userLogin') {
      const username = String(event.username || '').trim();
      const password = String(event.password || '');
      if (!username) return { success: false, message: '请输入用户账号' };
      if (!password) return { success: false, message: '请输入用户密码' };
      const user = await getUserByUsername(username);
      if (!user || user.enabled === false) return { success: false, message: '用户账号不存在或已停用' };
      if (String(user.password || '') !== password) return { success: false, message: '用户账号或密码错误' };
      const avatarUrl = await normalizeSingleMediaRef(user.avatarUrl || '');
      await db.collection(USERS_COLLECTION).doc(user._id).update({ data: { lastLoginTime: currentTime, lastLoginOpenid: openid, updateTime: currentTime, avatarUrl } });
      return { success: true, authInfo: { userId: user._id, username: user.username, nickname: user.nickname || user.username, avatarUrl, role: 'user', loginTime: currentTime } };
    }
    if (action === 'adminEntry') {
      const username = String(event.username || '').trim();
      const password = String(event.password || '');
      if (!username) return { success: false, message: '请输入管理员账号' };
      if (!password) return { success: false, message: '请输入管理员密码' };
      const admin = await getAdminByUsername(username);
      if (!admin || admin.enabled === false) return { success: false, message: '管理员账号不存在或已停用' };
      if (String(admin.password || '') !== password) return { success: false, message: '管理员账号或密码错误' };
      const avatarUrl = await normalizeSingleMediaRef(admin.avatarUrl || '');
      await db.collection(ADMINS_COLLECTION).doc(admin._id).update({ data: { lastLoginTime: currentTime, lastLoginOpenid: openid, updateTime: currentTime, avatarUrl } });
      return { success: true, authInfo: { openid, adminId: admin._id, username: admin.username || 'admin', nickname: admin.nickname || '系统管理员', avatarUrl, role: 'admin', loginTime: currentTime } };
    }
    return { success: false, message: '不支持的操作类型' };
  } catch (err) {
    return { success: false, message: err && err.message ? err.message : '云端登录失败' };
  }
};
