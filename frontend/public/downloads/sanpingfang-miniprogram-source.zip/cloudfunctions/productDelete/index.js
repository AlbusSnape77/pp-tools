const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;
const PRODUCTS_COLLECTION = 'products';
const PRODUCT_STATUS_COLLECTION = 'product_status';
const ADMINS_COLLECTION = 'admins';

async function isAdmin(openid) {
  const byOpenid = await db.collection(ADMINS_COLLECTION).where({
    openid,
    enabled: _.neq(false)
  }).limit(1).get();

  if (byOpenid.data && byOpenid.data.length) {
    return true;
  }

  const byLastLoginOpenid = await db.collection(ADMINS_COLLECTION).where({
    lastLoginOpenid: openid,
    enabled: _.neq(false)
  }).limit(1).get();

  return !!(byLastLoginOpenid.data && byLastLoginOpenid.data.length);
}

exports.main = async (event) => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const id = Number(event.id);

    if (!openid) {
      return {
        success: false,
        message: '获取 openid 失败'
      };
    }

    const admin = await isAdmin(openid);

    if (!admin) {
      return {
        success: false,
        message: '无管理员权限'
      };
    }

    if (!id) {
      return {
        success: false,
        message: '商品ID不能为空'
      };
    }

    const res = await db.collection(PRODUCTS_COLLECTION).where({
      id
    }).limit(1).get();

    const product = (res.data && res.data[0]) || null;

    if (!product) {
      return {
        success: false,
        message: '商品不存在'
      };
    }

    await db.collection(PRODUCTS_COLLECTION).doc(product._id).remove();

    const statusRes = await db.collection(PRODUCT_STATUS_COLLECTION).where({
      productId: id
    }).limit(100).get();

    const statusList = statusRes.data || [];
    for (const item of statusList) {
      await db.collection(PRODUCT_STATUS_COLLECTION).doc(item._id).remove();
    }

    return {
      success: true
    };
  } catch (err) {
    return {
      success: false,
      message: err && err.message ? err.message : '删除商品失败'
    };
  }
};