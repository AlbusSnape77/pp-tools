const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;
const FEEDBACK_COLLECTION = 'feedback';
const ADMIN_OPENID = 'o9axD3WgVPbxL1Nxe9OVOeeV_DQo';

async function isAdmin(openid) {
  if (openid === ADMIN_OPENID) {
    return true;
  }

  const byOpenid = await db.collection('admins').where({
    openid,
    enabled: _.neq(false)
  }).limit(1).get();

  if (byOpenid.data && byOpenid.data.length) {
    return true;
  }

  const byLastLoginOpenid = await db.collection('admins').where({
    lastLoginOpenid: openid,
    enabled: _.neq(false)
  }).limit(1).get();

  return !!(byLastLoginOpenid.data && byLastLoginOpenid.data.length);
}

function buildUserInfo(userDoc = {}, openid = '') {
  const accountUsername = String(
    userDoc.username ||
    userDoc.accountUsername ||
    userDoc.userName ||
    ''
  ).trim();

  const accountNickname = String(
    userDoc.nickname ||
    userDoc.accountNickname ||
    userDoc.nickName ||
    ''
  ).trim();

  const userDisplayName =
    accountNickname ||
    accountUsername ||
    (openid ? `用户${String(openid).slice(-6)}` : '未知用户');

  return {
    userOpenId: openid || '',
    accountUsername,
    accountNickname,
    userDisplayName
  };
}

async function getUserMapByOpenIds(openIdList = []) {
  const ids = Array.from(new Set((openIdList || []).filter(Boolean)));
  const map = {};

  if (!ids.length) {
    return map;
  }

  const [usersByRegister, usersByLastLogin, adminsByOpenid, adminsByLastLogin] = await Promise.all([
    db.collection('users').where({
      registerOpenid: _.in(ids)
    }).get(),
    db.collection('users').where({
      lastLoginOpenid: _.in(ids)
    }).get(),
    db.collection('admins').where({
      openid: _.in(ids)
    }).get(),
    db.collection('admins').where({
      lastLoginOpenid: _.in(ids)
    }).get()
  ]);

  (usersByRegister.data || []).forEach(item => {
    const openid = item.registerOpenid || item.lastLoginOpenid || '';
    if (openid) {
      map[openid] = buildUserInfo(item, openid);
    }
  });

  (usersByLastLogin.data || []).forEach(item => {
    const openid = item.lastLoginOpenid || item.registerOpenid || '';
    if (openid) {
      map[openid] = buildUserInfo(item, openid);
    }
  });

  (adminsByOpenid.data || []).forEach(item => {
    if (item.openid) {
      map[item.openid] = buildUserInfo(item, item.openid);
    }
  });

  (adminsByLastLogin.data || []).forEach(item => {
    const openid = item.lastLoginOpenid || item.openid || '';
    if (openid) {
      map[openid] = buildUserInfo(item, openid);
    }
  });

  if (ids.includes(ADMIN_OPENID) && !map[ADMIN_OPENID]) {
    map[ADMIN_OPENID] = buildUserInfo({
      username: 'admin',
      nickname: '系统管理员'
    }, ADMIN_OPENID);
  }

  return map;
}

function enrichFeedbackList(list = [], userMap = {}) {
  return (list || []).map(item => {
    const openid = item.openid || item.creatorOpenId || item.userOpenId || '';
    const userInfo = userMap[openid] || buildUserInfo({}, openid);

    return {
      ...item,
      creatorOpenId: item.creatorOpenId || openid,
      ...userInfo
    };
  });
}

exports.main = async (event) => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const scope = event.scope === 'all' ? 'all' : 'mine';

    if (!openid) {
      return {
        success: false,
        message: '获取 openid 失败'
      };
    }

    if (scope === 'all') {
      const ok = await isAdmin(openid);

      if (!ok) {
        return {
          success: false,
          message: '无管理员权限'
        };
      }

      const res = await db.collection(FEEDBACK_COLLECTION)
        .orderBy('createTimestamp', 'desc')
        .limit(200)
        .get();

      const list = res.data || [];
      const openIdList = list.map(item => item.openid || item.creatorOpenId || item.userOpenId).filter(Boolean);
      const userMap = await getUserMapByOpenIds(openIdList);

      return {
        success: true,
        list: enrichFeedbackList(list, userMap)
      };
    }

    const res = await db.collection(FEEDBACK_COLLECTION)
      .where({
        openid
      })
      .orderBy('createTimestamp', 'desc')
      .limit(200)
      .get();

    const list = res.data || [];
    const openIdList = list.map(item => item.openid || item.creatorOpenId || item.userOpenId).filter(Boolean);
    const userMap = await getUserMapByOpenIds(openIdList);

    return {
      success: true,
      list: enrichFeedbackList(list, userMap)
    };
  } catch (err) {
    return {
      success: false,
      message: err && err.message ? err.message : '读取反馈列表失败'
    };
  }
};
