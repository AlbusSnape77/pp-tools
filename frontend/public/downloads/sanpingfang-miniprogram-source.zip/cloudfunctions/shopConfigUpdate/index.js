const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;
const SHOP_COLLECTION = 'shop_config';
const ADMINS_COLLECTION = 'admins';
const DEFAULT_ENV_ID = '';

function now() {
  return Date.now();
}

function trimValue(value) {
  return String(value || '').trim();
}

function uniq(list = []) {
  return Array.from(new Set((list || []).filter(Boolean)));
}

function isCloudFileId(value) {
  return /^cloud:\/\//i.test(trimValue(value));
}

function extractLegacyCloudInfo(value) {
  const raw = trimValue(value);
  if (!raw || isCloudFileId(raw)) return null;

  try {
    const url = new URL(raw);
    const hostname = String(url.hostname || '').toLowerCase();
    if (!hostname.endsWith('.tcb.qcloud.la')) return null;

    const bucket = hostname.split('.')[0] || '';
    const path = decodeURIComponent(url.pathname || '').replace(/^\/+/, '');
    if (!bucket || !path) return null;

    const envFromBucket = bucket.replace(/-\d+$/, '');
    const aliasFromEnv = envFromBucket.replace(/^[^-]+-/, '');

    return {
      bucket,
      path,
      envCandidates: uniq([DEFAULT_ENV_ID, envFromBucket, aliasFromEnv])
    };
  } catch (err) {
    return null;
  }
}

function buildLegacyFileIdCandidates(value) {
  const info = extractLegacyCloudInfo(value);
  if (!info) return [];

  const candidates = [];
  info.envCandidates.forEach(env => {
    candidates.push(`cloud://${env}.${info.bucket}/${info.path}`);
    candidates.push(`cloud://${env}/${info.path}`);
  });

  candidates.push(`cloud://${info.bucket}.${info.bucket}/${info.path}`);
  candidates.push(`cloud://${info.bucket}/${info.path}`);

  return uniq(candidates);
}

async function normalizeMediaRefMap(valueList = []) {
  const uniqueValues = uniq((valueList || []).map(trimValue).filter(Boolean));
  const resultMap = {};
  const candidateMap = {};
  const probeList = [];

  uniqueValues.forEach(raw => {
    if (isCloudFileId(raw)) {
      resultMap[raw] = raw;
      return;
    }

    const candidates = buildLegacyFileIdCandidates(raw);
    if (!candidates.length) {
      resultMap[raw] = raw;
      return;
    }

    candidateMap[raw] = candidates;
    probeList.push(...candidates);
  });

  if (probeList.length) {
    try {
      const res = await cloud.getTempFileURL({ fileList: uniq(probeList) });
      const successSet = new Set(
        ((res && res.fileList) || [])
          .filter(item => item && item.tempFileURL)
          .map(item => trimValue(item.fileID))
          .filter(Boolean)
      );

      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = candidateMap[raw].find(candidate => successSet.has(candidate)) || raw;
      });
    } catch (err) {
      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = raw;
      });
    }
  }

  return resultMap;
}

async function isAdmin(openid) {
  const byOpenid = await db.collection(ADMINS_COLLECTION).where({
    openid,
    enabled: _.neq(false)
  }).limit(1).get();

  if (byOpenid.data && byOpenid.data.length) {
    return true;
  }

  const byLastLoginOpenid = await db.collection(ADMINS_COLLECTION).where({
    lastLoginOpenid: openid,
    enabled: _.neq(false)
  }).limit(1).get();

  return !!(byLastLoginOpenid.data && byLastLoginOpenid.data.length);
}

async function getStoreDoc() {
  const res = await db.collection(SHOP_COLLECTION).where({
    storeId: 'default'
  }).limit(1).get();

  return (res.data && res.data[0]) || null;
}

exports.main = async (event) => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const config = event.config || {};
    const status = String(config.status || '').trim();
    const mediaMap = await normalizeMediaRefMap([config.storeLogo || '', config.storeCover || '']);
    const storeLogo = mediaMap[trimValue(config.storeLogo)] || trimValue(config.storeLogo);
    const storeCover = mediaMap[trimValue(config.storeCover)] || trimValue(config.storeCover);

    if (!openid) {
      return {
        success: false,
        message: '获取 openid 失败'
      };
    }

    const admin = await isAdmin(openid);

    if (!admin) {
      return {
        success: false,
        message: '无管理员权限'
      };
    }

    if (!['open', 'pause', 'closed'].includes(status)) {
      return {
        success: false,
        message: '门店状态不合法'
      };
    }

    const currentTime = now();
    const existed = await getStoreDoc();
    const data = {
      storeId: 'default',
      status,
      storeLogo,
      storeCover,
      updatedAt: currentTime,
      updatedBy: openid
    };

    if (existed) {
      await db.collection(SHOP_COLLECTION).doc(existed._id).update({
        data
      });
    } else {
      await db.collection(SHOP_COLLECTION).add({
        data
      });
    }

    return {
      success: true,
      config: data
    };
  } catch (err) {
    return {
      success: false,
      message: err && err.message ? err.message : '更新门店配置失败'
    };
  }
};
