const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;
const FEEDBACK_COLLECTION = 'feedback';
const ADMINS_COLLECTION = 'admins';

function now() {
  return Date.now();
}

async function isAdmin(openid) {
  const byOpenid = await db.collection(ADMINS_COLLECTION).where({
    openid,
    enabled: _.neq(false)
  }).limit(1).get();

  if (byOpenid.data && byOpenid.data.length) {
    return true;
  }

  const byLastLoginOpenid = await db.collection(ADMINS_COLLECTION).where({
    lastLoginOpenid: openid,
    enabled: _.neq(false)
  }).limit(1).get();

  return !!(byLastLoginOpenid.data && byLastLoginOpenid.data.length);
}

exports.main = async (event) => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const action = String(event.action || '').trim();

    if (!openid) {
      return {
        success: false,
        message: '获取 openid 失败'
      };
    }

    if (action !== 'markProcessed') {
      return {
        success: false,
        message: '不支持的操作类型'
      };
    }

    const admin = await isAdmin(openid);

    if (!admin) {
      return {
        success: false,
        message: '无管理员权限'
      };
    }

    const feedbackId = Number(event.feedbackId);
    const res = await db.collection(FEEDBACK_COLLECTION).where({
      id: feedbackId
    }).limit(1).get();

    const item = (res.data && res.data[0]) || null;

    if (!item) {
      return {
        success: false,
        message: '反馈不存在'
      };
    }

    await db.collection(FEEDBACK_COLLECTION).doc(item._id).update({
      data: {
        status: '已处理',
        updateTime: now()
      }
    });

    return {
      success: true
    };
  } catch (err) {
    return {
      success: false,
      message: err && err.message ? err.message : '更新反馈状态失败'
    };
  }
};