const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;
const COLLECTION_NAME = 'products';
const DEFAULT_STOCK = 30;
const DEFAULT_ENV_ID = '';

function trimValue(value) {
  return String(value || '').trim();
}

function uniq(list = []) {
  return Array.from(new Set((list || []).filter(Boolean)));
}

function isCloudFileId(value) {
  return /^cloud:\/\//i.test(trimValue(value));
}

function extractLegacyCloudInfo(value) {
  const raw = trimValue(value);
  if (!raw || isCloudFileId(raw)) return null;

  try {
    const url = new URL(raw);
    const hostname = String(url.hostname || '').toLowerCase();
    if (!hostname.endsWith('.tcb.qcloud.la')) return null;

    const bucket = hostname.split('.')[0] || '';
    const path = decodeURIComponent(url.pathname || '').replace(/^\/+/, '');
    if (!bucket || !path) return null;

    const envFromBucket = bucket.replace(/-\d+$/, '');
    const aliasFromEnv = envFromBucket.replace(/^[^-]+-/, '');

    return {
      bucket,
      path,
      envCandidates: uniq([DEFAULT_ENV_ID, envFromBucket, aliasFromEnv])
    };
  } catch (err) {
    return null;
  }
}

function buildLegacyFileIdCandidates(value) {
  const info = extractLegacyCloudInfo(value);
  if (!info) return [];

  const candidates = [];
  info.envCandidates.forEach(env => {
    candidates.push(`cloud://${env}.${info.bucket}/${info.path}`);
    candidates.push(`cloud://${env}/${info.path}`);
  });

  candidates.push(`cloud://${info.bucket}.${info.bucket}/${info.path}`);
  candidates.push(`cloud://${info.bucket}/${info.path}`);

  return uniq(candidates);
}

async function normalizeMediaRefMap(valueList = []) {
  const uniqueValues = uniq((valueList || []).map(trimValue).filter(Boolean));
  const resultMap = {};
  const candidateMap = {};
  const probeList = [];

  uniqueValues.forEach(raw => {
    if (isCloudFileId(raw)) {
      resultMap[raw] = raw;
      return;
    }

    const candidates = buildLegacyFileIdCandidates(raw);
    if (!candidates.length) {
      resultMap[raw] = raw;
      return;
    }

    candidateMap[raw] = candidates;
    probeList.push(...candidates);
  });

  if (probeList.length) {
    try {
      const res = await cloud.getTempFileURL({ fileList: uniq(probeList) });
      const successSet = new Set(
        ((res && res.fileList) || [])
          .filter(item => item && item.tempFileURL)
          .map(item => trimValue(item.fileID))
          .filter(Boolean)
      );

      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = candidateMap[raw].find(candidate => successSet.has(candidate)) || raw;
      });
    } catch (err) {
      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = raw;
      });
    }
  }

  return resultMap;
}

function normalizeStock(stock) {
  const value = Number(stock);
  if (!Number.isFinite(value) || value < 0) {
    return DEFAULT_STOCK;
  }
  return Math.floor(value);
}

exports.main = async (event) => {
  try {
    const id = Number(event.id);

    if (!id) {
      return {
        success: false,
        message: '商品ID不能为空'
      };
    }

    const res = await db.collection(COLLECTION_NAME).where({
      id,
      enabled: _.neq(false)
    }).limit(1).get();

    const product = (res.data && res.data[0]) || null;

    if (!product) {
      return {
        success: false,
        message: '商品不存在'
      };
    }

    const mediaMap = await normalizeMediaRefMap([product.icon || '']);
    const icon = mediaMap[trimValue(product.icon)] || trimValue(product.icon);

    if (product._id && icon !== trimValue(product.icon)) {
      await db.collection(COLLECTION_NAME).doc(product._id).update({
        data: {
          icon,
          updateTime: Date.now()
        }
      });
    }

    return {
      success: true,
      product: {
        ...product,
        icon,
        stock: normalizeStock(product.stock)
      }
    };
  } catch (err) {
    return {
      success: false,
      message: err && err.message ? err.message : '读取商品详情失败'
    };
  }
};
