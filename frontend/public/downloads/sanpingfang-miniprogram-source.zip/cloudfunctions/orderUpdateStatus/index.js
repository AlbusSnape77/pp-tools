const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const _ = db.command;
const ORDERS_COLLECTION = 'orders';
const ADMINS_COLLECTION = 'admins';
const USERS_COLLECTION = 'users';
const PRODUCTS_COLLECTION = 'products';
const DEFAULT_STOCK = 30;

function now() {
  return Date.now();
}

function formatTime(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  const h = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  const s = String(date.getSeconds()).padStart(2, '0');
  return `${y}-${m}-${d} ${h}:${mm}:${s}`;
}

function normalizeStock(stock) {
  const value = Number(stock);
  if (!Number.isFinite(value) || value < 0) {
    return DEFAULT_STOCK;
  }
  return Math.floor(value);
}

function buildDemandMap(items = []) {
  const map = {};
  (Array.isArray(items) ? items : []).forEach(item => {
    const id = Number(item.id || 0);
    if (!id) return;
    map[id] = (map[id] || 0) + Math.max(0, Number(item.quantity || 0));
  });
  return map;
}

async function isAdmin(openid) {
  const byOpenid = await db.collection(ADMINS_COLLECTION).where({ openid, enabled: _.neq(false) }).limit(1).get();
  if (byOpenid.data && byOpenid.data.length) return true;
  const byLastLoginOpenid = await db.collection(ADMINS_COLLECTION).where({ lastLoginOpenid: openid, enabled: _.neq(false) }).limit(1).get();
  return !!(byLastLoginOpenid.data && byLastLoginOpenid.data.length);
}

async function getUserById(userId) {
  if (!userId) return null;
  try {
    const res = await db.collection(USERS_COLLECTION).doc(userId).get();
    return res.data || null;
  } catch (err) {
    return null;
  }
}

async function getOrderByWhere(where) {
  const res = await db.collection(ORDERS_COLLECTION).where(where).limit(1).get();
  return (res.data && res.data[0]) || null;
}

async function getProductByIdInTx(transaction, productId) {
  const res = await transaction.collection(PRODUCTS_COLLECTION).where({ id: productId }).limit(1).get();
  return (res.data && res.data[0]) || null;
}

async function restoreOrderStockIfNeeded(transaction, order, currentTime) {
  if (!order || order.stockDeducted !== true || order.stockRestored === true) {
    return;
  }

  const demandMap = buildDemandMap(order.items || []);
  for (const productIdText of Object.keys(demandMap)) {
    const productId = Number(productIdText);
    const demand = Number(demandMap[productId] || 0);
    if (!productId || demand <= 0) continue;

    const productDoc = await getProductByIdInTx(transaction, productId);
    if (!productDoc || productDoc.enabled === false) continue;

    const currentStock = normalizeStock(productDoc.stock);
    await transaction.collection(PRODUCTS_COLLECTION).doc(productDoc._id).update({
      data: {
        stock: currentStock + demand,
        updateTime: currentTime
      }
    });
  }

  await transaction.collection(ORDERS_COLLECTION).doc(order._id).update({
    data: {
      stockRestored: true,
      updateTime: currentTime
    }
  });
}

exports.main = async (event) => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const action = String(event.action || '').trim();
    const currentTime = now();

    if (!openid) return { success: false, message: '获取 openid 失败' };

    if (action === 'cancelMine') {
      const userId = String(event.userId || '').trim();
      const user = await getUserById(userId);
      if (!user || user.enabled === false) return { success: false, message: '用户身份失效，请重新登录' };

      const orderId = Number(event.orderId);
      const order = await getOrderByWhere({ id: orderId, userId });
      if (!order) return { success: false, message: '订单不存在' };
      if (order.status === '已完成' || order.status === '已取消') return { success: false, message: '当前订单不可取消' };

      await db.runTransaction(async transaction => {
        const latestOrder = await transaction.collection(ORDERS_COLLECTION).where({ id: orderId, userId }).limit(1).get();
        const orderDoc = (latestOrder.data && latestOrder.data[0]) || null;
        if (!orderDoc) throw new Error('订单不存在');
        if (orderDoc.status === '已完成' || orderDoc.status === '已取消') throw new Error('当前订单不可取消');

        await restoreOrderStockIfNeeded(transaction, orderDoc, currentTime);
        await transaction.collection(ORDERS_COLLECTION).doc(orderDoc._id).update({
          data: {
            status: '已取消',
            verifyStatus: '未核销',
            verifyTime: '',
            verifyTimestamp: 0,
            updateTime: currentTime
          }
        });
      });

      return { success: true };
    }

    if (action === 'adminUpdateById') {
      const admin = await isAdmin(openid);
      if (!admin) return { success: false, message: '无管理员权限' };

      const orderId = Number(event.orderId);
      const status = String(event.status || '').trim();
      if (!status) return { success: false, message: '缺少订单状态' };

      const order = await getOrderByWhere({ id: orderId });
      if (!order) return { success: false, message: '订单不存在' };

      await db.runTransaction(async transaction => {
        const latestOrder = await transaction.collection(ORDERS_COLLECTION).where({ id: orderId }).limit(1).get();
        const orderDoc = (latestOrder.data && latestOrder.data[0]) || null;
        if (!orderDoc) throw new Error('订单不存在');

        if (status === '已取消' && orderDoc.status !== '已取消' && orderDoc.status !== '已完成') {
          await restoreOrderStockIfNeeded(transaction, orderDoc, currentTime);
        }

        const updateData = {
          status,
          verifyStatus: status === '已完成' ? '已核销' : '未核销',
          verifyTime: status === '已完成' ? formatTime(new Date(currentTime)) : '',
          verifyTimestamp: status === '已完成' ? currentTime : 0,
          updateTime: currentTime
        };

        await transaction.collection(ORDERS_COLLECTION).doc(orderDoc._id).update({ data: updateData });
      });

      return { success: true };
    }

    if (action === 'adminVerifyByCode') {
      const admin = await isAdmin(openid);
      if (!admin) return { success: false, message: '无管理员权限' };

      const pickupCode = String(event.pickupCode || '').trim();
      if (!pickupCode) return { success: false, message: '取餐码不能为空' };

      await db.runTransaction(async transaction => {
        const latestOrderRes = await transaction.collection(ORDERS_COLLECTION).where({ pickupCode }).limit(1).get();
        const orderDoc = (latestOrderRes.data && latestOrderRes.data[0]) || null;

        if (!orderDoc) {
          throw new Error('未找到对应订单');
        }

        if (orderDoc.status === '已完成' || orderDoc.verifyStatus === '已核销') {
          throw new Error('该订单已核销，请勿重复操作');
        }

        if (orderDoc.status !== '待取餐') {
          throw new Error('当前订单不可核销');
        }

        await transaction.collection(ORDERS_COLLECTION).doc(orderDoc._id).update({
          data: {
            status: '已完成',
            verifyStatus: '已核销',
            verifyTime: formatTime(new Date(currentTime)),
            verifyTimestamp: currentTime,
            updateTime: currentTime
          }
        });
      });

      return { success: true };
    }

    return { success: false, message: '不支持的操作类型' };
  } catch (err) {
    return { success: false, message: err && err.message ? err.message : '更新订单状态失败' };
  }
};
