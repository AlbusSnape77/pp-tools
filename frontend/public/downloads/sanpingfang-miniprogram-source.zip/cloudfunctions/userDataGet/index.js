const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const USERS_COLLECTION = 'users';
const USER_DATA_COLLECTION = 'user_data';
function now() { return Date.now(); }
function normalizeDoc(doc = {}) { return { cartList: Array.isArray(doc.cartList) ? doc.cartList : [], favoriteList: Array.isArray(doc.favoriteList) ? doc.favoriteList : [], recentViewedList: Array.isArray(doc.recentViewedList) ? doc.recentViewedList : [] }; }
async function getUserById(userId) { if (!userId) return null; try { const res = await db.collection(USERS_COLLECTION).doc(userId).get(); return res.data || null; } catch (err) { return null; } }
async function getDocByUserId(userId) { const res = await db.collection(USER_DATA_COLLECTION).where({ userId }).limit(1).get(); return (res.data && res.data[0]) || null; }
exports.main = async (event) => { try { const userId = String(event.userId || '').trim(); if (!userId) return { success: false, message: '用户身份无效，请重新登录' }; const user = await getUserById(userId); if (!user || user.enabled === false) return { success: false, message: '用户账号不存在或已停用' }; let doc = await getDocByUserId(userId); if (!doc) { const currentTime = now(); const addRes = await db.collection(USER_DATA_COLLECTION).add({ data: { userId, username: user.username || '', nickname: user.nickname || '', cartList: [], favoriteList: [], recentViewedList: [], createTime: currentTime, updateTime: currentTime } }); doc = { _id: addRes._id, userId, cartList: [], favoriteList: [], recentViewedList: [], createTime: currentTime, updateTime: currentTime }; } return { success: true, data: normalizeDoc(doc) }; } catch (err) { return { success: false, message: err && err.message ? err.message : '读取用户数据失败' }; } };
