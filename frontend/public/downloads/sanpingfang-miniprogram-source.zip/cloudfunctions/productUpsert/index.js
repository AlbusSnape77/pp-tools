const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const _ = db.command;
const PRODUCTS_COLLECTION = 'products';
const ADMINS_COLLECTION = 'admins';
const DEFAULT_STOCK = 30;
const DEFAULT_ENV_ID = '';

function now() {
  return Date.now();
}

function trimValue(value) {
  return String(value || '').trim();
}

function uniq(list = []) {
  return Array.from(new Set((list || []).filter(Boolean)));
}

function isCloudFileId(value) {
  return /^cloud:\/\//i.test(trimValue(value));
}

function extractLegacyCloudInfo(value) {
  const raw = trimValue(value);
  if (!raw || isCloudFileId(raw)) return null;

  try {
    const url = new URL(raw);
    const hostname = String(url.hostname || '').toLowerCase();
    if (!hostname.endsWith('.tcb.qcloud.la')) return null;

    const bucket = hostname.split('.')[0] || '';
    const path = decodeURIComponent(url.pathname || '').replace(/^\/+/, '');
    if (!bucket || !path) return null;

    const envFromBucket = bucket.replace(/-\d+$/, '');
    const aliasFromEnv = envFromBucket.replace(/^[^-]+-/, '');

    return {
      bucket,
      path,
      envCandidates: uniq([DEFAULT_ENV_ID, envFromBucket, aliasFromEnv])
    };
  } catch (err) {
    return null;
  }
}

function buildLegacyFileIdCandidates(value) {
  const info = extractLegacyCloudInfo(value);
  if (!info) return [];

  const candidates = [];
  info.envCandidates.forEach(env => {
    candidates.push(`cloud://${env}.${info.bucket}/${info.path}`);
    candidates.push(`cloud://${env}/${info.path}`);
  });

  candidates.push(`cloud://${info.bucket}.${info.bucket}/${info.path}`);
  candidates.push(`cloud://${info.bucket}/${info.path}`);

  return uniq(candidates);
}

async function normalizeMediaRefMap(valueList = []) {
  const uniqueValues = uniq((valueList || []).map(trimValue).filter(Boolean));
  const resultMap = {};
  const candidateMap = {};
  const probeList = [];

  uniqueValues.forEach(raw => {
    if (isCloudFileId(raw)) {
      resultMap[raw] = raw;
      return;
    }

    const candidates = buildLegacyFileIdCandidates(raw);
    if (!candidates.length) {
      resultMap[raw] = raw;
      return;
    }

    candidateMap[raw] = candidates;
    probeList.push(...candidates);
  });

  if (probeList.length) {
    try {
      const res = await cloud.getTempFileURL({ fileList: uniq(probeList) });
      const successSet = new Set(
        ((res && res.fileList) || [])
          .filter(item => item && item.tempFileURL)
          .map(item => trimValue(item.fileID))
          .filter(Boolean)
      );

      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = candidateMap[raw].find(candidate => successSet.has(candidate)) || raw;
      });
    } catch (err) {
      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = raw;
      });
    }
  }

  return resultMap;
}

async function normalizeSingleMediaRef(value) {
  const raw = trimValue(value);
  if (!raw) return '';

  const map = await normalizeMediaRefMap([raw]);
  return map[raw] || raw;
}

function isImageSource(value) {
  return /^(https?:\/\/|cloud:\/\/|data:image)/i.test(String(value || '').trim());
}

function normalizeStock(stock) {
  const value = Number(stock);
  if (!Number.isFinite(value) || value < 0) {
    return DEFAULT_STOCK;
  }
  return Math.floor(value);
}

async function isAdmin(openid) {
  const byOpenid = await db.collection(ADMINS_COLLECTION).where({ openid, enabled: _.neq(false) }).limit(1).get();
  if (byOpenid.data && byOpenid.data.length) return true;
  const byLastLoginOpenid = await db.collection(ADMINS_COLLECTION).where({ lastLoginOpenid: openid, enabled: _.neq(false) }).limit(1).get();
  return !!(byLastLoginOpenid.data && byLastLoginOpenid.data.length);
}

async function getNextProductId() {
  const res = await db.collection(PRODUCTS_COLLECTION).orderBy('id', 'desc').limit(1).get();
  const lastItem = (res.data && res.data[0]) || null;
  return lastItem ? Number(lastItem.id || 0) + 1 : 1;
}

exports.main = async (event) => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;

    if (!openid) return { success: false, message: '获取 openid 失败' };

    const admin = await isAdmin(openid);
    if (!admin) return { success: false, message: '无管理员权限' };

    const product = event.product || {};
    const currentTime = now();
    const name = String(product.name || '').trim();
    const desc = String(product.desc || '').trim();
    const category = String(product.category || '').trim();
    const tag = String(product.tag || '').trim();
    const icon = await normalizeSingleMediaRef(String(product.icon || '').trim() || '🧋');
    const iconType = isImageSource(icon) ? 'image' : 'emoji';
    const price = Number(product.price || 0);
    const stock = normalizeStock(product.stock);

    if (!name) return { success: false, message: '商品名称不能为空' };
    if (!desc) return { success: false, message: '商品描述不能为空' };
    if (!category) return { success: false, message: '商品分类不能为空' };
    if (!(price > 0)) return { success: false, message: '商品价格必须大于 0' };
    if (stock < 0) return { success: false, message: '库存不能小于 0' };

    const incomingId = Number(product.id || 0);

    if (incomingId) {
      const existedRes = await db.collection(PRODUCTS_COLLECTION).where({ id: incomingId }).limit(1).get();
      const existed = (existedRes.data && existedRes.data[0]) || null;
      if (!existed) return { success: false, message: '待编辑商品不存在' };

      const updateData = {
        name,
        desc,
        price,
        stock,
        category,
        tag,
        icon,
        iconType,
        enabled: true,
        sortOrder: Number(existed.sortOrder || incomingId),
        updateTime: currentTime
      };

      await db.collection(PRODUCTS_COLLECTION).doc(existed._id).update({ data: updateData });
      return { success: true, product: { ...existed, ...updateData } };
    }

    const nextId = await getNextProductId();
    const data = {
      id: nextId,
      name,
      desc,
      price,
      stock,
      category,
      tag,
      icon,
      iconType,
      enabled: true,
      sortOrder: nextId,
      createTime: currentTime,
      updateTime: currentTime
    };

    const addRes = await db.collection(PRODUCTS_COLLECTION).add({ data });
    return { success: true, product: { _id: addRes._id, ...data } };
  } catch (err) {
    return { success: false, message: err && err.message ? err.message : '保存商品失败' };
  }
};
