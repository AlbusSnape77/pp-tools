const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;
const COLLECTION_NAME = 'products';
const DEFAULT_STOCK = 30;
const DEFAULT_ENV_ID = '';

const DEFAULT_PRODUCTS = [
  { id: 1, name: '珍珠奶茶', desc: '经典奶香口味，搭配珍珠更有嚼劲', price: 16, category: '招牌奶茶', tag: '经典热卖', iconType: 'emoji', icon: '🧋' },
  { id: 2, name: '芋泥波波奶茶', desc: '芋泥绵密细腻，奶香浓郁，口感层次丰富', price: 18, category: '招牌奶茶', tag: '人气推荐', iconType: 'emoji', icon: '🥤' },
  { id: 3, name: '黑糖珍珠鲜奶', desc: '黑糖香浓，珍珠Q弹，奶香顺滑', price: 19, category: '招牌奶茶', tag: '黑糖系列', iconType: 'emoji', icon: '🟤' },
  { id: 4, name: '奥利奥奶茶', desc: '浓郁奶茶搭配奥利奥碎，口感丰富', price: 18, category: '招牌奶茶', tag: '甜口推荐', iconType: 'emoji', icon: '🍪' },
  { id: 5, name: '布丁奶茶', desc: '滑嫩布丁搭配奶茶，口感柔和香甜', price: 17, category: '招牌奶茶', tag: '顺滑口感', iconType: 'emoji', icon: '🍮' },
  { id: 6, name: '红豆奶茶', desc: '红豆软糯香甜，适合喜欢饱满口感的人', price: 17, category: '招牌奶茶', tag: '饱满口感', iconType: 'emoji', icon: '🫘' },
  { id: 7, name: '四季奶青', desc: '茶香清爽，奶味柔和，口感平衡', price: 16, category: '招牌奶茶', tag: '清爽茶底', iconType: 'emoji', icon: '🍵' },
  { id: 8, name: '茉莉奶绿', desc: '茉莉花香清新，入口轻盈顺口', price: 16, category: '招牌奶茶', tag: '花香茶底', iconType: 'emoji', icon: '🌿' },
  { id: 9, name: '烤奶', desc: '茶香更浓郁，适合喜欢厚重口感的人', price: 17, category: '招牌奶茶', tag: '浓郁推荐', iconType: 'emoji', icon: '🔥' },
  { id: 10, name: '厚乳奶茶', desc: '奶香更突出，整体口感更醇厚顺滑', price: 19, category: '招牌奶茶', tag: '浓乳系列', iconType: 'emoji', icon: '🥛' },

  { id: 11, name: '西瓜椰椰', desc: '西瓜清甜搭配椰香口感，清爽解暑，是本店招牌果茶', price: 20, category: '果茶', tag: '本店招牌', iconType: 'emoji', icon: '🍉' },
  { id: 12, name: '杨枝甘露', desc: '芒果香甜，西柚清新，果香层次更丰富', price: 19, category: '果茶', tag: '热门果茶', iconType: 'emoji', icon: '🥭' },
  { id: 13, name: '满杯百香果', desc: '酸甜清爽，果香浓郁，适合夏日饮用', price: 17, category: '果茶', tag: '清新推荐', iconType: 'emoji', icon: '🍋' },
  { id: 14, name: '多肉葡萄', desc: '葡萄果香浓郁，入口清甜，口感饱满', price: 20, category: '果茶', tag: '果香爆款', iconType: 'emoji', icon: '🍇' },
  { id: 15, name: '芝芝桃桃', desc: '桃香柔和细腻，奶盖搭配更有层次', price: 21, category: '果茶', tag: '奶盖系列', iconType: 'emoji', icon: '🍑' },
  { id: 16, name: '柠檬绿茶', desc: '柠檬清香和绿茶结合，酸爽解腻', price: 15, category: '果茶', tag: '经典清爽', iconType: 'emoji', icon: '🍋' },
  { id: 17, name: '草莓果茶', desc: '草莓香甜明显，入口果味更丰富', price: 19, category: '果茶', tag: '少女口味', iconType: 'emoji', icon: '🍓' },
  { id: 18, name: '芒果西柚茶', desc: '芒果香甜搭配西柚清苦，层次感更强', price: 20, category: '果茶', tag: '层次丰富', iconType: 'emoji', icon: '🥭' },
  { id: 19, name: '青提茉莉', desc: '青提香气清新，搭配茉莉更显轻盈', price: 20, category: '果茶', tag: '轻盈清香', iconType: 'emoji', icon: '🍏' },
  { id: 20, name: '蜜桃乌龙果茶', desc: '桃香柔和，乌龙茶底更显清爽回甘', price: 18, category: '果茶', tag: '茶香果香', iconType: 'emoji', icon: '🍑' },

  { id: 21, name: '拿铁咖啡', desc: '奶香与咖啡香平衡，口感顺滑柔和', price: 19, category: '咖啡', tag: '咖啡系列', iconType: 'emoji', icon: '☕' },
  { id: 22, name: '美式咖啡', desc: '口感更清爽，咖啡风味更直接，适合提神', price: 15, category: '咖啡', tag: '提神必备', iconType: 'emoji', icon: '🫘' },
  { id: 23, name: '生椰拿铁', desc: '椰香与咖啡香融合，口感更柔和顺滑', price: 21, category: '咖啡', tag: '椰香推荐', iconType: 'emoji', icon: '🥥' },
  { id: 24, name: '焦糖玛奇朵', desc: '焦糖香气明显，整体口感更柔和香甜', price: 22, category: '咖啡', tag: '甜口咖啡', iconType: 'emoji', icon: '🍮' },
  { id: 25, name: '榛果拿铁', desc: '榛果香气浓郁，适合喜欢坚果风味的人', price: 22, category: '咖啡', tag: '坚果风味', iconType: 'emoji', icon: '🌰' },
  { id: 26, name: '摩卡咖啡', desc: '巧克力风味和咖啡结合，浓郁顺滑', price: 22, category: '咖啡', tag: '可可系列', iconType: 'emoji', icon: '🍫' },
  { id: 27, name: '香草拿铁', desc: '香草甜香柔和，适合不爱苦味的人', price: 21, category: '咖啡', tag: '香草风味', iconType: 'emoji', icon: '🌼' },
  { id: 28, name: '冰博克拿铁', desc: '奶香更厚重，整体口感更醇厚浓郁', price: 24, category: '咖啡', tag: '醇厚推荐', iconType: 'emoji', icon: '🥛' },
  { id: 29, name: '桂花拿铁', desc: '桂花清香和咖啡结合，风味更特别', price: 22, category: '咖啡', tag: '花香咖啡', iconType: 'emoji', icon: '🌼' },
  { id: 30, name: '燕麦拿铁', desc: '燕麦奶口感更轻盈，适合喜欢植物奶的人', price: 23, category: '咖啡', tag: '植物奶系列', iconType: 'emoji', icon: '🌾' }
];

function now() {
  return Date.now();
}

function trimValue(value) {
  return String(value || '').trim();
}

function uniq(list = []) {
  return Array.from(new Set((list || []).filter(Boolean)));
}

function isCloudFileId(value) {
  return /^cloud:\/\//i.test(trimValue(value));
}

function extractLegacyCloudInfo(value) {
  const raw = trimValue(value);
  if (!raw || isCloudFileId(raw)) return null;

  try {
    const url = new URL(raw);
    const hostname = String(url.hostname || '').toLowerCase();
    if (!hostname.endsWith('.tcb.qcloud.la')) return null;

    const bucket = hostname.split('.')[0] || '';
    const path = decodeURIComponent(url.pathname || '').replace(/^\/+/, '');
    if (!bucket || !path) return null;

    const envFromBucket = bucket.replace(/-\d+$/, '');
    const aliasFromEnv = envFromBucket.replace(/^[^-]+-/, '');

    return {
      bucket,
      path,
      envCandidates: uniq([DEFAULT_ENV_ID, envFromBucket, aliasFromEnv])
    };
  } catch (err) {
    return null;
  }
}

function buildLegacyFileIdCandidates(value) {
  const info = extractLegacyCloudInfo(value);
  if (!info) return [];

  const candidates = [];
  info.envCandidates.forEach(env => {
    candidates.push(`cloud://${env}.${info.bucket}/${info.path}`);
    candidates.push(`cloud://${env}/${info.path}`);
  });

  candidates.push(`cloud://${info.bucket}.${info.bucket}/${info.path}`);
  candidates.push(`cloud://${info.bucket}/${info.path}`);

  return uniq(candidates);
}

async function normalizeMediaRefMap(valueList = []) {
  const uniqueValues = uniq((valueList || []).map(trimValue).filter(Boolean));
  const resultMap = {};
  const candidateMap = {};
  const probeList = [];

  uniqueValues.forEach(raw => {
    if (isCloudFileId(raw)) {
      resultMap[raw] = raw;
      return;
    }

    const candidates = buildLegacyFileIdCandidates(raw);
    if (!candidates.length) {
      resultMap[raw] = raw;
      return;
    }

    candidateMap[raw] = candidates;
    probeList.push(...candidates);
  });

  if (probeList.length) {
    try {
      const res = await cloud.getTempFileURL({ fileList: uniq(probeList) });
      const successSet = new Set(
        ((res && res.fileList) || [])
          .filter(item => item && item.tempFileURL)
          .map(item => trimValue(item.fileID))
          .filter(Boolean)
      );

      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = candidateMap[raw].find(candidate => successSet.has(candidate)) || raw;
      });
    } catch (err) {
      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = raw;
      });
    }
  }

  return resultMap;
}

function normalizeStock(stock) {
  const value = Number(stock);
  if (!Number.isFinite(value) || value < 0) {
    return DEFAULT_STOCK;
  }
  return Math.floor(value);
}

function normalizeProduct(item = {}) {
  return {
    ...item,
    stock: normalizeStock(item.stock)
  };
}

async function seedIfEmpty() {
  const countRes = await db.collection(COLLECTION_NAME).count();

  if (countRes.total > 0) {
    return;
  }

  const currentTime = now();

  for (const item of DEFAULT_PRODUCTS) {
    await db.collection(COLLECTION_NAME).add({
      data: {
        ...item,
        stock: DEFAULT_STOCK,
        enabled: true,
        sortOrder: item.id,
        createTime: currentTime,
        updateTime: currentTime
      }
    });
  }
}

exports.main = async () => {
  try {
    await seedIfEmpty();

    const res = await db.collection(COLLECTION_NAME)
      .where({
        enabled: _.neq(false)
      })
      .orderBy('sortOrder', 'asc')
      .limit(100)
      .get();

    const list = Array.isArray(res.data) ? res.data.map(normalizeProduct) : [];
    const mediaMap = await normalizeMediaRefMap(list.map(item => item.icon || ''));

    const normalizedList = [];
    for (const item of list) {
      const icon = mediaMap[trimValue(item.icon)] || trimValue(item.icon);
      const nextItem = {
        ...item,
        icon,
        stock: normalizeStock(item.stock)
      };
      normalizedList.push(nextItem);

      if (item._id && icon !== trimValue(item.icon)) {
        await db.collection(COLLECTION_NAME).doc(item._id).update({
          data: {
            icon,
            updateTime: now()
          }
        });
      }
    }

    return {
      success: true,
      list: normalizedList
    };
  } catch (err) {
    return {
      success: false,
      message: err && err.message ? err.message : '读取商品列表失败'
    };
  }
};
