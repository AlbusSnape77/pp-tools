const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;
const ADMIN_OPENID = 'o9axD3WgVPbxL1Nxe9OVOeeV_DQo';

async function isAdmin(openid) {
  if (openid === ADMIN_OPENID) {
    return true;
  }

  const res = await db.collection('admins').where({
    openid,
    enabled: true
  }).limit(1).get();

  return res.data.length > 0;
}

function buildUserInfo(userDoc = {}, openid = '') {
  const accountUsername = String(
    userDoc.username ||
    userDoc.accountUsername ||
    userDoc.userName ||
    ''
  ).trim();

  const accountNickname = String(
    userDoc.nickname ||
    userDoc.accountNickname ||
    userDoc.nickName ||
    ''
  ).trim();

  const userDisplayName =
    accountNickname ||
    accountUsername ||
    (openid ? `用户${String(openid).slice(-6)}` : '未知用户');

  return {
    userOpenId: openid || '',
    accountUsername,
    accountNickname,
    userDisplayName
  };
}

async function getUserMapByOpenIds(openIdList = []) {
  const ids = Array.from(new Set((openIdList || []).filter(Boolean)));
  const map = {};

  if (!ids.length) {
    return map;
  }

  const [userRes, adminRes] = await Promise.all([
    db.collection('users').where({
      openid: _.in(ids)
    }).get(),
    db.collection('admins').where({
      openid: _.in(ids)
    }).get()
  ]);

  (userRes.data || []).forEach(item => {
    map[item.openid] = buildUserInfo(item, item.openid);
  });

  (adminRes.data || []).forEach(item => {
    map[item.openid] = buildUserInfo(item, item.openid);
  });

  if (ids.includes(ADMIN_OPENID) && !map[ADMIN_OPENID]) {
    map[ADMIN_OPENID] = buildUserInfo({
      username: 'admin',
      nickname: '系统管理员'
    }, ADMIN_OPENID);
  }

  return map;
}

function enrichOrderList(list = [], userMap = {}) {
  return (list || []).map(item => {
    const openid = item.creatorOpenId || item.userOpenId || '';
    const userInfo = userMap[openid] || buildUserInfo({}, openid);

    return {
      ...item,
      ...userInfo
    };
  });
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext();
  const openid = wxContext.OPENID;
  const scope = event.scope === 'all' ? 'all' : 'mine';

  if (scope === 'all') {
    const ok = await isAdmin(openid);

    if (!ok) {
      return {
        success: false,
        message: '无管理员权限'
      };
    }

    const res = await db.collection('orders')
      .orderBy('createTime', 'desc')
      .limit(200)
      .get();

    const list = res.data || [];
    const openIdList = list.map(item => item.creatorOpenId).filter(Boolean);
    const userMap = await getUserMapByOpenIds(openIdList);

    return {
      success: true,
      list: enrichOrderList(list, userMap)
    };
  }

  const res = await db.collection('orders')
    .where({
      creatorOpenId: openid
    })
    .orderBy('createTime', 'desc')
    .limit(200)
    .get();

  const list = res.data || [];
  const openIdList = list.map(item => item.creatorOpenId).filter(Boolean);
  const userMap = await getUserMapByOpenIds(openIdList);

  return {
    success: true,
    list: enrichOrderList(list, userMap)
  };
};