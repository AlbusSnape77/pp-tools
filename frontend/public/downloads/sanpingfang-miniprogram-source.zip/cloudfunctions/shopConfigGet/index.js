const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const COLLECTION_NAME = 'shop_config';
const DEFAULT_ENV_ID = '';

function now() {
  return Date.now();
}

function trimValue(value) {
  return String(value || '').trim();
}

function uniq(list = []) {
  return Array.from(new Set((list || []).filter(Boolean)));
}

function isCloudFileId(value) {
  return /^cloud:\/\//i.test(trimValue(value));
}

function extractLegacyCloudInfo(value) {
  const raw = trimValue(value);
  if (!raw || isCloudFileId(raw)) return null;

  try {
    const url = new URL(raw);
    const hostname = String(url.hostname || '').toLowerCase();
    if (!hostname.endsWith('.tcb.qcloud.la')) return null;

    const bucket = hostname.split('.')[0] || '';
    const path = decodeURIComponent(url.pathname || '').replace(/^\/+/, '');
    if (!bucket || !path) return null;

    const envFromBucket = bucket.replace(/-\d+$/, '');
    const aliasFromEnv = envFromBucket.replace(/^[^-]+-/, '');

    return {
      bucket,
      path,
      envCandidates: uniq([DEFAULT_ENV_ID, envFromBucket, aliasFromEnv])
    };
  } catch (err) {
    return null;
  }
}

function buildLegacyFileIdCandidates(value) {
  const info = extractLegacyCloudInfo(value);
  if (!info) return [];

  const candidates = [];
  info.envCandidates.forEach(env => {
    candidates.push(`cloud://${env}.${info.bucket}/${info.path}`);
    candidates.push(`cloud://${env}/${info.path}`);
  });

  candidates.push(`cloud://${info.bucket}.${info.bucket}/${info.path}`);
  candidates.push(`cloud://${info.bucket}/${info.path}`);

  return uniq(candidates);
}

async function normalizeMediaRefMap(valueList = []) {
  const uniqueValues = uniq((valueList || []).map(trimValue).filter(Boolean));
  const resultMap = {};
  const candidateMap = {};
  const probeList = [];

  uniqueValues.forEach(raw => {
    if (isCloudFileId(raw)) {
      resultMap[raw] = raw;
      return;
    }

    const candidates = buildLegacyFileIdCandidates(raw);
    if (!candidates.length) {
      resultMap[raw] = raw;
      return;
    }

    candidateMap[raw] = candidates;
    probeList.push(...candidates);
  });

  if (probeList.length) {
    try {
      const res = await cloud.getTempFileURL({ fileList: uniq(probeList) });
      const successSet = new Set(
        ((res && res.fileList) || [])
          .filter(item => item && item.tempFileURL)
          .map(item => trimValue(item.fileID))
          .filter(Boolean)
      );

      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = candidateMap[raw].find(candidate => successSet.has(candidate)) || raw;
      });
    } catch (err) {
      Object.keys(candidateMap).forEach(raw => {
        resultMap[raw] = raw;
      });
    }
  }

  return resultMap;
}

async function getStoreDoc() {
  const res = await db.collection(COLLECTION_NAME).where({
    storeId: 'default'
  }).limit(1).get();

  return (res.data && res.data[0]) || null;
}

exports.main = async () => {
  try {
    let doc = await getStoreDoc();

    if (!doc) {
      const initDoc = {
        storeId: 'default',
        status: 'open',
        storeLogo: '',
        storeCover: '',
        updatedAt: now(),
        updatedBy: 'system'
      };

      const addRes = await db.collection(COLLECTION_NAME).add({
        data: initDoc
      });

      doc = {
        _id: addRes._id,
        ...initDoc
      };
    }

    const mediaMap = await normalizeMediaRefMap([doc.storeLogo || '', doc.storeCover || '']);
    const storeLogo = mediaMap[trimValue(doc.storeLogo)] || trimValue(doc.storeLogo);
    const storeCover = mediaMap[trimValue(doc.storeCover)] || trimValue(doc.storeCover);

    if (doc._id && (storeLogo !== trimValue(doc.storeLogo) || storeCover !== trimValue(doc.storeCover))) {
      await db.collection(COLLECTION_NAME).doc(doc._id).update({
        data: {
          storeLogo,
          storeCover,
          updatedAt: now()
        }
      });
    }

    return {
      success: true,
      config: {
        storeId: doc.storeId || 'default',
        status: doc.status || 'open',
        storeLogo,
        storeCover,
        updatedAt: Number(doc.updatedAt || 0),
        updatedBy: doc.updatedBy || 'system'
      }
    };
  } catch (err) {
    return {
      success: false,
      message: err && err.message ? err.message : '读取门店配置失败'
    };
  }
};
